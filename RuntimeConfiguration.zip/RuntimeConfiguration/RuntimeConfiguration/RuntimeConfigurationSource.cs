﻿using Microsoft.Extensions.Configuration.Memory;

namespace RuntimeConfiguration;

internal sealed class RuntimeConfigurationSource
    : IConfigurationSource
{
    public RuntimeConfigurationProvider? Provider { get; private set; }

    public IConfigurationProvider Build(
        IConfigurationBuilder builder)
    {
        // ConfigurationManager may call Build more than once. Reuse the
        // same provider so the DI singleton stays consistent with the
        // instance IConfiguration actually reads from.
        return Provider ??= new RuntimeConfigurationProvider(
            new MemoryConfigurationSource());
    }
}
