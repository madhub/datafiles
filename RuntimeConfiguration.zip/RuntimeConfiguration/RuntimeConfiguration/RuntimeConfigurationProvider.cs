﻿using Microsoft.Extensions.Configuration.Memory;

namespace RuntimeConfiguration;

internal sealed class RuntimeConfigurationProvider
    : MemoryConfigurationProvider
{
    private readonly object _sync = new();

    public RuntimeConfigurationProvider(
        MemoryConfigurationSource source)
        : base(source)
    {
    }

    public void SetAndReload(string key, string? value)
    {
        if (string.IsNullOrWhiteSpace(key))
        {
            throw new ArgumentException(
                "Configuration key must be provided.",
                nameof(key));
        }

        // Guard against concurrent writes corrupting the backing store.
        lock (_sync)
        {
            Set(key, value);
        }

        // Notify IConfiguration consumers such as IOptionsMonitor<T>
        OnReload();
    }
    public void SetManyAndReload(
        IEnumerable<KeyValuePair<string, string?>> values)
    {
        lock (_sync)
        {
            foreach (var (key, value) in values) Set(key, value);
        }
        OnReload();
    }
}
