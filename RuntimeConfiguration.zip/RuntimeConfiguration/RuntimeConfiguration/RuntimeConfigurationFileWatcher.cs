namespace RuntimeConfiguration;
internal sealed class RuntimeConfigurationFileWatcher(
    RuntimeConfigurationProvider provider,
    IConfiguration configuration,
    ILogger<RuntimeConfigurationFileWatcher> logger) : BackgroundService
{
    private readonly string _path =
        configuration["RuntimeOverridesFile"] ?? "appsettings-runtime-overrides.json";
    private string? _seen;

    protected override async Task ExecuteAsync(CancellationToken ct)
    {
        _seen = Hash();  // ignore file present at startup -> ephemeral
        using var timer = new PeriodicTimer(TimeSpan.FromSeconds(5));
        while (await timer.WaitForNextTickAsync(ct))
        {
            try
            {
                var hash = Hash();
                if (hash is null || hash == _seen) continue;

                var file = new ConfigurationBuilder()
                    .AddJsonFile(_path, optional: true).Build();
                var allowed = configuration.GetSection("RuntimeOverrides")
                    .Get<string[]>() ?? [];

                provider.SetManyAndReload(file.AsEnumerable()
                    .Where(kv => kv.Value is not null
                        && allowed.Contains(kv.Key, StringComparer.OrdinalIgnoreCase)));
                _seen = hash;
            }
            catch (Exception ex) { logger.LogWarning(ex, "Override apply failed."); }
        }
    }

    private string? Hash() => File.Exists(_path)
        ? Convert.ToHexString(System.Security.Cryptography.SHA256.HashData(
            File.ReadAllBytes(_path)))
        : null;
}