using Microsoft.Extensions.Options;
using RuntimeConfiguration;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.
builder.AddRuntimeConfiguration();
builder.Services
    .AddOptions<ResilienceSettings>()
    .BindConfiguration("MySettings:Resilience");
var app = builder.Build();

// Configure the HTTP request pipeline.

var summaries = new[]
{
    "Freezing", "Bracing", "Chilly", "Cool", "Mild", "Warm", "Balmy", "Hot", "Sweltering", "Scorching"
};
app.MapRuntimeConfiguration();
app.MapGet("/weatherforecast", (IConfiguration configuration,IOptionsMonitor<ResilienceSettings> optionsMonitor, IOptions<ResilienceSettings> options) =>
{

    var maxRetry = configuration.GetValue<int?>("MySettings:Resilience:MaxRetry");
    Console.WriteLine($"MaxRetry from configuration: {maxRetry}");
    Console.WriteLine($"MaxRetry from optionsMonitor: {optionsMonitor.CurrentValue.MaxRetry}");
    Console.WriteLine($"MaxRetry from options: {options.Value.MaxRetry}");

    var forecast = Enumerable.Range(1, 5).Select(index =>
        new WeatherForecast
        (
            DateOnly.FromDateTime(DateTime.Now.AddDays(index)),
            Random.Shared.Next(-20, 55),
            summaries[Random.Shared.Next(summaries.Length)]
        ))
        .ToArray();
    return forecast;
});

app.Run();

internal record WeatherForecast(DateOnly Date, int TemperatureC, string? Summary)
{
    public int TemperatureF => 32 + (int)(TemperatureC / 0.5556);
}

public sealed class ResilienceSettings
{
    public int MaxRetry { get; set; }

    public int TimeoutSeconds { get; set; }
}