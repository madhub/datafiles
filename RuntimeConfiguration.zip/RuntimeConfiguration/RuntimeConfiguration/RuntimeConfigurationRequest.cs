﻿namespace RuntimeConfiguration;

public sealed record RuntimeConfigurationRequest(
    string Key,
    string? Value);