﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace RuntimeConfiguration;

public static class RuntimeConfigurationExtensions
{
    private const string RuntimeOverridesSection =
        "RuntimeOverrides";

    private const string Endpoint =
        "/internal/runtime-config";

    public static WebApplicationBuilder AddRuntimeConfiguration(
        this WebApplicationBuilder builder)
    {
        var source = new RuntimeConfigurationSource();

        // ConfigurationManager implements IConfigurationBuilder,
        // but use the interface explicitly to avoid ambiguity.
        ((IConfigurationBuilder)builder.Configuration)
            .Add(source);

        // ConfigurationManager builds the provider immediately when
        // the source is added.
        var provider = source.Provider
            ?? throw new InvalidOperationException(
                "Runtime configuration provider was not created.");

        builder.Services.AddSingleton(provider);

        return builder;
    }

    /// <summary>
    /// Maps the runtime configuration endpoint to the application.
    /// Curl example : 
    /// curl -X PUT http://localhost:5000/internal/runtime-config -H "Content-Type: application/json" -d "{\"key\":\"MySettings:Resilience:MaxRetry\",\"value\":\"NewValue\"}"
    /// </summary>
    /// <param name="app"></param>
    /// <returns></returns>
    public static WebApplication MapRuntimeConfiguration(
        this WebApplication app)
    {
        app.MapPut(
            Endpoint,
            (
                HttpContext httpContext,
                [FromBody]RuntimeConfigurationRequest? request,
                IConfiguration configuration,
                RuntimeConfigurationProvider provider) =>
            {
                // Defense in depth: only accept loopback callers even if
                // the endpoint is inadvertently exposed beyond localhost.
                if (!IsLoopback(httpContext))
                {
                    return Results.NotFound();
                }

                if (request is null
                    || string.IsNullOrWhiteSpace(request.Key))
                {
                    return Results.BadRequest(
                        "Configuration key is required.");
                }

                if (!IsAllowed(
                        request.Key,
                        configuration))
                {
                    return Results.BadRequest(
                        $"Configuration key '{request.Key}' " +
                        "is not allowed for runtime override.");
                }

                provider.SetAndReload(
                    request.Key,
                    request.Value);

                return Results.Ok(new
                {
                    request.Key,
                    request.Value
                });
            });

        return app;
    }

    private static bool IsLoopback(HttpContext httpContext)
    {
        var remoteIp = httpContext.Connection.RemoteIpAddress;

        // A null remote address means an in-process/test connection.
        if (remoteIp is null)
        {
            return true;
        }

        var localIp = httpContext.Connection.LocalIpAddress;

        return System.Net.IPAddress.IsLoopback(remoteIp)
            || remoteIp.Equals(localIp);
    }

    private static bool IsAllowed(
        string key,
        IConfiguration configuration)
    {
        var allowedKeys =
            configuration
                .GetSection(RuntimeOverridesSection)
                .Get<string[]>();

        return allowedKeys?.Contains(
            key,
            StringComparer.OrdinalIgnoreCase) == true;
    }
}