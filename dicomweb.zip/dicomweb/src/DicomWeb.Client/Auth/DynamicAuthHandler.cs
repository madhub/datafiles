using System.Net.Http;
using System.Threading;
using System.Threading.Tasks;
using DicomWeb.Client.Common;
using Microsoft.Extensions.Http;

namespace DicomWeb.Client.Auth;

/// <summary>
/// A DelegatingHandler that extracts the DicomWebContext from request options
/// and delegates authentication to the configured IAuthProvider.
/// </summary>
public class DynamicAuthHandler : DelegatingHandler
{
    protected override async Task<HttpResponseMessage> SendAsync(HttpRequestMessage request, CancellationToken ct)
    {
        // 1. Extract Context
        if (request.Options.TryGetValue(new HttpRequestOptionsKey<DicomWebContext>(DicomWebConstants.ContextOptionsKey), out var context) && context != null)
        {
            // 2. Configure Auth
            if (context.AuthProvider != null)
            {
                await context.AuthProvider.ConfigureRequestAsync(request, ct);
            }
        }
        
        // 3. Continue pipeline
        return await base.SendAsync(request, ct);
    }
}
