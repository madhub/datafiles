using System.Net.Http;
using System.Threading;
using System.Threading.Tasks;

namespace DicomWeb.Client.Auth;

/// <summary>
/// Defines a strategy for authenticating a DICOMweb request.
/// </summary>
public interface IAuthProvider
{
    /// <summary>
    /// Configures the request with necessary authentication headers or signatures.
    /// </summary>
    Task ConfigureRequestAsync(HttpRequestMessage request, CancellationToken ct);
}
