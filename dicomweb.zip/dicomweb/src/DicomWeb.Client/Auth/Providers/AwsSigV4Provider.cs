using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Threading;
using System.Threading.Tasks;
using Amazon.Runtime;
using AwsSignatureVersion4.Private;
using DicomWeb.Client.Common;
using Microsoft.Extensions.Http;

namespace DicomWeb.Client.Auth.Providers;

/// <summary>
/// Provides AWS SigV4 authentication.
/// </summary>
public class AwsSigV4Provider : IAuthProvider
{
    private readonly string _region;
    private readonly string _service;
    private readonly ImmutableCredentials _credentials;

    public AwsSigV4Provider(string region, string service, ImmutableCredentials credentials)
    {
        _region = region ?? throw new ArgumentNullException(nameof(region));
        _service = service ?? throw new ArgumentNullException(nameof(service));
        _credentials = credentials ?? throw new ArgumentNullException(nameof(credentials));
    }

    public async Task ConfigureRequestAsync(HttpRequestMessage request, CancellationToken ct)
    {
        // We need the BaseAddress. 
        // We can get it from the Context if it was stored there.
        // In DicomWebClient, we likely create the request with absolute URI?
        // If request.RequestUri is absolute, we can use it as base.
        
        Uri? baseAddress = null;
        if (request.RequestUri != null && request.RequestUri.IsAbsoluteUri)
        {
            // Use the authority/scheme as base? 
            // Signer expects baseAddress. It's used to calculate the relative path if needed.
            // If we assume the request has full path, we can perhaps just pass the root.
            baseAddress = new Uri(request.RequestUri.GetLeftPart(UriPartial.Authority));
        }
        else
        {
             // Try to get from context options as a fallback
             if (request.Options.TryGetValue(new HttpRequestOptionsKey<DicomWebContext>(DicomWebConstants.ContextOptionsKey), out var ctx) && ctx != null)
             {
                 baseAddress = ctx.BaseServiceUrl;
             }
        }
        
        if (baseAddress == null)
            throw new InvalidOperationException("Cannot determine BaseAddress for SigV4 signing. Ensure request URI is absolute or BaseServiceUrl is set in context.");

        // Sign
        await Signer.SignAsync(
            request,
            baseAddress,
            Enumerable.Empty<KeyValuePair<string, IEnumerable<string>>>(), // We don't have access to DefaultRequestHeaders
            DateTime.UtcNow,
            _region,
            _service,
            _credentials
        );
    }
}
