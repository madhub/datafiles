using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using FellowOakDicom;
using DicomWeb.Client.Common;

namespace DicomWeb.Client;

/// <summary>
/// A provider-agnostic client for interacting with DICOMweb services.
/// </summary>
public interface IDicomWebClient
{
    /// <summary>
    /// Retrieves a DICOM study.
    /// </summary>
    Task<DicomFile[]> RetrieveStudyAsync(DicomWebContext context, string studyInstanceUid, CancellationToken ct = default);

    /// <summary>
    /// Searches for DICOM studies (QIDO-RS).
    /// </summary>
    Task<IEnumerable<DicomDataset>> QueryStudiesAsync(DicomWebContext context, QidoRequest request, CancellationToken ct = default);

    /// <summary>
    /// Searches for DICOM series (QIDO-RS).
    /// </summary>
    Task<IEnumerable<DicomDataset>> QuerySeriesAsync(DicomWebContext context, string studyInstanceUid, QidoRequest request, CancellationToken ct = default);

    /// <summary>
    /// Searches for DICOM instances (QIDO-RS).
    /// </summary>
    Task<IEnumerable<DicomDataset>> QueryInstancesAsync(DicomWebContext context, string studyInstanceUid, string seriesInstanceUid, QidoRequest request, CancellationToken ct = default);

    Task<DicomFile[]> RetrieveSeriesAsync(DicomWebContext context, string studyInstanceUid, string seriesInstanceUid, CancellationToken ct = default);
    Task<DicomFile> RetrieveInstanceAsync(DicomWebContext context, string studyInstanceUid, string seriesInstanceUid, string sopInstanceUid, CancellationToken ct = default);
    Task<System.IO.Stream[]> RetrieveFramesAsync(DicomWebContext context, string studyInstanceUid, string seriesInstanceUid, string sopInstanceUid, int[] frames, CancellationToken ct = default);

    Task<IEnumerable<DicomDataset>> RetrieveStudyMetadataAsync(DicomWebContext context, string studyInstanceUid, CancellationToken ct = default);
    Task<IEnumerable<DicomDataset>> RetrieveSeriesMetadataAsync(DicomWebContext context, string studyInstanceUid, string seriesInstanceUid, CancellationToken ct = default);
    Task<IEnumerable<DicomDataset>> RetrieveInstanceMetadataAsync(DicomWebContext context, string studyInstanceUid, string seriesInstanceUid, string sopInstanceUid, CancellationToken ct = default);

    /// <summary>
    /// Stores DICOM files (STOW-RS).
    /// </summary>
    Task<DicomDataset> StoreAsync(DicomWebContext context, IEnumerable<DicomFile> files, string? studyInstanceUid = null, CancellationToken ct = default);
}
