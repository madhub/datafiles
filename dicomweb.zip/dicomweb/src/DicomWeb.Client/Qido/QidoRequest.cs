using System.Collections.Generic;
using System.Linq;
using System.Text.Encodings.Web;
using System.Text;
using FellowOakDicom;

namespace DicomWeb.Client;

/// <summary>
/// Represents a QIDO-RS search request.
/// </summary>
public class QidoRequest
{
    public int? Limit { get; set; }
    public int? Offset { get; set; }
    public bool? FuzzyMatching { get; set; }
    public List<string> IncludeFields { get; set; } = new List<string>();
    
    // Standard matching fields
    // Standard matching fields (Key can be Tag ID "00100010", Keyword "PatientName", or Path "00101002.00100020")
    public Dictionary<string, string> Filters { get; set; } = new Dictionary<string, string>();

    public void AddFilter(DicomTag tag, string value)
    {
         // Default to Tag ID for precision, but standard allows Keyword.
         // Let's use Tag ID format GGGGEEEE to match previous logic, or user can put keyword manually.
         Filters[$"{tag.Group:X4}{tag.Element:X4}"] = value;
    }

    public void AddFilter(string key, string value)
    {
        Filters[key] = value;
    }

    public string ToQueryString()
    {
        var sb = new StringBuilder();
        var isFirst = true;

        void Append(string key, string value)
        {
            if (!isFirst) sb.Append("&");
            sb.Append($"{UrlEncoder.Default.Encode(key)}={UrlEncoder.Default.Encode(value)}");
            isFirst = false;
        }

        if (Limit.HasValue) Append("limit", Limit.Value.ToString());
        if (Offset.HasValue) Append("offset", Offset.Value.ToString());
        if (FuzzyMatching.HasValue) Append("fuzzymatching", FuzzyMatching.Value.ToString().ToLowerInvariant());

        foreach (var field in IncludeFields)
        {
            Append("includefield", field);
        }

        foreach (var filter in Filters)
        {
            Append(filter.Key, filter.Value);
        }

        return sb.ToString();
    }
}
