using System;
using DicomWeb.Client.Auth;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Http.Resilience;
using Polly;

namespace DicomWeb.Client;

public static class DicomWebClientServiceCollectionExtensions
{
    public static IServiceCollection AddDicomWebClient(this IServiceCollection services)
    {
        services.AddScoped<DynamicAuthHandler>();
        
        services.AddHttpClient(DicomWebClient.HttpClientName)
            .AddHttpMessageHandler<DynamicAuthHandler>()
            .AddStandardResilienceHandler(); // Adds default resilience strategies (Retry, CircuitBreaker, Timeout)
            
        services.AddTransient<IDicomWebClient, DicomWebClient>();
        
        return services;
    }
}
