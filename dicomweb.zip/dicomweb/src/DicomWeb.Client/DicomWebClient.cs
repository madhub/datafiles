using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Threading;
using System.Threading.Tasks;
using DicomWeb.Client.Auth;
using DicomWeb.Client.Common;
using FellowOakDicom;
using Microsoft.AspNetCore.WebUtilities;
using Microsoft.Extensions.Http;

namespace DicomWeb.Client;

public class DicomWebClient : IDicomWebClient
{
    private readonly IHttpClientFactory _httpClientFactory;
    
    // We expect a named client configuration called "DicomWebClient"
    // that has the DynamicAuthHandler and Resilience configured.
    public const string HttpClientName = "DicomWebClient";

    public DicomWebClient(IHttpClientFactory httpClientFactory)
    {
        _httpClientFactory = httpClientFactory ?? throw new ArgumentNullException(nameof(httpClientFactory));
    }

    public async Task<DicomFile[]> RetrieveStudyAsync(DicomWebContext context, string studyInstanceUid, CancellationToken ct = default)
    {
        if (context == null) throw new ArgumentNullException(nameof(context));
        if (string.IsNullOrWhiteSpace(studyInstanceUid)) throw new ArgumentException("Study Instance UID is required", nameof(studyInstanceUid));

        var uri = DicomWebUriBuilder.BuildRetrieveStudyUri(context.BaseServiceUrl, studyInstanceUid);
        return await RetrieveMultipartAsync(context, uri, ct);
    }


    public async Task<IEnumerable<DicomDataset>> QueryStudiesAsync(DicomWebContext context, QidoRequest request, CancellationToken ct = default)
    {
        var uri = DicomWebUriBuilder.BuildQueryStudiesUri(context.BaseServiceUrl, request?.ToQueryString());
        return await PerformQueryAsync(context, uri, ct);
    }

    public async Task<IEnumerable<DicomDataset>> QuerySeriesAsync(DicomWebContext context, string studyInstanceUid, QidoRequest request, CancellationToken ct = default)
    {
        var uri = DicomWebUriBuilder.BuildQuerySeriesUri(context.BaseServiceUrl, studyInstanceUid, request?.ToQueryString());
        return await PerformQueryAsync(context, uri, ct);
    }

    public async Task<IEnumerable<DicomDataset>> QueryInstancesAsync(DicomWebContext context, string studyInstanceUid, string seriesInstanceUid, QidoRequest request, CancellationToken ct = default)
    {
        var uri = DicomWebUriBuilder.BuildQueryInstancesUri(context.BaseServiceUrl, studyInstanceUid, seriesInstanceUid, request?.ToQueryString());
        return await PerformQueryAsync(context, uri, ct);
    }

    public async Task<DicomFile[]> RetrieveSeriesAsync(DicomWebContext context, string studyInstanceUid, string seriesInstanceUid, CancellationToken ct = default)
    {
        var uri = DicomWebUriBuilder.BuildRetrieveSeriesUri(context.BaseServiceUrl, studyInstanceUid, seriesInstanceUid);
        return await RetrieveMultipartAsync(context, uri, ct); // Reusing logic
    }

    public async Task<DicomFile> RetrieveInstanceAsync(DicomWebContext context, string studyInstanceUid, string seriesInstanceUid, string sopInstanceUid, CancellationToken ct = default)
    {
        var uri = DicomWebUriBuilder.BuildRetrieveInstanceUri(context.BaseServiceUrl, studyInstanceUid, seriesInstanceUid, sopInstanceUid);
        var files = await RetrieveMultipartAsync(context, uri, ct);
        return files.FirstOrDefault() ?? throw new DicomDataException("Instance not found or empty response");
    }

    public async Task<Stream[]> RetrieveFramesAsync(DicomWebContext context, string studyInstanceUid, string seriesInstanceUid, string sopInstanceUid, int[] frames, CancellationToken ct = default)
    {
        var uri = DicomWebUriBuilder.BuildRetrieveFramesUri(context.BaseServiceUrl, studyInstanceUid, seriesInstanceUid, sopInstanceUid, frames);
        
        // Custom multipart handling for frames (octet-stream)
        using var request = new HttpRequestMessage(HttpMethod.Get, uri);
        request.Options.Set(new HttpRequestOptionsKey<DicomWebContext>(DicomWebConstants.ContextOptionsKey), context);
        request.Headers.Accept.Add(new MediaTypeWithQualityHeaderValue("multipart/related"));
        // request.Headers.Accept.Add(new MediaTypeWithQualityHeaderValue("application/octet-stream")); // WADO-RS spec says multipart/related; type="application/octet-stream"

        var client = _httpClientFactory.CreateClient(HttpClientName);
        using var response = await client.SendAsync(request, HttpCompletionOption.ResponseHeadersRead, ct);
        response.EnsureSuccessStatusCode();

        return await ParseMultipartFramesResponseAsync(response, ct);
    }

    public async Task<IEnumerable<DicomDataset>> RetrieveStudyMetadataAsync(DicomWebContext context, string studyInstanceUid, CancellationToken ct = default)
    {
        var uri = DicomWebUriBuilder.BuildRetrieveStudyMetadataUri(context.BaseServiceUrl, studyInstanceUid);
        return await PerformQueryAsync(context, uri, ct);
    }

    public async Task<IEnumerable<DicomDataset>> RetrieveSeriesMetadataAsync(DicomWebContext context, string studyInstanceUid, string seriesInstanceUid, CancellationToken ct = default)
    {
        var uri = DicomWebUriBuilder.BuildRetrieveSeriesMetadataUri(context.BaseServiceUrl, studyInstanceUid, seriesInstanceUid);
        return await PerformQueryAsync(context, uri, ct);
    }

    public async Task<IEnumerable<DicomDataset>> RetrieveInstanceMetadataAsync(DicomWebContext context, string studyInstanceUid, string seriesInstanceUid, string sopInstanceUid, CancellationToken ct = default)
    {
        var uri = DicomWebUriBuilder.BuildRetrieveInstanceMetadataUri(context.BaseServiceUrl, studyInstanceUid, seriesInstanceUid, sopInstanceUid);
        return await PerformQueryAsync(context, uri, ct);
    }

    public async Task<DicomDataset> StoreAsync(DicomWebContext context, IEnumerable<DicomFile> files, string? studyInstanceUid = null, CancellationToken ct = default)
    {
        if (files == null || !files.Any()) throw new ArgumentException("No files to store", nameof(files));

        var uri = DicomWebUriBuilder.BuildStoreUri(context.BaseServiceUrl, studyInstanceUid);

        using var content = new MultipartContent("related", "DICOM_BOUNDARY_" + Guid.NewGuid().ToString("N"));
        content.Headers.ContentType.Parameters.Add(new NameValueHeaderValue("type", "\"application/dicom\""));

        foreach (var file in files)
        {
            var ms = new MemoryStream();
            await file.SaveAsync(ms);
            ms.Position = 0;

            var streamContent = new StreamContent(ms);
            streamContent.Headers.ContentType = new MediaTypeHeaderValue("application/dicom");
            content.Add(streamContent);
        }

        using var httpRequest = new HttpRequestMessage(HttpMethod.Post, uri);
        httpRequest.Options.Set(new HttpRequestOptionsKey<DicomWebContext>(DicomWebConstants.ContextOptionsKey), context);
        httpRequest.Headers.Accept.Add(new MediaTypeWithQualityHeaderValue("application/dicom+json"));
        httpRequest.Content = content;

        var client = _httpClientFactory.CreateClient(HttpClientName);
        using var response = await client.SendAsync(httpRequest, ct);
        
        // STOW-RS can fail partially (202 Accepted) or fully.
        // If 200/202, parse body for details.
        if (!response.IsSuccessStatusCode)
        {
             // Log or throw? EnsureSuccessStatusCode throws.
             response.EnsureSuccessStatusCode(); 
        }

        var responseContent = await response.Content.ReadAsStringAsync(ct);
        
        var options = new System.Text.Json.JsonSerializerOptions();
        options.Converters.Add(new FellowOakDicom.Serialization.DicomJsonConverter());
        
        IEnumerable<DicomDataset>? datasets = null;
        try 
        {
             datasets = System.Text.Json.JsonSerializer.Deserialize<IEnumerable<DicomDataset>>(responseContent, options);
        } 
        catch 
        {
            // If parsing fails but HTTP is success, we might warn or just return empty.
            // But STOW usually returns body.
        }

        var responseDataset = datasets?.FirstOrDefault();
        
        // 202 Accepted means some instances failed.
        if (response.StatusCode == System.Net.HttpStatusCode.Accepted)
        {
             throw new DicomWebException($"STOW-RS completed with failures. Status: {response.StatusCode}", response.StatusCode);
        }
        
        if (responseDataset != null && responseDataset.Contains(DicomTag.FailedSOPSequence))
        {
             throw new DicomWebException($"STOW-RS completed with failures. Status: {response.StatusCode}", response.StatusCode);
        }

        return responseDataset ?? new DicomDataset();
    }

    private async Task<IEnumerable<DicomDataset>> PerformQueryAsync(DicomWebContext context, Uri uri, CancellationToken ct)
    {
        using var httpRequest = new HttpRequestMessage(HttpMethod.Get, uri);
        httpRequest.Options.Set(new HttpRequestOptionsKey<DicomWebContext>(DicomWebConstants.ContextOptionsKey), context);
        httpRequest.Headers.Accept.Add(new MediaTypeWithQualityHeaderValue("application/dicom+json"));

        var client = _httpClientFactory.CreateClient(HttpClientName);
        using var response = await client.SendAsync(httpRequest, ct);
        response.EnsureSuccessStatusCode();

        var content = await response.Content.ReadAsStringAsync(ct);
        if (string.IsNullOrWhiteSpace(content)) return Enumerable.Empty<DicomDataset>();

        var options = new System.Text.Json.JsonSerializerOptions();
        options.Converters.Add(new FellowOakDicom.Serialization.DicomJsonConverter());
        
        return System.Text.Json.JsonSerializer.Deserialize<IEnumerable<DicomDataset>>(content, options) 
               ?? Enumerable.Empty<DicomDataset>();
    }

    // Refactored helper from RetrieveStudyAsync
    private async Task<DicomFile[]> RetrieveMultipartAsync(DicomWebContext context, Uri uri, CancellationToken ct)
    {
        using var request = new HttpRequestMessage(HttpMethod.Get, uri);
        request.Options.Set(new HttpRequestOptionsKey<DicomWebContext>(DicomWebConstants.ContextOptionsKey), context);
        request.Headers.Accept.Add(new MediaTypeWithQualityHeaderValue("multipart/related"));
        request.Headers.Accept.Add(new MediaTypeWithQualityHeaderValue("application/dicom")); 

        var client = _httpClientFactory.CreateClient(HttpClientName);
        using var response = await client.SendAsync(request, HttpCompletionOption.ResponseHeadersRead, ct);
        response.EnsureSuccessStatusCode();

        return await ParseMultipartResponseAsync(response, ct);
    }

    private async Task<Stream[]> ParseMultipartFramesResponseAsync(HttpResponseMessage response, CancellationToken ct)
    {
        var content = response.Content;
        var contentType = content.Headers.ContentType;
         // TODO: Validate boundary
         if (contentType == null) throw new HttpRequestException("Missing Content-Type header");
         var boundary = GetBoundary(contentType);
         var stream = await content.ReadAsStreamAsync(ct);
         var reader = new MultipartReader(boundary, stream);
         
         var frames = new List<Stream>();
         MultipartSection? section;
         while ((section = await reader.ReadNextSectionAsync(ct)) != null)
         {
             var memoryStream = new MemoryStream();
             await section.Body.CopyToAsync(memoryStream, ct);
             memoryStream.Position = 0;
             frames.Add(memoryStream);
         }
         return frames.ToArray();
    }

    private async Task<DicomFile[]> ParseMultipartResponseAsync(HttpResponseMessage response, CancellationToken ct)
    {
        var content = response.Content;
        var contentType = content.Headers.ContentType;

        if (contentType != null && contentType.MediaType.Equals("multipart/related", StringComparison.OrdinalIgnoreCase))
        {
            var boundary = GetBoundary(contentType);
            var stream = await content.ReadAsStreamAsync(ct);
            var reader = new MultipartReader(boundary, stream);
            
            var dicomFiles = new List<DicomFile>();

            MultipartSection? section;
            while ((section = await reader.ReadNextSectionAsync(ct)) != null)
            {
                // Each section should be a DICOM instance
                // We should clone the stream or read fully because DicomFile.OpenAsync might need seekable?
                // DicomFile.OpenAsync supports non-seekable if explicit false passed for defer loading?
                // Actually, fo-dicom strongly prefers seekable for performance but can handle stream.
                // However, Multipart parser stream is strictly forward-only.
                // Safest to copy to memory if files are reasonable size (typical for individual instances).
                
                using var memoryStream = new MemoryStream();
                await section.Body.CopyToAsync(memoryStream, ct);
                memoryStream.Position = 0;
                
                try 
                {
                    var file = await DicomFile.OpenAsync(memoryStream);
                    dicomFiles.Add(file);
                }
                catch
                {
                    // Ignore non-dicom parts or errors? 
                    // Better to propagate or log. For now, strict.
                    throw; 
                }
            }
            return dicomFiles.ToArray();
        }
        else if (contentType != null && contentType.MediaType.Equals("application/dicom", StringComparison.OrdinalIgnoreCase))
        {
            // Single instance response
            using var stream = await content.ReadAsStreamAsync(ct);
            using var ms = new MemoryStream();
            await stream.CopyToAsync(ms, ct);
            ms.Position = 0;
            return new[] { await DicomFile.OpenAsync(ms) };
        }
        
        throw new HttpRequestException($"Unexpected Content-Type: {contentType?.MediaType}");
    }

    private string GetBoundary(MediaTypeHeaderValue contentType)
    {
        var boundary = contentType.Parameters.FirstOrDefault(x => x.Name.Equals("boundary", StringComparison.OrdinalIgnoreCase))?.Value;
        
        if (string.IsNullOrWhiteSpace(boundary))
        {
             throw new InvalidOperationException("Missing boundary in multipart response.");
        }
        
        if (boundary.Length > 1 && boundary.StartsWith("\"") && boundary.EndsWith("\""))
        {
            boundary = boundary.Substring(1, boundary.Length - 2);
        }
        
        return boundary;
    }
}
