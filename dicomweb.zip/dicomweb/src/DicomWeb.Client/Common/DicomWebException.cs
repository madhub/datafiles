using System;
using System.Net;

namespace DicomWeb.Client;

/// <summary>
/// Represents errors that occur during DICOMweb operations, such as partial failures or protocol status errors.
/// </summary>
public class DicomWebException : Exception
{
    public HttpStatusCode StatusCode { get; }

    public DicomWebException(string message, HttpStatusCode statusCode) 
        : base(message)
    {
        StatusCode = statusCode;
    }

    public DicomWebException(string message, HttpStatusCode statusCode, Exception inner) 
        : base(message, inner)
    {
        StatusCode = statusCode;
    }
}
