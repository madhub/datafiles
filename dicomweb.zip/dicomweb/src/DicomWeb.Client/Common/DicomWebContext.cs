using System;
using DicomWeb.Client.Auth;

namespace DicomWeb.Client.Common;

/// <summary>
/// Encapsulates the per-request context required to execute a DICOMweb operation.
/// </summary>
/// <param name="BaseServiceUrl">The base URL of the DICOMweb service (e.g., https://dicom-provider.com/studies).</param>
/// <param name="AuthProvider">The authentication provider to use for this request.</param>
public record DicomWebContext(Uri BaseServiceUrl, IAuthProvider AuthProvider);
