using System;

namespace DicomWeb.Client.Common;

/// <summary>
/// Helper for constructing standard DICOMweb URIs.
/// </summary>
public static class DicomWebUriBuilder
{
    public static Uri BuildRetrieveStudyUri(Uri baseUri, string studyInstanceUid)
    {
        return AppendPath(baseUri, $"studies/{studyInstanceUid}");
    }

    public static Uri BuildQueryStudiesUri(Uri baseUri, string? queryString)
    {
        return AppendPath(baseUri, "studies", queryString);
    }

    public static Uri BuildQuerySeriesUri(Uri baseUri, string studyInstanceUid, string? queryString)
    {
        return AppendPath(baseUri, $"studies/{studyInstanceUid}/series", queryString);
    }

    public static Uri BuildQueryInstancesUri(Uri baseUri, string studyInstanceUid, string seriesInstanceUid, string? queryString)
    {
        return AppendPath(baseUri, $"studies/{studyInstanceUid}/series/{seriesInstanceUid}/instances", queryString);
    }

    public static Uri BuildRetrieveSeriesUri(Uri baseUri, string studyInstanceUid, string seriesInstanceUid)
    {
        return AppendPath(baseUri, $"studies/{studyInstanceUid}/series/{seriesInstanceUid}");
    }

    public static Uri BuildRetrieveInstanceUri(Uri baseUri, string studyInstanceUid, string seriesInstanceUid, string sopInstanceUid)
    {
        return AppendPath(baseUri, $"studies/{studyInstanceUid}/series/{seriesInstanceUid}/instances/{sopInstanceUid}");
    }

    public static Uri BuildRetrieveFramesUri(Uri baseUri, string studyInstanceUid, string seriesInstanceUid, string sopInstanceUid, int[] frames)
    {
        var frameList = string.Join(",", frames);
        return AppendPath(baseUri, $"studies/{studyInstanceUid}/series/{seriesInstanceUid}/instances/{sopInstanceUid}/frames/{frameList}");
    }
    
    public static Uri BuildRetrieveStudyMetadataUri(Uri baseUri, string studyInstanceUid)
    {
        return AppendPath(baseUri, $"studies/{studyInstanceUid}/metadata");
    }

    public static Uri BuildRetrieveSeriesMetadataUri(Uri baseUri, string studyInstanceUid, string seriesInstanceUid)
    {
        return AppendPath(baseUri, $"studies/{studyInstanceUid}/series/{seriesInstanceUid}/metadata");
    }

    public static Uri BuildRetrieveInstanceMetadataUri(Uri baseUri, string studyInstanceUid, string seriesInstanceUid, string sopInstanceUid)
    {
        return AppendPath(baseUri, $"studies/{studyInstanceUid}/series/{seriesInstanceUid}/instances/{sopInstanceUid}/metadata");
    }

    public static Uri BuildStoreUri(Uri baseUri, string? studyInstanceUid = null)
    {
        if (!string.IsNullOrWhiteSpace(studyInstanceUid))
        {
            return AppendPath(baseUri, $"studies/{studyInstanceUid}");
        }
        return AppendPath(baseUri, "studies");
    }

    private static Uri AppendPath(Uri baseUri, string relativePath, string? queryString = null)
    {
        var baseStr = baseUri.ToString().TrimEnd('/');
        
        // Handle if baseUri already contains the "resource" path like "studies" IF the relative path duplicates it?
        // No, we decided previously that we append assuming base is "Service Root".
        // BUT we had logic to detect if "studies" was already there.
        // Let's keep that logic consistent but generalized.
        
        // Simpler approach: normalize base to NOT have trailing slash.
        // If specific relative path segment starts with what base ends with, avoid duplication? 
        // Too complex. Let's assume standard behavior: Base + Relative.
        // Exception: User put ".../studies" as base.
        
        if (baseStr.EndsWith("/studies", StringComparison.OrdinalIgnoreCase))
        {
            // If we are appending "studies" (search studies), we just use base + Query.
            if (relativePath.Equals("studies", StringComparison.OrdinalIgnoreCase))
            {
                return CreateUri(baseStr, queryString);
            }
            
            // If we are appending "studies/{uid}"... existing logic:
            if (relativePath.StartsWith("studies/", StringComparison.OrdinalIgnoreCase))
            {
                 // Replace "studies/" in relative with ""? No.
                 // "base/studies" + "studies/123" -> double studies.
                 // remove "studies" from relative.
                 relativePath = relativePath.Substring(8); // "studies/".Length
            }
        }
        
        return CreateUri($"{baseStr}/{relativePath}", queryString);
    }
    
    private static Uri CreateUri(string path, string? query)
    {
        if (string.IsNullOrEmpty(query)) return new Uri(path);
        // Ensure query starts with ?
        if (!query.StartsWith("?")) query = "?" + query;
        return new Uri(path + query);
    }
}
