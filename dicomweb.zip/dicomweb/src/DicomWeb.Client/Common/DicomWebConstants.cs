namespace DicomWeb.Client.Common;

public static class DicomWebConstants
{
    /// <summary>
    /// The key used to store the DicomWebContext in HttpRequestMessage.Options.
    /// </summary>
    public const string ContextOptionsKey = "DicomWebContext";
}
