using Microsoft.VisualStudio.TestTools.UnitTesting;
using NSubstitute;
using DicomWeb.Client;
using DicomWeb.Client.Common;
using DicomWeb.Client.Auth;
using System;
using System.Net.Http;
using System.Threading.Tasks;
using System.Net;
using DicomWeb.Client.Tests.Helpers;
using FellowOakDicom;

namespace DicomWeb.Client.Tests;

[TestClass]
public class StowValidationTests
{
    private DicomWebContext _context;

    [TestInitialize]
    public void Setup()
    {
        var auth = Substitute.For<IAuthProvider>();
        _context = new DicomWebContext(new Uri("http://localhost"), auth);
    }

    [TestMethod]
    public async Task StoreAsync_ShouldThrowDicomWebException_OnPartialFailure()
    {
        // Assemble
        var factory = Substitute.For<IHttpClientFactory>();
        
        // Mock a 202 Accepted response with Failed SOP Sequence in JSON body
        var responseJson = @"[
            {
                ""00081198"": { ""vr"": ""SQ"", ""Value"": [ { ""00081150"": { ""vr"": ""UI"", ""Value"": [""1.2.3""] } } ] }
            }
        ]";

        var handler = new MockHttpMessageHandler((req, ct) => {
             return new HttpResponseMessage(HttpStatusCode.Accepted) { 
                 Content = new StringContent(responseJson, System.Text.Encoding.UTF8, "application/dicom+json") 
             };
        });

        var httpClient = new HttpClient(handler) { BaseAddress = new Uri("http://localhost") };
        factory.CreateClient("DicomWebClient").Returns(httpClient);
        
        var service = new DicomWebClient(factory);

        var dataset = new DicomDataset();
        dataset.Add(DicomTag.SOPClassUID, DicomUID.SecondaryCaptureImageStorage);
        dataset.Add(DicomTag.SOPInstanceUID, "1.2.3");
        var file = new DicomFile(dataset);

        // Act & Assert
        try 
        {
            await service.StoreAsync(_context, new [] { file });
            Assert.Fail("Should have thrown DicomWebException");
        }
        catch (DicomWebException ex)
        {
            Assert.AreEqual(HttpStatusCode.Accepted, ex.StatusCode);
        }
    }
}
