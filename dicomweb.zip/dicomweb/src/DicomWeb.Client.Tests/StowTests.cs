using Microsoft.VisualStudio.TestTools.UnitTesting;
using NSubstitute;
using DicomWeb.Client;
using DicomWeb.Client.Common;
using DicomWeb.Client.Auth;
using System;
using System.Net.Http;
using System.Threading.Tasks;
using System.Net;
using DicomWeb.Client.Tests.Helpers;
using FellowOakDicom;
using System.Linq;
using System.Collections.Generic;

namespace DicomWeb.Client.Tests;

[TestClass]
public class StowTests
{
    [TestMethod]
    public async Task StoreAsync_ShouldPostMultipartContent()
    {
        // Assemble
        var factory = Substitute.For<IHttpClientFactory>();
        var authProvider = Substitute.For<IAuthProvider>();
        var context = new DicomWebContext(new Uri("http://localhost/dicom"), authProvider);
        
        var handler = new MockHttpMessageHandler(async (req, ct) => {
            if (req.Method != HttpMethod.Post) return new HttpResponseMessage(HttpStatusCode.MethodNotAllowed);
            if (!req.Content.Headers.ContentType.MediaType.Equals("multipart/related")) 
                 return new HttpResponseMessage(HttpStatusCode.UnsupportedMediaType);
            
             // Read content to verify
             var body = await req.Content.ReadAsStringAsync();
             if (!body.Contains("DICOM_BOUNDARY_")) return new HttpResponseMessage(HttpStatusCode.BadRequest);

             return new HttpResponseMessage(HttpStatusCode.OK) { 
                 Content = new StringContent("[]", System.Text.Encoding.UTF8, "application/dicom+json") 
             };
        });
        
        var httpClient = new HttpClient(handler) { BaseAddress = new Uri("http://localhost/dicom") };
        factory.CreateClient("DicomWebClient").Returns(httpClient);
        
        var service = new DicomWebClient(factory);
        var dataset = new DicomDataset();
        dataset.Add(DicomTag.SOPClassUID, DicomUID.SecondaryCaptureImageStorage);
        dataset.Add(DicomTag.SOPInstanceUID, "1.2.3");
        var file = new DicomFile(dataset);

        // Act
        var result = await service.StoreAsync(context, new [] { file });

        // Assert
        Assert.IsNotNull(result);
    }
}
