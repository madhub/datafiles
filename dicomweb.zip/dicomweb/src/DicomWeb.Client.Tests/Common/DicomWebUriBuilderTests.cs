using Microsoft.VisualStudio.TestTools.UnitTesting;
using DicomWeb.Client.Common;
using System;

namespace DicomWeb.Client.Tests.Common;

[TestClass]
public class DicomWebUriBuilderTests
{
    [TestMethod]
    [DataRow("https://server/dicom-web/studies", "1.2.3", "https://server/dicom-web/studies/1.2.3")]
    [DataRow("https://server/dicom-web/studies/", "1.2.3", "https://server/dicom-web/studies/1.2.3")]
    [DataRow("https://server/dicom-web", "1.2.3", "https://server/dicom-web/studies/1.2.3")]
    [DataRow("https://server/dicom-web/", "1.2.3", "https://server/dicom-web/studies/1.2.3")]
    public void BuildRetrieveStudyUri_ShouldConstructCorrectUri(string baseUri, string studyUid, string expected)
    {
        var result = DicomWebUriBuilder.BuildRetrieveStudyUri(new Uri(baseUri), studyUid);
        Assert.AreEqual(expected, result.ToString());
    }
}
