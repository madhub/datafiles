using Microsoft.VisualStudio.TestTools.UnitTesting;
using NSubstitute;
using DicomWeb.Client;
using DicomWeb.Client.Common;
using DicomWeb.Client.Auth;
using System;
using System.Net.Http;
using System.Threading.Tasks;
using System.Threading;
using System.Net;
using DicomWeb.Client.Tests.Helpers;

namespace DicomWeb.Client.Tests;

[TestClass]
public class DicomWebClientTests
{
    [TestMethod]
    public async Task RetrieveStudyAsync_ShouldUseClientFactoryAndContext()
    {
        // Assemble
        var factory = Substitute.For<IHttpClientFactory>();
        var authProvider = Substitute.For<IAuthProvider>();
        var context = new DicomWebContext(new Uri("http://localhost/dicom"), authProvider);
        
        // Mock Handler
        var handler = new MockHttpMessageHandler((req, ct) => {
            // Assert Context is present
            if (!req.Options.TryGetValue(new HttpRequestOptionsKey<DicomWebContext>(DicomWebConstants.ContextOptionsKey), out var ctx) || ctx != context)
                return new HttpResponseMessage(HttpStatusCode.BadRequest);
                
            var content = new StringContent("");
            content.Headers.ContentType = new System.Net.Http.Headers.MediaTypeHeaderValue("application/dicom");
            return new HttpResponseMessage(HttpStatusCode.OK) { Content = content };
        });
        
        var httpClient = new HttpClient(handler) { BaseAddress = new Uri("http://localhost/dicom") };
        factory.CreateClient("DicomWebClient").Returns(httpClient);
        
        var service = new DicomWebClient(factory);
        
        // Act
        // We expect it to try to parse dicom from empty content, which might throw in DicomFile.OpenAsync usually,
        // but for this test we just want to verify the Request setup. 
        // We'll trust DicomFile exception means success of flow.
        try 
        {
            await service.RetrieveStudyAsync(context, "1.2.3");
        }
        catch (FellowOakDicom.DicomDataException) 
        {
            // Expected partial failure due to empty stream
        }
        catch (Exception ex)
        {
            // If Bad Request returned by mock
            if (ex.Message.Contains("400")) Assert.Fail("Context not passed to request options");
            // Ignore other parsing errors
        }

        // Assert
        factory.Received(1).CreateClient("DicomWebClient");
    }
}
