using Microsoft.VisualStudio.TestTools.UnitTesting;
using NSubstitute;
using DicomWeb.Client;
using DicomWeb.Client.Common;
using DicomWeb.Client.Auth;
using System;
using System.Net.Http;
using System.Threading.Tasks;
using System.Net;
using DicomWeb.Client.Tests.Helpers;

namespace DicomWeb.Client.Tests;

[TestClass]
public class ResilienceTests
{
    private DicomWebContext _context;

    [TestInitialize]
    public void Setup()
    {
        var auth = Substitute.For<IAuthProvider>();
        _context = new DicomWebContext(new Uri("http://localhost"), auth);
    }

    [TestMethod]
    public async Task RetrieveStudyAsync_ShouldThrowOn404()
    {
        // Assemble
        var factory = Substitute.For<IHttpClientFactory>();
        var handler = new MockHttpMessageHandler((req, ct) => new HttpResponseMessage(HttpStatusCode.NotFound));
        
        var httpClient = new HttpClient(handler) { BaseAddress = new Uri("http://localhost") };
        factory.CreateClient("DicomWebClient").Returns(httpClient);
        
        var service = new DicomWebClient(factory);

        // Act
        try
        {
            await service.RetrieveStudyAsync(_context, "1.2.3");
            Assert.Fail("Should have thrown HttpRequestException");
        }
        catch (HttpRequestException) { }
    }

    [TestMethod]
    public async Task QueryStudiesAsync_ShouldThrowOn500()
    {
        // Assemble
        var factory = Substitute.For<IHttpClientFactory>();
        var handler = new MockHttpMessageHandler((req, ct) => new HttpResponseMessage(HttpStatusCode.InternalServerError));
        
        var httpClient = new HttpClient(handler) { BaseAddress = new Uri("http://localhost") };
        factory.CreateClient("DicomWebClient").Returns(httpClient);
        
        var service = new DicomWebClient(factory);

        // Act
        try
        {
            await service.QueryStudiesAsync(_context, new QidoRequest());
            Assert.Fail("Should have thrown HttpRequestException");
        }
        catch (HttpRequestException) { }
    }

    [TestMethod]
    public async Task RetrieveStudyAsync_ShouldThrowOnTimeout()
    {
        // Assemble
        var factory = Substitute.For<IHttpClientFactory>();
        var handler = new MockHttpMessageHandler(async (req, ct) => {
            await Task.Delay(500, ct); 
            return new HttpResponseMessage(HttpStatusCode.OK);
        });
        
        var httpClient = new HttpClient(handler) { BaseAddress = new Uri("http://localhost") };
        factory.CreateClient("DicomWebClient").Returns(httpClient);
        
        var service = new DicomWebClient(factory);

        // Act
        using var cts = new System.Threading.CancellationTokenSource(100); 
        try
        {
            await service.RetrieveStudyAsync(_context, "1.2.3", cts.Token);
            Assert.Fail("Should have thrown OperationCanceledException");
        }
        catch (OperationCanceledException) { }
    }

    [TestMethod]
    public async Task RetrieveStudyAsync_ShouldThrowOnMissingUid()
    {
        var factory = Substitute.For<IHttpClientFactory>();
        var service = new DicomWebClient(factory);
        try
        {
            await service.RetrieveStudyAsync(_context, "");
            Assert.Fail("Should have thrown ArgumentException");
        }
        catch (ArgumentException) { }
    }
}
