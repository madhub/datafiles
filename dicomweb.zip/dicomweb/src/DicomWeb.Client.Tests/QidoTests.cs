using Microsoft.VisualStudio.TestTools.UnitTesting;
using NSubstitute;
using DicomWeb.Client;
using DicomWeb.Client.Common;
using DicomWeb.Client.Auth;
using System;
using System.Net.Http;
using System.Threading.Tasks;
using System.Net;
using DicomWeb.Client.Tests.Helpers;
using FellowOakDicom;
using System.Linq;

namespace DicomWeb.Client.Tests;

[TestClass]
public class QidoTests
{
    [TestMethod]
    public async Task QueryStudiesAsync_ShouldBuildUriAndParseResponse()
    {
        // Assemble
        var factory = Substitute.For<IHttpClientFactory>();
        var authProvider = Substitute.For<IAuthProvider>();
        var context = new DicomWebContext(new Uri("http://localhost/dicom"), authProvider);
        
        var jsonResponse = "[{\"00080050\": { \"vr\": \"SH\", \"Value\": [ \"1.2.3.4\" ] } }]";
        
        var handler = new MockHttpMessageHandler((req, ct) => {
            if (!req.RequestUri.ToString().Contains("/studies"))
                return new HttpResponseMessage(HttpStatusCode.NotFound);
                
            return new HttpResponseMessage(HttpStatusCode.OK) 
            { 
                Content = new StringContent(jsonResponse, System.Text.Encoding.UTF8, "application/dicom+json") 
            };
        });
        
        var httpClient = new HttpClient(handler) { BaseAddress = new Uri("http://localhost/dicom") };
        factory.CreateClient("DicomWebClient").Returns(httpClient);
        
        var service = new DicomWebClient(factory);
        
        // Act
        var result = await service.QueryStudiesAsync(context, new QidoRequest { Limit = 10 });

        // Assert
        Assert.IsNotNull(result);
        Assert.AreEqual(1, result.Count());
        Assert.AreEqual("1.2.3.4", result.First().GetSingleValue<string>(DicomTag.AccessionNumber));
    }
}
