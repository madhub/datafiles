using Microsoft.VisualStudio.TestTools.UnitTesting;
using DicomWeb.Client;
using System.Collections.Generic;
using System;
using FellowOakDicom;

namespace DicomWeb.Client.Tests;

[TestClass]
public class QidoPatternTests
{
    private string GetQuery(QidoRequest req) => req.ToQueryString();

    [TestMethod]
    public void Pattern1_PatientID()
    {
        // http://dicomrs/studies?PatientID=11235813
        var req = new QidoRequest();
        req.AddFilter("PatientID", "11235813");
        
        Assert.AreEqual("PatientID=11235813", GetQuery(req));
    }

    [TestMethod]
    public void Pattern2_PatientID_And_StudyDate()
    {
        // http://dicomrs/studies?PatientID=11235813&StudyDate=20130509
        var req = new QidoRequest();
        req.AddFilter("PatientID", "11235813");
        req.AddFilter("StudyDate", "20130509");

        var q = GetQuery(req);
        // Order is not guaranteed in Dictionary, but small count usually consistent or check contains
        Assert.IsTrue(q.Contains("PatientID=11235813"));
        Assert.IsTrue(q.Contains("StudyDate=20130509"));
    }

    [TestMethod]
    public void Pattern3_Tags_SequencePath_Limit()
    {
        // http://dicomrs/studies?00100010=SMITH*&00101002.00100020=11235813&limit=25
        var req = new QidoRequest { Limit = 25 };
        // 00100010 is PatientName
        req.AddFilter("00100010", "SMITH*");
        req.AddFilter("00101002.00100020", "11235813");

        var q = GetQuery(req);
        Assert.IsTrue(q.Contains("limit=25"));
        var encodedValue = System.Text.Encodings.Web.UrlEncoder.Default.Encode("SMITH*");
        Assert.IsTrue(q.Contains($"00100010={encodedValue}")); 
        Assert.IsTrue(q.Contains("00101002.00100020=11235813"));
    }

    [TestMethod]
    public void Pattern4_Tag_KeywordSequencePath()
    {
        // http://dicomrs/studies?00100010=SMITH*&OtherPatientIDsSequence.00100020=11235813
        var req = new QidoRequest();
        req.AddFilter("00100010", "SMITH*");
        req.AddFilter("OtherPatientIDsSequence.00100020", "11235813");

        var q = GetQuery(req);
        var encodedValue = System.Text.Encodings.Web.UrlEncoder.Default.Encode("SMITH*");
        Assert.IsTrue(q.Contains($"00100010={encodedValue}"));
        Assert.IsTrue(q.Contains("OtherPatientIDsSequence.00100020=11235813"));
    }

    [TestMethod]
    public void Pattern5_IncludeFields()
    {
        // http://dicomrs/studies?PatientID=11235813&includefield=00081048&includefield=00081049&includefield=00081060
        var req = new QidoRequest();
        req.AddFilter("PatientID", "11235813");
        req.IncludeFields.Add("00081048");
        req.IncludeFields.Add("00081049");
        req.IncludeFields.Add("00081060");

        var q = GetQuery(req);
        Assert.IsTrue(q.Contains("PatientID=11235813"));
        Assert.IsTrue(q.Contains("includefield=00081048"));
        Assert.IsTrue(q.Contains("includefield=00081049"));
        Assert.IsTrue(q.Contains("includefield=00081060"));
    }

    [TestMethod]
    public void Pattern6_DateRange()
    {
        // http://dicomrs/studies?PatientID=11235813&StudyDate=20130509-20130510
        var req = new QidoRequest();
        req.AddFilter("PatientID", "11235813");
        req.AddFilter("StudyDate", "20130509-20130510");

        var q = GetQuery(req);
        Assert.IsTrue(q.Contains("StudyDate=20130509-20130510"));
    }

    [TestMethod]
    public void Pattern7_MultiValue()
    {
        // http://dicomrs/studies?StudyInstanceUID=1.2...%2c1.2...
        var req = new QidoRequest();
        var uid1 = "1.2.392.200036.9116.2.2.2.2162893313.1029997326.94587";
        var uid2 = "1.2.392.200036.9116.2.2.2.2162893313.1029997326.94583";
        // User responsibility to join with comma for OR matching
        req.AddFilter("StudyInstanceUID", $"{uid1},{uid2}");

        var q = GetQuery(req);
        Assert.IsTrue(q.Contains($"StudyInstanceUID={System.Text.Encodings.Web.UrlEncoder.Default.Encode(uid1 + "," + uid2)}"));
    }
}
