# Common DICOMweb API Client – Design Overview

## 1. Objective

Design and implement a **common, extensible DICOMweb API client** that can interact with multiple DICOMweb service providers while abstracting provider-specific concerns such as:
- Endpoint structure
- Authentication & authorization
- Tenant identification
- Resiliency behavior

The solution must prioritize **readability, maintainability, and testability**, and be built using **.NET 8 and C# 12**.

---

## 2. Supported DICOMweb Providers

### 2.1 Amazon HealthImaging (AHI)

- **Base URL Pattern**  
https://dicom-medical-imaging.{region}.amazonaws.com/datastore/{datastore-id}/studies
- **Tenant Identifier**
- `{datastore-id}` injected per request
- **Authentication & Authorization**
- AWS **SigV4** signing
- Requires AWS credentials per request
- **Key Characteristics**
- Region-specific endpoint
- Request signing must occur at HTTP pipeline level

---

### 2.2 Orthanc DICOMweb

- **Base URL Pattern**
http://localhost:8042/dicom-web/{organizationId}/studies
- **Tenant Identifier**
- `{organizationId}` identifies the tenant
- **Authentication & Authorization**
- Bearer token (JWT or opaque token)
- **Key Characteristics**
- Multi-tenant via URL path
- Simple header-based authentication

---

## 3. Core Quality Attributes

| Attribute        | Description |
|------------------|-------------|
| Readability      | Clear separation of concerns and intuitive APIs |
| Maintainability  | Provider-specific logic isolated and extensible |
| Testability      | Fully unit-testable via dependency inversion and mocks |
| Resilience       | Automatic handling of transient HTTP failures |

---

## 4. Technical Constraints & Standards

- **Runtime & Language**
- .NET 8
- C# 12
- **DICOM Parsing**
- [`fo-dicom`](https://github.com/fo-dicom/fo-dicom) for all DICOM-related operations
- **Dependency Injection**
- Must integrate with `Microsoft.Extensions.DependencyInjection`
- **HTTP Resilience**
- Use `Microsoft.Extensions.Http.Resilience`

---

## 5. Resiliency Requirements

The HTTP client must implement resilient communication patterns using:

- Automatic retries for transient failures
- Timeouts
- Circuit breakers (where appropriate)
- Configurable policies per provider

Reference:
- [Build resilient HTTP apps](https://learn.microsoft.com/en-us/dotnet/core/resilience/http-resilience)

---

## 6. Tenant & Authorization Handling

### 6.1 Per-Request Context

The design must allow **tenant and authorization details to be provided per request**, not statically at startup.

Examples:
- **Amazon HealthImaging**
- `datastoreId`
- AWS credentials (Access Key, Secret Key, optional Session Token)
- Region
- **Orthanc**
- `organizationId`
- Bearer token

This enables:
- True multi-tenancy
- Safe parallel processing across tenants
- Use in stateless execution environments

---

## 7. Application Hosting Scenarios

### 7.1 ASP.NET Core 8

- Tenant details extracted from:
- Route parameters
- Headers
- Claims or middleware context
- Client invoked within controllers or minimal APIs

### 7.2 Console / Worker Service

- Hosted using `.NET Worker Service`
- Tenant details sourced from:
- Queue messages
- Event payloads
- Batch jobs
- Supports high-throughput background processing

Reference:
- [Worker Services in .NET](https://learn.microsoft.com/en-us/dotnet/core/extensions/workers)

---

## 8. High-Level Architectural Approach

### 8.1 Key Abstractions

- **IDicomWebClient**
- Provider-agnostic interface for DICOMweb operations
- **Provider-Specific Implementations**
- Amazon HealthImaging client
- Orthanc client
- **Request Context Object**
- Encapsulates tenant and authorization data
- **Authentication Handlers**
- AWS SigV4 delegating handler
- Bearer token delegating handler
- **HttpClient Factory**
- Configured with resilience policies and message handlers

---

## 9. Testability Strategy

- Provider logic isolated behind interfaces
- Authentication logic encapsulated in HTTP message handlers
- `HttpMessageHandler` mocked for unit tests
- No hard dependency on static credentials or environment variables

---

## 10. Non-Goals (Out of Scope)

- UI or visualization components
- PACS server implementation
- DICOM storage persistence layer
- Provider-specific admin or management APIs

---

## 11. References

- **HTTP Resilience**
- https://learn.microsoft.com/en-us/dotnet/core/resilience/http-resilience
- **Worker Services**
- https://learn.microsoft.com/en-us/dotnet/core/extensions/workers
- **fo-dicom**
- https://github.com/fo-dicom/fo-dicom

---

## 12. Summary

This design enables a **clean, resilient, and extensible DICOMweb client** capable of working across multiple providers with differing authentication and tenancy models, while remaining:
- Cloud-agnostic
- Highly testable
- Suitable for both web and background processing workloads
- Aligned with modern .NET 8 best practices
