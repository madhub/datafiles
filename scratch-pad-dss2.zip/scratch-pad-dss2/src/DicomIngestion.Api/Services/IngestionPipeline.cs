using System.Collections.Concurrent;
using System.Diagnostics;
using DicomIngestion.Api.Models;
using Microsoft.Extensions.Options;

namespace DicomIngestion.Api.Services;

public class IngestionPipeline : IIngestionPipeline
{
    private readonly IS3StorageService _s3Service;
    private readonly IDicomMetadataReader _metadataReader;
    private readonly MinioOptions _minioOptions;
    private readonly IngestionOptions _ingestionOptions;
    private readonly ILogger<IngestionPipeline> _logger;

    public IngestionPipeline(
        IS3StorageService s3Service,
        IDicomMetadataReader metadataReader,
        IOptions<MinioOptions> minioOptions,
        IOptions<IngestionOptions> ingestionOptions,
        ILogger<IngestionPipeline> logger)
    {
        _s3Service = s3Service;
        _metadataReader = metadataReader;
        _minioOptions = minioOptions.Value;
        _ingestionOptions = ingestionOptions.Value;
        _logger = logger;
    }

    /// <summary>
    /// Mode 1: Bulk unsegregated ingestion. Dynamically discovers, parses, and partitions by Series.
    /// </summary>
    public async Task<IngestResponse> IngestBulkAsync(BulkIngestRequest request, CancellationToken ct = default)
    {
        var totalSw = Stopwatch.StartNew();
        var (sourceBucket, destBucket, concurrency) = ResolveDefaults(request);

        var response = CreateBaseResponse(request.TenantId, "BulkUnsegregated", sourceBucket, destBucket, concurrency);
        await _s3Service.EnsureBucketExistsAsync(destBucket, ct);

        // Discovery
        var discoverySw = Stopwatch.StartNew();
        var s3Objects = await _s3Service.ListObjectsAsync(sourceBucket, request.SourcePrefix, ct);
        discoverySw.Stop();

        response.Metrics.DiscoveryDurationMs = Math.Round(discoverySw.Elapsed.TotalMilliseconds, 2);
        response.Metrics.FilesDiscovered = s3Objects.Count;

        if (s3Objects.Count == 0)
        {
            totalSw.Stop();
            response.Success = true;
            response.Metrics.TotalDurationMs = Math.Round(totalSw.Elapsed.TotalMilliseconds, 2);
            return response;
        }

        var accumulator = new IngestionAccumulator();
        var processingSw = Stopwatch.StartNew();

        var parallelOptions = new ParallelOptions { MaxDegreeOfParallelism = concurrency, CancellationToken = ct };
        await Parallel.ForEachAsync(s3Objects, parallelOptions, async (item, token) =>
        {
            await ProcessInstanceAsync(request.TenantId, sourceBucket, destBucket, item, null, null, request.UseByteRangeForHeader, accumulator, token);
        });

        processingSw.Stop();
        response.Metrics.ProcessingDurationMs = Math.Round(processingSw.Elapsed.TotalMilliseconds, 2);

        // Group into Series Processing Units and generate factored manifests
        var manifestSw = Stopwatch.StartNew();
        var seriesManifests = new List<SeriesManifest>();

        if (!accumulator.ParsedRecords.IsEmpty)
        {
            var seriesGroups = accumulator.ParsedRecords
                .GroupBy(r => (r.Study.StudyInstanceUid, r.Series.SeriesInstanceUid));

            foreach (var seriesGroup in seriesGroups)
            {
                var manifest = await BuildAndPersistSeriesManifestAsync(
                    request.TenantId, destBucket, seriesGroup.ToList(), request.GenerateManifests, ct);
                seriesManifests.Add(manifest);
            }
        }

        manifestSw.Stop();
        response.Metrics.ManifestDurationMs = Math.Round(manifestSw.Elapsed.TotalMilliseconds, 2);

        totalSw.Stop();
        FinalizeResponse(response, seriesManifests, accumulator, totalSw.Elapsed.TotalMilliseconds);
        return response;
    }

    /// <summary>
    /// Mode 2: Pre-segregated single series ingestion. Bypasses segregation completely.
    /// </summary>
    public async Task<IngestResponse> IngestSeriesAsync(SeriesIngestRequest request, CancellationToken ct = default)
    {
        var totalSw = Stopwatch.StartNew();
        var (sourceBucket, destBucket, concurrency) = ResolveDefaults(request);

        var response = CreateBaseResponse(request.TenantId, "PreSegregatedSeries", sourceBucket, destBucket, concurrency);
        await _s3Service.EnsureBucketExistsAsync(destBucket, ct);

        // Discovery for this specific series prefix
        var discoverySw = Stopwatch.StartNew();
        var s3Objects = await _s3Service.ListObjectsAsync(sourceBucket, request.SourcePrefix, ct);
        discoverySw.Stop();

        response.Metrics.DiscoveryDurationMs = Math.Round(discoverySw.Elapsed.TotalMilliseconds, 2);
        response.Metrics.FilesDiscovered = s3Objects.Count;

        if (s3Objects.Count == 0)
        {
            totalSw.Stop();
            response.Success = true;
            response.Metrics.TotalDurationMs = Math.Round(totalSw.Elapsed.TotalMilliseconds, 2);
            return response;
        }

        var accumulator = new IngestionAccumulator();
        var processingSw = Stopwatch.StartNew();

        var parallelOptions = new ParallelOptions { MaxDegreeOfParallelism = concurrency, CancellationToken = ct };
        await Parallel.ForEachAsync(s3Objects, parallelOptions, async (item, token) =>
        {
            await ProcessInstanceAsync(
                request.TenantId,
                sourceBucket,
                destBucket,
                item,
                request.StudyInstanceUid,
                request.SeriesInstanceUid,
                request.UseByteRangeForHeader,
                accumulator,
                token
            );
        });

        processingSw.Stop();
        response.Metrics.ProcessingDurationMs = Math.Round(processingSw.Elapsed.TotalMilliseconds, 2);

        // Directly build factored manifest without any grouping overhead
        var manifestSw = Stopwatch.StartNew();
        var seriesManifests = new List<SeriesManifest>();

        if (!accumulator.ParsedRecords.IsEmpty)
        {
            var manifest = await BuildAndPersistSeriesManifestAsync(
                request.TenantId, destBucket, accumulator.ParsedRecords.ToList(), request.GenerateManifests, ct);
            seriesManifests.Add(manifest);
        }

        manifestSw.Stop();
        response.Metrics.ManifestDurationMs = Math.Round(manifestSw.Elapsed.TotalMilliseconds, 2);

        totalSw.Stop();
        FinalizeResponse(response, seriesManifests, accumulator, totalSw.Elapsed.TotalMilliseconds);
        return response;
    }

    /// <summary>
    /// Mode 3: Pre-segregated study with mapped series folders. Processes series units concurrently.
    /// </summary>
    public async Task<IngestResponse> IngestStudyAsync(StudyIngestRequest request, CancellationToken ct = default)
    {
        var totalSw = Stopwatch.StartNew();
        var (sourceBucket, destBucket, concurrency) = ResolveDefaults(request);

        var response = CreateBaseResponse(request.TenantId, "PreSegregatedStudyWithSeries", sourceBucket, destBucket, concurrency);
        await _s3Service.EnsureBucketExistsAsync(destBucket, ct);

        var accumulator = new IngestionAccumulator();
        var seriesManifests = new ConcurrentBag<SeriesManifest>();

        var discoverySw = Stopwatch.StartNew();
        var seriesFolderTasks = new List<(SeriesFolderMapping Mapping, List<S3ObjectItem> Objects)>();

        foreach (var mapping in request.Series)
        {
            var items = await _s3Service.ListObjectsAsync(sourceBucket, mapping.SourcePrefix, ct);
            seriesFolderTasks.Add((mapping, items));
        }
        discoverySw.Stop();

        var totalDiscovered = seriesFolderTasks.Sum(x => x.Objects.Count);
        response.Metrics.DiscoveryDurationMs = Math.Round(discoverySw.Elapsed.TotalMilliseconds, 2);
        response.Metrics.FilesDiscovered = totalDiscovered;

        if (totalDiscovered == 0)
        {
            totalSw.Stop();
            response.Success = true;
            response.Metrics.TotalDurationMs = Math.Round(totalSw.Elapsed.TotalMilliseconds, 2);
            return response;
        }

        var processingSw = Stopwatch.StartNew();
        var parallelOptions = new ParallelOptions { MaxDegreeOfParallelism = concurrency, CancellationToken = ct };

        // Process each series mapping concurrently
        await Parallel.ForEachAsync(seriesFolderTasks, parallelOptions, async (seriesTask, token) =>
        {
            var seriesAccumulator = new IngestionAccumulator();
            var (mapping, items) = seriesTask;

            await Parallel.ForEachAsync(items, parallelOptions, async (item, itemToken) =>
            {
                await ProcessInstanceAsync(
                    request.TenantId,
                    sourceBucket,
                    destBucket,
                    item,
                    request.StudyInstanceUid,
                    mapping.SeriesInstanceUid,
                    request.UseByteRangeForHeader,
                    seriesAccumulator,
                    itemToken
                );
            });

            // Merge accumulator metrics
            accumulator.Merge(seriesAccumulator);

            if (!seriesAccumulator.ParsedRecords.IsEmpty)
            {
                var manifest = await BuildAndPersistSeriesManifestAsync(
                    request.TenantId, destBucket, seriesAccumulator.ParsedRecords.ToList(), request.GenerateManifests, token);
                seriesManifests.Add(manifest);
            }
        });

        processingSw.Stop();
        response.Metrics.ProcessingDurationMs = Math.Round(processingSw.Elapsed.TotalMilliseconds, 2);

        totalSw.Stop();
        FinalizeResponse(response, seriesManifests.OrderBy(s => s.Series.SeriesNumber).ToList(), accumulator, totalSw.Elapsed.TotalMilliseconds);
        return response;
    }

    /// <summary>
    /// Unified entry point: Automatically routes based on request payload.
    /// </summary>
    public Task<IngestResponse> ExecuteIngestionAsync(IngestRequest request, CancellationToken ct = default)
    {
        if (request.Series is { Count: > 0 })
        {
            return IngestStudyAsync(new StudyIngestRequest
            {
                TenantId = request.TenantId,
                SourceBucket = request.SourceBucket,
                DestinationBucket = request.DestinationBucket,
                StudyInstanceUid = request.StudyInstanceUid ?? string.Empty,
                Series = request.Series,
                ConcurrencyLimit = request.ConcurrencyLimit,
                GenerateManifests = request.GenerateManifests,
                UseByteRangeForHeader = request.UseByteRangeForHeader
            }, ct);
        }

        if (!string.IsNullOrWhiteSpace(request.SeriesInstanceUid))
        {
            return IngestSeriesAsync(new SeriesIngestRequest
            {
                TenantId = request.TenantId,
                SourceBucket = request.SourceBucket,
                DestinationBucket = request.DestinationBucket,
                SourcePrefix = request.SourcePrefix ?? string.Empty,
                StudyInstanceUid = request.StudyInstanceUid ?? string.Empty,
                SeriesInstanceUid = request.SeriesInstanceUid,
                ConcurrencyLimit = request.ConcurrencyLimit,
                GenerateManifests = request.GenerateManifests,
                UseByteRangeForHeader = request.UseByteRangeForHeader
            }, ct);
        }

        return IngestBulkAsync(new BulkIngestRequest
        {
            TenantId = request.TenantId,
            SourceBucket = request.SourceBucket,
            DestinationBucket = request.DestinationBucket,
            SourcePrefix = request.SourcePrefix ?? string.Empty,
            ConcurrencyLimit = request.ConcurrencyLimit,
            GenerateManifests = request.GenerateManifests,
            UseByteRangeForHeader = request.UseByteRangeForHeader
        }, ct);
    }

    // ------------------------------------------------------------------------------------------------
    // Shared Core Helpers (Zero Duplication)
    // ------------------------------------------------------------------------------------------------

    private async Task ProcessInstanceAsync(
        string tenantId,
        string sourceBucket,
        string destBucket,
        S3ObjectItem s3Item,
        string? assertedStudyUid,
        string? assertedSeriesUid,
        bool useByteRange,
        IngestionAccumulator acc,
        CancellationToken token)
    {
        var itemSw = Stopwatch.StartNew();
        ParsedDicomRecord? record = null;

        try
        {
            Stream? stream = null;
            try
            {
                if (useByteRange && s3Item.Size > _ingestionOptions.HeaderReadChunkSizeBytes)
                {
                    stream = await _s3Service.GetByteRangeStreamAsync(
                        sourceBucket, s3Item.Key, 0, _ingestionOptions.HeaderReadChunkSizeBytes - 1, token);
                }
                else
                {
                    stream = await _s3Service.GetStreamAsync(sourceBucket, s3Item.Key, token);
                }

                record = await _metadataReader.ExtractMetadataAsync(stream, s3Item.Key, s3Item.Size, token);
            }
            catch (Exception ex) when (useByteRange)
            {
                if (stream != null) await stream.DisposeAsync();
                stream = await _s3Service.GetStreamAsync(sourceBucket, s3Item.Key, token);
                record = await _metadataReader.ExtractMetadataAsync(stream, s3Item.Key, s3Item.Size, token);
            }
            finally
            {
                if (stream != null) await stream.DisposeAsync();
            }

            // If caller asserted UIDs, ensure they are used
            var studyUid = !string.IsNullOrWhiteSpace(assertedStudyUid) ? assertedStudyUid : record.Study.StudyInstanceUid;
            var seriesUid = !string.IsNullOrWhiteSpace(assertedSeriesUid) ? assertedSeriesUid : record.Series.SeriesInstanceUid;

            record.Study.StudyInstanceUid = studyUid;
            record.Series.SeriesInstanceUid = seriesUid;

            acc.ParseLatencies.Add(record.HeaderParseLatencyMs);

            // S3 Server-side Copy to standardized path
            var destKey = $"{tenantId}/{studyUid}/{seriesUid}/{record.SopInstanceUid}.dcm";
            record.DestinationS3Key = destKey;

            var copySw = Stopwatch.StartNew();
            await _s3Service.CopyObjectAsync(sourceBucket, s3Item.Key, destBucket, destKey, token);
            copySw.Stop();

            record.S3CopyLatencyMs = copySw.Elapsed.TotalMilliseconds;
            acc.CopyLatencies.Add(record.S3CopyLatencyMs);

            Interlocked.Add(ref acc.TotalBytesProcessed, s3Item.Size);
            acc.ParsedRecords.Add(record);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error processing DICOM object {Key}", s3Item.Key);
            acc.Errors.Add(new IngestionError
            {
                SourceKey = s3Item.Key,
                Stage = record == null ? "MetadataParsing" : "S3Copy",
                Message = ex.Message
            });
        }
        finally
        {
            itemSw.Stop();
            acc.EndToEndLatencies.Add(itemSw.Elapsed.TotalMilliseconds);
        }
    }

    private async Task<SeriesManifest> BuildAndPersistSeriesManifestAsync(
        string tenantId,
        string destBucket,
        List<ParsedDicomRecord> groupList,
        bool generateManifests,
        CancellationToken ct)
    {
        var first = groupList.First();
        var (commonMetadata, factoredInstances) = FactorSeriesAttributes(groupList);

        var seriesManifest = new SeriesManifest
        {
            TenantId = tenantId,
            ManifestS3Key = $"{tenantId}/{first.Study.StudyInstanceUid}/{first.Series.SeriesInstanceUid}/manifest.json",
            IngestTimestampUtc = DateTime.UtcNow,
            TotalInstances = groupList.Count,
            TotalSizeBytes = groupList.Sum(x => x.FileSizeBytes),
            Patient = first.Patient,
            Study = first.Study,
            Series = first.Series,
            CommonInstanceMetadata = commonMetadata,
            Instances = factoredInstances
        };

        if (generateManifests)
        {
            await _s3Service.PutJsonAsync(destBucket, seriesManifest.ManifestS3Key, seriesManifest, ct);
        }

        return seriesManifest;
    }

    private static (InstanceImageAttributes Common, List<FactoredInstanceMetadata> Instances) FactorSeriesAttributes(List<ParsedDicomRecord> records)
    {
        var common = new InstanceImageAttributes
        {
            ImageType = GetMode(records.Select(r => r.ImageAttributes.ImageType)),
            NumberOfFrames = GetMode(records.Select(r => r.ImageAttributes.NumberOfFrames)),
            SopClassUid = GetMode(records.Select(r => r.ImageAttributes.SopClassUid)),
            TransferSyntaxUid = GetMode(records.Select(r => r.ImageAttributes.TransferSyntaxUid)),
            SpecificCharacterSet = GetMode(records.Select(r => r.ImageAttributes.SpecificCharacterSet)),
            Rows = GetMode(records.Select(r => r.ImageAttributes.Rows)),
            Columns = GetMode(records.Select(r => r.ImageAttributes.Columns)),
            BitsAllocated = GetMode(records.Select(r => r.ImageAttributes.BitsAllocated)),
            BitsStored = GetMode(records.Select(r => r.ImageAttributes.BitsStored)),
            HighBit = GetMode(records.Select(r => r.ImageAttributes.HighBit)),
            PixelRepresentation = GetMode(records.Select(r => r.ImageAttributes.PixelRepresentation)),
            SamplesPerPixel = GetMode(records.Select(r => r.ImageAttributes.SamplesPerPixel)),
            PhotometricInterpretation = GetMode(records.Select(r => r.ImageAttributes.PhotometricInterpretation))
        };

        var instances = new List<FactoredInstanceMetadata>();
        foreach (var r in records.OrderBy(x => ParseInstanceNumber(x.InstanceNumber)))
        {
            var attr = r.ImageAttributes;
            InstanceImageAttributes? overrides = null;
            var hasOverride = false;
            var delta = new InstanceImageAttributes();

            if (attr.ImageType != common.ImageType) { delta.ImageType = attr.ImageType; hasOverride = true; }
            if (attr.NumberOfFrames != common.NumberOfFrames) { delta.NumberOfFrames = attr.NumberOfFrames; hasOverride = true; }
            if (attr.SopClassUid != common.SopClassUid) { delta.SopClassUid = attr.SopClassUid; hasOverride = true; }
            if (attr.TransferSyntaxUid != common.TransferSyntaxUid) { delta.TransferSyntaxUid = attr.TransferSyntaxUid; hasOverride = true; }
            if (attr.SpecificCharacterSet != common.SpecificCharacterSet) { delta.SpecificCharacterSet = attr.SpecificCharacterSet; hasOverride = true; }
            if (attr.Rows != common.Rows) { delta.Rows = attr.Rows; hasOverride = true; }
            if (attr.Columns != common.Columns) { delta.Columns = attr.Columns; hasOverride = true; }
            if (attr.BitsAllocated != common.BitsAllocated) { delta.BitsAllocated = attr.BitsAllocated; hasOverride = true; }
            if (attr.BitsStored != common.BitsStored) { delta.BitsStored = attr.BitsStored; hasOverride = true; }
            if (attr.HighBit != common.HighBit) { delta.HighBit = attr.HighBit; hasOverride = true; }
            if (attr.PixelRepresentation != common.PixelRepresentation) { delta.PixelRepresentation = attr.PixelRepresentation; hasOverride = true; }
            if (attr.SamplesPerPixel != common.SamplesPerPixel) { delta.SamplesPerPixel = attr.SamplesPerPixel; hasOverride = true; }
            if (attr.PhotometricInterpretation != common.PhotometricInterpretation) { delta.PhotometricInterpretation = attr.PhotometricInterpretation; hasOverride = true; }

            if (hasOverride)
            {
                overrides = delta;
            }

            instances.Add(new FactoredInstanceMetadata
            {
                SopInstanceUid = r.SopInstanceUid,
                InstanceNumber = r.InstanceNumber,
                DestinationS3Key = r.DestinationS3Key,
                SourceS3Key = r.SourceS3Key,
                FileSizeBytes = r.FileSizeBytes,
                Overrides = overrides
            });
        }

        return (common, instances);
    }

    private static T? GetMode<T>(IEnumerable<T?> source)
    {
        var nonNull = source.Where(x => x != null).ToList();
        if (nonNull.Count == 0) return default;
        return nonNull
            .GroupBy(x => x)
            .OrderByDescending(g => g.Count())
            .First()
            .Key;
    }

    private static int ParseInstanceNumber(string? num)
    {
        return int.TryParse(num, out var val) ? val : int.MaxValue;
    }

    private (string SourceBucket, string DestBucket, int Concurrency) ResolveDefaults(BaseIngestRequest req)
    {
        var sourceBucket = string.IsNullOrWhiteSpace(req.SourceBucket) ? _minioOptions.DefaultSourceBucket : req.SourceBucket;
        var destBucket = string.IsNullOrWhiteSpace(req.DestinationBucket) ? _minioOptions.DefaultDestinationBucket : req.DestinationBucket;
        var concurrency = Math.Max(1, req.ConcurrencyLimit.GetValueOrDefault(_ingestionOptions.DefaultConcurrency));
        return (sourceBucket, destBucket, concurrency);
    }

    private static IngestResponse CreateBaseResponse(string tenantId, string mode, string src, string dst, int concurrency)
    {
        return new IngestResponse
        {
            TenantId = tenantId,
            IngestionMode = mode,
            SourceBucket = src,
            DestinationBucket = dst,
            ConcurrencyUsed = concurrency
        };
    }

    private static void FinalizeResponse(IngestResponse response, List<SeriesManifest> manifests, IngestionAccumulator acc, double totalMs)
    {
        response.Success = acc.Errors.IsEmpty;
        //response.SeriesManifests = manifests;
        response.SeriesCount = manifests.Count;
        response.Errors = acc.Errors.ToList();

        response.Metrics.TotalDurationMs = Math.Round(totalMs, 2);
        response.Metrics.FilesProcessed = acc.ParsedRecords.Count;
        response.Metrics.FilesFailed = acc.Errors.Count;
        response.Metrics.TotalBytesProcessed = acc.TotalBytesProcessed;

        var totalSeconds = totalMs / 1000.0;
        if (totalSeconds > 0)
        {
            response.Metrics.ThroughputFilesPerSecond = Math.Round(acc.ParsedRecords.Count / totalSeconds, 2);
            response.Metrics.ThroughputMegabytesPerSecond = Math.Round((acc.TotalBytesProcessed / (1024.0 * 1024.0)) / totalSeconds, 2);
        }

        response.Metrics.HeaderParseLatency = LatencyDistribution.Compute(acc.ParseLatencies);
        response.Metrics.S3CopyLatency = LatencyDistribution.Compute(acc.CopyLatencies);
        response.Metrics.EndToEndPerFileLatency = LatencyDistribution.Compute(acc.EndToEndLatencies);
    }

    private class IngestionAccumulator
    {
        public ConcurrentBag<ParsedDicomRecord> ParsedRecords { get; } = new();
        public ConcurrentBag<IngestionError> Errors { get; } = new();
        public ConcurrentBag<double> ParseLatencies { get; } = new();
        public ConcurrentBag<double> CopyLatencies { get; } = new();
        public ConcurrentBag<double> EndToEndLatencies { get; } = new();
        public long TotalBytesProcessed;

        public void Merge(IngestionAccumulator other)
        {
            foreach (var r in other.ParsedRecords) ParsedRecords.Add(r);
            foreach (var e in other.Errors) Errors.Add(e);
            foreach (var l in other.ParseLatencies) ParseLatencies.Add(l);
            foreach (var l in other.CopyLatencies) CopyLatencies.Add(l);
            foreach (var l in other.EndToEndLatencies) EndToEndLatencies.Add(l);
            Interlocked.Add(ref TotalBytesProcessed, other.TotalBytesProcessed);
        }
    }
}
