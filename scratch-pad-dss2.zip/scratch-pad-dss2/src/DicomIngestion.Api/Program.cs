using Amazon.S3;
using DicomIngestion.Api.Models;
using DicomIngestion.Api.Services;
using Microsoft.Extensions.Options;

var builder = WebApplication.CreateBuilder(args);

// Bind Configuration Options
builder.Services.Configure<MinioOptions>(
    builder.Configuration.GetSection(MinioOptions.SectionName));
builder.Services.Configure<IngestionOptions>(
    builder.Configuration.GetSection(IngestionOptions.SectionName));

// Configure Amazon S3 Client for MinIO
builder.Services.AddSingleton<IAmazonS3>(sp =>
{
    var minio = sp.GetRequiredService<IOptions<MinioOptions>>().Value;
    var config = new AmazonS3Config
    {
        ServiceURL = minio.ServiceUrl,
        ForcePathStyle = minio.ForcePathStyle,
        UseHttp = minio.ServiceUrl.StartsWith("http://", StringComparison.OrdinalIgnoreCase)
    };
    return new AmazonS3Client(minio.AccessKey, minio.SecretKey, config);
});

// Register Pipeline Services
builder.Services.AddSingleton<IS3StorageService, S3StorageService>();
builder.Services.AddSingleton<IDicomMetadataReader, DicomMetadataReader>();
builder.Services.AddScoped<IIngestionPipeline, IngestionPipeline>();
builder.Services.AddScoped<IDicomDataGenerator, DicomDataGenerator>();

builder.Services.AddControllers();
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen(c =>
{
    c.SwaggerDoc("v1", new()
    {
        Title = "DICOM Ingestion & Benchmark API",
        Version = "v1",
        Description = "High-performance synchronous DICOM ingestion pipeline with MinIO and metadata manifest generation"
    });
});

var app = builder.Build();

// Enable Swagger UI in both Development and Production for easy benchmarking
app.UseSwagger();
app.UseSwaggerUI(c =>
{
    c.SwaggerEndpoint("/swagger/v1/swagger.json", "DICOM Ingestion API v1");
    c.RoutePrefix = string.Empty; // Serve Swagger at app root
});

app.UseAuthorization();
app.MapControllers();

app.Run();
