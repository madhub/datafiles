using System.Diagnostics;
using DicomIngestion.Api.Models;
using FellowOakDicom;

namespace DicomIngestion.Api.Services;

public class DicomMetadataReader : IDicomMetadataReader
{
    private readonly ILogger<DicomMetadataReader> _logger;

    public DicomMetadataReader(ILogger<DicomMetadataReader> logger)
    {
        _logger = logger;
    }

    public async Task<ParsedDicomRecord> ExtractMetadataAsync(Stream dicomStream, string sourceKey, long fileSize, CancellationToken ct = default)
    {
        var sw = Stopwatch.StartNew();

        // Read file structure with SkipLargeTags so PixelData payload is not parsed/allocated in memory
        var dicomFile = await DicomFile.OpenAsync(dicomStream, FileReadOption.SkipLargeTags);
        var dataset = dicomFile.Dataset;

        // UIDs
        var studyInstanceUid = SanitizeUid(
            GetString(dataset, DicomTag.StudyInstanceUID),
            fallback: "unknown-study"
        );

        var seriesInstanceUid = SanitizeUid(
            GetString(dataset, DicomTag.SeriesInstanceUID),
            fallback: "unknown-series"
        );

        var sopInstanceUid = SanitizeUid(
            GetString(dataset, DicomTag.SOPInstanceUID),
            fallback: Path.GetFileNameWithoutExtension(sourceKey)
        );

        // Patient Level
        var patientId = GetString(dataset, DicomTag.PatientID, "unknown-patient");
        var issuerOfPatientId = GetNullableString(dataset, DicomTag.IssuerOfPatientID);
        var patientName = GetString(dataset, DicomTag.PatientName, "ANONYMOUS");
        var patientBirthDate = GetNullableString(dataset, DicomTag.PatientBirthDate);
        var patientSex = GetNullableString(dataset, DicomTag.PatientSex);

        // Study Level
        var studyDate = GetNullableString(dataset, DicomTag.StudyDate);
        var studyTime = GetNullableString(dataset, DicomTag.StudyTime);
        var accessionNumber = GetNullableString(dataset, DicomTag.AccessionNumber);
        var studyDescription = GetNullableString(dataset, DicomTag.StudyDescription);
        var referringPhysician = GetNullableString(dataset, DicomTag.ReferringPhysicianName);

        // Series Level
        var modality = GetString(dataset, DicomTag.Modality, "OT");
        var seriesNumber = GetNullableString(dataset, DicomTag.SeriesNumber);
        var seriesDescription = GetNullableString(dataset, DicomTag.SeriesDescription);
        var bodyPart = GetNullableString(dataset, DicomTag.BodyPartExamined);

        // Instance Identifiers
        var instanceNumber = GetNullableString(dataset, DicomTag.InstanceNumber);
        var sopClassUid = GetNullableString(dataset, DicomTag.SOPClassUID);
        var transferSyntax = dicomFile.FileMetaInfo?.TransferSyntax?.UID?.UID;
        var charset = GetNullableString(dataset, DicomTag.SpecificCharacterSet);

        // Image Attributes (for factoring, supporting single & multi-frame)
        var imageType = GetNullableString(dataset, DicomTag.ImageType);
        var numberOfFrames = GetNullableInt(dataset, DicomTag.NumberOfFrames);
        var rows = GetNullableInt(dataset, DicomTag.Rows);
        var cols = GetNullableInt(dataset, DicomTag.Columns);
        var bitsAllocated = GetNullableInt(dataset, DicomTag.BitsAllocated);
        var bitsStored = GetNullableInt(dataset, DicomTag.BitsStored);
        var highBit = GetNullableInt(dataset, DicomTag.HighBit);
        var pixelRep = GetNullableInt(dataset, DicomTag.PixelRepresentation);
        var samples = GetNullableInt(dataset, DicomTag.SamplesPerPixel);
        var photometric = GetNullableString(dataset, DicomTag.PhotometricInterpretation);

        sw.Stop();

        return new ParsedDicomRecord
        {
            Patient = new PatientMetadata
            {
                PatientId = patientId,
                IssuerOfPatientId = issuerOfPatientId,
                PatientName = patientName,
                PatientBirthDate = patientBirthDate,
                PatientSex = patientSex
            },
            Study = new StudyMetadata
            {
                StudyInstanceUid = studyInstanceUid,
                StudyDate = studyDate,
                StudyTime = studyTime,
                AccessionNumber = accessionNumber,
                StudyDescription = studyDescription,
                ReferringPhysicianName = referringPhysician
            },
            Series = new SeriesMetadata
            {
                SeriesInstanceUid = seriesInstanceUid,
                Modality = modality,
                SeriesNumber = seriesNumber,
                SeriesDescription = seriesDescription,
                BodyPartExamined = bodyPart
            },
            ImageAttributes = new InstanceImageAttributes
            {
                ImageType = imageType,
                NumberOfFrames = numberOfFrames,
                SopClassUid = sopClassUid,
                TransferSyntaxUid = transferSyntax,
                SpecificCharacterSet = charset,
                Rows = rows,
                Columns = cols,
                BitsAllocated = bitsAllocated,
                BitsStored = bitsStored,
                HighBit = highBit,
                PixelRepresentation = pixelRep,
                SamplesPerPixel = samples,
                PhotometricInterpretation = photometric
            },
            SopInstanceUid = sopInstanceUid,
            InstanceNumber = instanceNumber,
            SourceS3Key = sourceKey,
            FileSizeBytes = fileSize,
            HeaderParseLatencyMs = sw.Elapsed.TotalMilliseconds
        };
    }

    private static string GetString(DicomDataset dataset, DicomTag tag, string defaultValue = "")
    {
        if (dataset.TryGetString(tag, out var value) && !string.IsNullOrWhiteSpace(value))
        {
            return value.Trim();
        }
        return defaultValue;
    }

    private static string? GetNullableString(DicomDataset dataset, DicomTag tag)
    {
        if (dataset.TryGetString(tag, out var value) && !string.IsNullOrWhiteSpace(value))
        {
            return value.Trim();
        }
        return null;
    }

    private static int? GetNullableInt(DicomDataset dataset, DicomTag tag)
    {
        if (dataset.Contains(tag))
        {
            try
            {
                return dataset.GetSingleValue<int>(tag);
            }
            catch
            {
                if (dataset.TryGetString(tag, out var str) && int.TryParse(str, out var val))
                {
                    return val;
                }
            }
        }
        return null;
    }

    private static string SanitizeUid(string? uid, string fallback)
    {
        if (string.IsNullOrWhiteSpace(uid)) return fallback;
        var sanitized = string.Concat(uid.Where(c => char.IsLetterOrDigit(c) || c == '.' || c == '-' || c == '_')).Trim();
        return string.IsNullOrWhiteSpace(sanitized) ? fallback : sanitized;
    }
}
