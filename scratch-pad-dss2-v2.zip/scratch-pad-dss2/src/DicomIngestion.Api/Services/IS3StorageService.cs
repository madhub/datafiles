namespace DicomIngestion.Api.Services;

public record S3ObjectItem(string Key, long Size, DateTime LastModified);

public interface IS3StorageService
{
    Task EnsureBucketExistsAsync(string bucketName, CancellationToken ct = default);
    Task<List<S3ObjectItem>> ListObjectsAsync(string bucketName, string prefix, CancellationToken ct = default);
    Task<Stream> GetByteRangeStreamAsync(string bucketName, string key, long startByte, long endByte, CancellationToken ct = default);
    Task<Stream> GetStreamAsync(string bucketName, string key, CancellationToken ct = default);
    Task CopyObjectAsync(string sourceBucket, string sourceKey, string destinationBucket, string destinationKey, CancellationToken ct = default);
    Task PutJsonAsync<T>(string bucketName, string key, T payload, CancellationToken ct = default);
    Task<T?> GetJsonAsync<T>(string bucketName, string key, CancellationToken ct = default);
    Task PutObjectAsync(string bucketName, string key, Stream content, long length, string contentType = "application/dicom", CancellationToken ct = default);
    Task<int> DeleteObjectsByPrefixAsync(string bucketName, string prefix, CancellationToken ct = default);
}
