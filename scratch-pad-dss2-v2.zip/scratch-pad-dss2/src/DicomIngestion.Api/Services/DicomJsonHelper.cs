using System.Text.Json.Nodes;
using DicomIngestion.Api.Data;

namespace DicomIngestion.Api.Services;

public static class DicomJsonHelper
{
    public static JsonObject ToDicomJson(StudyRecord study)
    {
        var obj = new JsonObject();

        // 0008xxxx Tags
        AddString(obj, "00080020", "DA", study.StudyDate);
        AddString(obj, "00080030", "TM", study.StudyTime);
        AddString(obj, "00080050", "SH", study.AccessionNumber);

        if (!string.IsNullOrWhiteSpace(study.ModalitiesInStudy))
        {
            var modalities = study.ModalitiesInStudy.Split('\\', StringSplitOptions.RemoveEmptyEntries);
            var modArray = new JsonArray();
            foreach (var m in modalities) modArray.Add(m);
            obj["00080061"] = new JsonObject
            {
                ["vr"] = "CS",
                ["Value"] = modArray
            };
        }

        AddPersonName(obj, "00080090", study.ReferringPhysicianName);
        AddString(obj, "00081030", "LO", study.StudyDescription);

        // 0010xxxx Tags (Patient Level)
        if (study.Patient != null)
        {
            AddPersonName(obj, "00100010", study.Patient.PatientName);
            AddString(obj, "00100020", "LO", study.Patient.PatientId);
            AddString(obj, "00100021", "LO", study.Patient.IssuerOfPatientId);
            AddString(obj, "00100030", "DA", study.Patient.PatientBirthDate);
            AddString(obj, "00100040", "CS", study.Patient.PatientSex);
        }
        else
        {
            AddString(obj, "00100020", "LO", study.PatientId);
        }

        // 0020xxxx Tags (Study Level & Aggregates)
        AddString(obj, "0020000D", "UI", study.StudyInstanceUid);
        AddInt(obj, "00201206", "IS", study.NumberOfStudyRelatedSeries);
        AddInt(obj, "00201208", "IS", study.NumberOfStudyRelatedInstances);

        return SortDicomTags(obj);
    }

    public static JsonObject ToDicomJson(SeriesRecord series)
    {
        var obj = new JsonObject();

        AddString(obj, "00080060", "CS", series.Modality);
        AddString(obj, "0008103E", "LO", series.SeriesDescription);
        AddString(obj, "00180015", "CS", series.BodyPartExamined);
        AddString(obj, "0020000D", "UI", series.StudyInstanceUid);
        AddString(obj, "0020000E", "UI", series.SeriesInstanceUid);
        AddString(obj, "00200011", "IS", series.SeriesNumber);
        AddInt(obj, "00201209", "IS", series.NumberOfSeriesRelatedInstances);

        return SortDicomTags(obj);
    }

    public static JsonObject ToDicomJson(InstanceRecord instance)
    {
        var obj = new JsonObject();

        AddString(obj, "00080016", "UI", instance.SopClassUid);
        AddString(obj, "00080018", "UI", instance.SopInstanceUid);
        AddString(obj, "0020000D", "UI", instance.StudyInstanceUid);
        AddString(obj, "0020000E", "UI", instance.SeriesInstanceUid);
        AddString(obj, "00200013", "IS", instance.InstanceNumber);

        return SortDicomTags(obj);
    }

    private static JsonObject SortDicomTags(JsonObject obj)
    {
        var sorted = new JsonObject();
        foreach (var kvp in obj.OrderBy(x => x.Key, StringComparer.OrdinalIgnoreCase))
        {
            sorted[kvp.Key] = kvp.Value?.DeepClone();
        }
        return sorted;
    }

    public static object ToFriendlyJson(StudyRecord s)
    {
        return new
        {
            tenantId = s.TenantId,
            patientId = s.PatientId,
            patientName = s.Patient?.PatientName ?? string.Empty,
            issuerOfPatientId = s.Patient?.IssuerOfPatientId,
            patientBirthDate = s.Patient?.PatientBirthDate,
            patientSex = s.Patient?.PatientSex,
            studyInstanceUid = s.StudyInstanceUid,
            studyDate = s.StudyDate,
            studyTime = s.StudyTime,
            accessionNumber = s.AccessionNumber,
            studyDescription = s.StudyDescription,
            referringPhysicianName = s.ReferringPhysicianName,
            numberOfStudyRelatedSeries = s.NumberOfStudyRelatedSeries,
            numberOfStudyRelatedInstances = s.NumberOfStudyRelatedInstances,
            modalitiesInStudy = s.ModalitiesInStudy
        };
    }

    public static object ToFriendlyJson(SeriesRecord s)
    {
        return new
        {
            tenantId = s.TenantId,
            studyInstanceUid = s.StudyInstanceUid,
            seriesInstanceUid = s.SeriesInstanceUid,
            modality = s.Modality,
            seriesNumber = s.SeriesNumber,
            seriesDescription = s.SeriesDescription,
            bodyPartExamined = s.BodyPartExamined,
            numberOfSeriesRelatedInstances = s.NumberOfSeriesRelatedInstances,
            totalSizeBytes = s.TotalSizeBytes,
            manifestS3Key = s.ManifestS3Key
        };
    }

    public static object ToFriendlyJson(InstanceRecord i)
    {
        return new
        {
            tenantId = i.TenantId,
            studyInstanceUid = i.StudyInstanceUid,
            seriesInstanceUid = i.SeriesInstanceUid,
            sopInstanceUid = i.SopInstanceUid,
            instanceNumber = i.InstanceNumber,
            sopClassUid = i.SopClassUid,
            destinationS3Key = i.DestinationS3Key,
            fileSizeBytes = i.FileSizeBytes
        };
    }

    private static void AddString(JsonObject obj, string tag, string vr, string? value)
    {
        if (string.IsNullOrEmpty(value)) return;
        obj[tag] = new JsonObject
        {
            ["vr"] = vr,
            ["Value"] = new JsonArray(value)
        };
    }

    private static void AddInt(JsonObject obj, string tag, string vr, int value)
    {
        obj[tag] = new JsonObject
        {
            ["vr"] = vr,
            ["Value"] = new JsonArray(value)
        };
    }

    private static void AddPersonName(JsonObject obj, string tag, string? name)
    {
        if (string.IsNullOrEmpty(name)) return;
        var person = new JsonObject
        {
            ["Alphabetic"] = name
        };
        obj[tag] = new JsonObject
        {
            ["vr"] = "PN",
            ["Value"] = new JsonArray(person)
        };
    }
}
