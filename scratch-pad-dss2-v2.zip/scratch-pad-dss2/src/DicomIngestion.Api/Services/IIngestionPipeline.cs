using DicomIngestion.Api.Models;

namespace DicomIngestion.Api.Services;

public interface IIngestionPipeline
{
    Task<IngestResponse> IngestBulkAsync(BulkIngestRequest request, CancellationToken ct = default);
    Task<IngestResponse> IngestSeriesAsync(SeriesIngestRequest request, CancellationToken ct = default);
    Task<IngestResponse> IngestStudyAsync(StudyIngestRequest request, CancellationToken ct = default);
    Task<IngestResponse> ExecuteIngestionAsync(IngestRequest request, CancellationToken ct = default);
}
