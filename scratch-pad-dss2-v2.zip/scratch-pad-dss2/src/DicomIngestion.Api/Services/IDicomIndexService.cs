using DicomIngestion.Api.Data;
using DicomIngestion.Api.Models;

namespace DicomIngestion.Api.Services;

public interface IDicomIndexService
{
    Task IndexManifestAsync(SeriesManifest manifest, CancellationToken ct = default);
    Task<IndexSyncResult> RebuildIndexFromS3Async(string tenantId, string? destinationBucket = null, CancellationToken ct = default);
    Task<IndexStatsDto> GetIndexStatsAsync(string tenantId, CancellationToken ct = default);

    Task<List<StudyRecord>> QueryStudiesAsync(string tenantId, QidoStudyQuery query, CancellationToken ct = default);
    Task<List<SeriesRecord>> QuerySeriesAsync(string tenantId, string? studyInstanceUid, QidoSeriesQuery query, CancellationToken ct = default);
    Task<List<InstanceRecord>> QueryInstancesAsync(string tenantId, string? studyInstanceUid, string? seriesInstanceUid, QidoInstanceQuery query, CancellationToken ct = default);

    Task<InstanceRecord?> GetInstanceAsync(string tenantId, string studyUid, string seriesUid, string sopUid, CancellationToken ct = default);
    Task<List<InstanceRecord>> GetSeriesInstancesAsync(string tenantId, string studyUid, string seriesUid, CancellationToken ct = default);
    Task<List<InstanceRecord>> GetStudyInstancesAsync(string tenantId, string studyUid, CancellationToken ct = default);

    Task<CleanupResult> CleanupAsync(CleanupRequest request, CancellationToken ct = default);
}
