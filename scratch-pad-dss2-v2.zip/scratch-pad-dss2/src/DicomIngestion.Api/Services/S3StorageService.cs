using System.Text;
using System.Text.Json;
using Amazon.S3;
using Amazon.S3.Model;
using Amazon.S3.Util;
using DicomIngestion.Api.Models;
using Microsoft.Extensions.Options;

namespace DicomIngestion.Api.Services;

public class S3StorageService : IS3StorageService
{
    private readonly IAmazonS3 _s3Client;
    private readonly ILogger<S3StorageService> _logger;
    private static readonly JsonSerializerOptions JsonOptions = new()
    {
        WriteIndented = true,
        PropertyNamingPolicy = JsonNamingPolicy.CamelCase
    };

    public S3StorageService(IAmazonS3 s3Client, ILogger<S3StorageService> logger)
    {
        _s3Client = s3Client;
        _logger = logger;
    }

    public async Task EnsureBucketExistsAsync(string bucketName, CancellationToken ct = default)
    {
        try
        {
            var exists = await AmazonS3Util.DoesS3BucketExistV2Async(_s3Client, bucketName);
            if (!exists)
            {
                _logger.LogInformation("Creating S3 bucket: {BucketName}", bucketName);
                await _s3Client.PutBucketAsync(new PutBucketRequest
                {
                    BucketName = bucketName
                }, ct);
            }
        }
        catch (AmazonS3Exception ex) when (ex.ErrorCode == "BucketAlreadyOwnedByYou" || ex.ErrorCode == "BucketAlreadyExists")
        {
            // Bucket exists, ignore
        }
        catch (Exception ex)
        {
            _logger.LogWarning(ex, "Could not verify/create bucket {BucketName}. Proceeding assuming it exists.", bucketName);
        }
    }

    public async Task<List<S3ObjectItem>> ListObjectsAsync(string bucketName, string prefix, CancellationToken ct = default)
    {
        var items = new List<S3ObjectItem>();
        var request = new ListObjectsV2Request
        {
            BucketName = bucketName,
            Prefix = prefix
        };

        ListObjectsV2Response response;
        do
        {
            response = await _s3Client.ListObjectsV2Async(request, ct);
            foreach (var s3Obj in response.S3Objects)
            {
                // Skip folder marker keys
                if (s3Obj.Key.EndsWith('/') && s3Obj.Size.GetValueOrDefault() == 0)
                {
                    continue;
                }

                items.Add(new S3ObjectItem(
                    s3Obj.Key,
                    s3Obj.Size.GetValueOrDefault(),
                    s3Obj.LastModified.GetValueOrDefault(DateTime.UtcNow)));
            }
            request.ContinuationToken = response.NextContinuationToken;
        } while (response.IsTruncated == true && !string.IsNullOrWhiteSpace(response.NextContinuationToken));

        return items;
    }

    public async Task<Stream> GetByteRangeStreamAsync(string bucketName, string key, long startByte, long endByte, CancellationToken ct = default)
    {
        var request = new GetObjectRequest
        {
            BucketName = bucketName,
            Key = key,
            ByteRange = new ByteRange(startByte, endByte)
        };

        using var response = await _s3Client.GetObjectAsync(request, ct);
        var memoryStream = new MemoryStream();
        await response.ResponseStream.CopyToAsync(memoryStream, ct);
        memoryStream.Position = 0;
        return memoryStream;
    }

    public async Task<Stream> GetStreamAsync(string bucketName, string key, CancellationToken ct = default)
    {
        var response = await _s3Client.GetObjectAsync(new GetObjectRequest
        {
            BucketName = bucketName,
            Key = key
        }, ct);

        var memoryStream = new MemoryStream();
        await response.ResponseStream.CopyToAsync(memoryStream, ct);
        memoryStream.Position = 0;
        return memoryStream;
    }

    public async Task CopyObjectAsync(string sourceBucket, string sourceKey, string destinationBucket, string destinationKey, CancellationToken ct = default)
    {
        var request = new CopyObjectRequest
        {
            SourceBucket = sourceBucket,
            SourceKey = sourceKey,
            DestinationBucket = destinationBucket,
            DestinationKey = destinationKey
        };

        await _s3Client.CopyObjectAsync(request, ct);
    }

    public async Task PutJsonAsync<T>(string bucketName, string key, T payload, CancellationToken ct = default)
    {
        var jsonBytes = JsonSerializer.SerializeToUtf8Bytes(payload, JsonOptions);
        using var stream = new MemoryStream(jsonBytes);

        var request = new PutObjectRequest
        {
            BucketName = bucketName,
            Key = key,
            InputStream = stream,
            ContentType = "application/json",
            UseChunkEncoding = false
        };

        await _s3Client.PutObjectAsync(request, ct);
    }

    public async Task<T?> GetJsonAsync<T>(string bucketName, string key, CancellationToken ct = default)
    {
        try
        {
            var request = new GetObjectRequest
            {
                BucketName = bucketName,
                Key = key
            };

            using var response = await _s3Client.GetObjectAsync(request, ct);
            return await JsonSerializer.DeserializeAsync<T>(response.ResponseStream, JsonOptions, ct);
        }
        catch (AmazonS3Exception ex) when (ex.StatusCode == System.Net.HttpStatusCode.NotFound || ex.ErrorCode == "NoSuchKey")
        {
            return default;
        }
    }

    public async Task PutObjectAsync(string bucketName, string key, Stream content, long length, string contentType = "application/dicom", CancellationToken ct = default)
    {
        var request = new PutObjectRequest
        {
            BucketName = bucketName,
            Key = key,
            InputStream = content,
            ContentType = contentType,
            UseChunkEncoding = false
        };

        await _s3Client.PutObjectAsync(request, ct);
    }

    public async Task<int> DeleteObjectsByPrefixAsync(string bucketName, string prefix, CancellationToken ct = default)
    {
        var totalDeleted = 0;
        while (!ct.IsCancellationRequested)
        {
            var listRequest = new ListObjectsV2Request
            {
                BucketName = bucketName,
                Prefix = prefix,
                MaxKeys = 1000
            };

            var listResponse = await _s3Client.ListObjectsV2Async(listRequest, ct);
            if (listResponse.S3Objects == null || listResponse.S3Objects.Count == 0)
            {
                break;
            }

            var deleteRequest = new DeleteObjectsRequest
            {
                BucketName = bucketName,
                Objects = listResponse.S3Objects.Select(o => new KeyVersion { Key = o.Key }).ToList(),
                Quiet = true
            };

            await _s3Client.DeleteObjectsAsync(deleteRequest, ct);
            totalDeleted += listResponse.S3Objects.Count;

            _logger.LogInformation("Deleted batch of {BatchCount} objects from '{Bucket}' prefix '{Prefix}' (Total: {Total})",
                listResponse.S3Objects.Count, bucketName, prefix, totalDeleted);

            // If the server returned fewer than max keys, we reached the end
            if (listResponse.S3Objects.Count < 1000)
            {
                break;
            }
        }

        return totalDeleted;
    }
}
