namespace DicomIngestion.Api.Services;

/// <summary>
/// Provides keyed asynchronous synchronization locks.
/// Ensures operations on the same key (e.g., tenantId + seriesInstanceUid) are serialized,
/// while operations on distinct keys execute in parallel with zero contention.
/// </summary>
public interface IKeyedLockService
{
    /// <summary>
    /// Asynchronously acquires an exclusive lock for the specified key.
    /// The returned IDisposable releases the lock when disposed.
    /// </summary>
    Task<IDisposable> AcquireLockAsync(string key, CancellationToken ct = default);
}
