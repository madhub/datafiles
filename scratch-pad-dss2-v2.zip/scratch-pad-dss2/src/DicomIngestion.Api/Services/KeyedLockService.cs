using System.Collections.Concurrent;

namespace DicomIngestion.Api.Services;

/// <summary>
/// In-memory implementation of IKeyedLockService using reference-counted SemaphoreSlim primitives.
/// Guarantees that concurrent requests for the same group key (e.g. tenantId_seriesInstanceUid)
/// are executed in strict serial sequence, while distinct keys execute fully concurrently.
/// Automatic ref-counting purges unreferenced semaphores to eliminate memory leaks.
/// </summary>
public class KeyedLockService : IKeyedLockService
{
    private sealed class RefCountedSemaphore
    {
        public readonly SemaphoreSlim Semaphore = new(1, 1);
        public int RefCount = 1;
    }

    private readonly ConcurrentDictionary<string, RefCountedSemaphore> _locks = new();

    public async Task<IDisposable> AcquireLockAsync(string key, CancellationToken ct = default)
    {
        RefCountedSemaphore item;
        lock (_locks)
        {
            if (_locks.TryGetValue(key, out var existing))
            {
                existing.RefCount++;
                item = existing;
            }
            else
            {
                item = new RefCountedSemaphore();
                _locks[key] = item;
            }
        }

        try
        {
            await item.Semaphore.WaitAsync(ct).ConfigureAwait(false);
        }
        catch
        {
            // If waiting was cancelled, decrement ref count
            Release(key, item, decrementOnly: true);
            throw;
        }

        return new Releaser(this, key, item);
    }

    private void Release(string key, RefCountedSemaphore item, bool decrementOnly = false)
    {
        if (!decrementOnly)
        {
            item.Semaphore.Release();
        }

        lock (_locks)
        {
            item.RefCount--;
            if (item.RefCount == 0)
            {
                _locks.TryRemove(key, out _);
                item.Semaphore.Dispose();
            }
        }
    }

    private sealed class Releaser : IDisposable
    {
        private KeyedLockService? _service;
        private readonly string _key;
        private readonly RefCountedSemaphore _item;

        public Releaser(KeyedLockService service, string key, RefCountedSemaphore item)
        {
            _service = service;
            _key = key;
            _item = item;
        }

        public void Dispose()
        {
            var service = Interlocked.Exchange(ref _service, null);
            service?.Release(_key, _item);
        }
    }
}
