using System.Diagnostics;
using System.Text.Json;
using DicomIngestion.Api.Data;
using DicomIngestion.Api.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Options;

namespace DicomIngestion.Api.Services;

public class DicomIndexService : IDicomIndexService
{
    private readonly DicomDbContext _db;
    private readonly IS3StorageService _s3Service;
    private readonly MinioOptions _minioOptions;
    private readonly ILogger<DicomIndexService> _logger;

    /// <summary>
    /// ARCHITECTURAL NOTE: Local SQLite & Scoped DbContext Serialization Lock.
    ///
    /// WHY THIS IS NEEDED IN THE CURRENT IMPLEMENTATION:
    /// 1. SQLite Single-Writer Architecture: SQLite allows concurrent readers in WAL mode, but supports
    ///    strictly ONLY ONE active write transaction globally across the entire database file. Concurrent
    ///    writes cause SQLITE_BUSY / lock contention errors.
    /// 2. EF Core Scoped DbContext: Within a single HTTP request (e.g. bulk ingestion), multiple threads
    ///    cannot use the same DbContext instance concurrently without throwing InvalidOperationException.
    ///
    /// WHY THIS IS NOT NEEDED IN AWS SQS FIFO + PRODUCTION RDBMS (PostgreSQL / Aurora):
    /// In an enterprise cloud deployment with AWS SQS FIFO and a distributed RDBMS:
    /// 1. Distributed SQS FIFO: SQS guarantees that messages with the same MessageGroupId (tenant_series_uid)
    ///    are processed strictly sequentially, while different series process concurrently across worker pods.
    /// 2. Row-Level MVCC: PostgreSQL / Aurora use Multi-Version Concurrency Control (MVCC) with row-level
    ///    locking. Multiple worker nodes write different series concurrently with ZERO table/database locks.
    /// 3. Independent DbContext Lifecycle: Each SQS message consumer executes within its own IServiceScope,
    ///    instantiating its own dedicated DbContext instance (eliminating in-process concurrency collisions).
    /// 4. In a distributed environment, a global C# SemaphoreSlim is an anti-pattern that would bottleneck
    ///    horizontal scalability and cannot coordinate across multiple Kubernetes pods/nodes anyway.
    /// </summary>
    private static readonly SemaphoreSlim _dbWriteLock = new(1, 1);

    private static readonly JsonSerializerOptions JsonOptions = new()
    {
        PropertyNameCaseInsensitive = true
    };

    public DicomIndexService(
        DicomDbContext db,
        IS3StorageService s3Service,
        IOptions<MinioOptions> minioOptions,
        ILogger<DicomIndexService> logger)
    {
        _db = db;
        _s3Service = s3Service;
        _minioOptions = minioOptions.Value;
        _logger = logger;
    }

    public async Task IndexManifestAsync(SeriesManifest manifest, CancellationToken ct = default)
    {
        if (string.IsNullOrWhiteSpace(manifest.Study?.StudyInstanceUid) || string.IsNullOrWhiteSpace(manifest.Series?.SeriesInstanceUid))
        {
            _logger.LogWarning("Skipping manifest with missing Study/Series UID: {ManifestKey}", manifest.ManifestS3Key);
            return;
        }

        var tenantId = string.IsNullOrWhiteSpace(manifest.TenantId) ? "tenant-001" : manifest.TenantId.Trim();
        var pat = manifest.Patient ?? new PatientMetadata();
        var st = manifest.Study ?? new StudyMetadata();
        var se = manifest.Series ?? new SeriesMetadata();

        if (string.IsNullOrWhiteSpace(st.StudyInstanceUid) || string.IsNullOrWhiteSpace(se.SeriesInstanceUid))
        {
            _logger.LogWarning("Skipping manifest index for tenant {TenantId}: Missing StudyInstanceUid or SeriesInstanceUid", tenantId);
            return;
        }

        await _dbWriteLock.WaitAsync(ct);
        try
        {
            await using var tx = await _db.Database.BeginTransactionAsync(ct);
            try
            {
            // 1. Upsert Patient
            var patientRecord = await _db.Patients
                .FirstOrDefaultAsync(p => p.TenantId == tenantId && p.PatientId == pat.PatientId, ct);

            if (patientRecord == null)
            {
                patientRecord = new PatientRecord
                {
                    TenantId = tenantId,
                    PatientId = pat.PatientId,
                    IssuerOfPatientId = pat.IssuerOfPatientId,
                    PatientName = pat.PatientName,
                    PatientBirthDate = pat.PatientBirthDate,
                    PatientSex = pat.PatientSex,
                    IndexedAtUtc = DateTime.UtcNow
                };
                _db.Patients.Add(patientRecord);
            }
            else
            {
                patientRecord.PatientName = pat.PatientName;
                patientRecord.IssuerOfPatientId = pat.IssuerOfPatientId;
                patientRecord.PatientBirthDate = pat.PatientBirthDate;
                patientRecord.PatientSex = pat.PatientSex;
                patientRecord.IndexedAtUtc = DateTime.UtcNow;
            }

            // 2. Upsert Study
            var studyRecord = await _db.Studies
                .FirstOrDefaultAsync(s => s.TenantId == tenantId && s.StudyInstanceUid == st.StudyInstanceUid, ct);

            if (studyRecord == null)
            {
                studyRecord = new StudyRecord
                {
                    TenantId = tenantId,
                    StudyInstanceUid = st.StudyInstanceUid,
                    PatientId = pat.PatientId,
                    StudyDate = st.StudyDate,
                    StudyTime = st.StudyTime,
                    AccessionNumber = st.AccessionNumber,
                    StudyDescription = st.StudyDescription,
                    ReferringPhysicianName = st.ReferringPhysicianName,
                    IndexedAtUtc = DateTime.UtcNow
                };
                _db.Studies.Add(studyRecord);
            }
            else
            {
                studyRecord.PatientId = pat.PatientId;
                studyRecord.StudyDate = st.StudyDate;
                studyRecord.StudyTime = st.StudyTime;
                studyRecord.AccessionNumber = st.AccessionNumber;
                studyRecord.StudyDescription = st.StudyDescription;
                studyRecord.ReferringPhysicianName = st.ReferringPhysicianName;
                studyRecord.IndexedAtUtc = DateTime.UtcNow;
            }

            // 3. Upsert Series
            var seriesRecord = await _db.Series
                .FirstOrDefaultAsync(s => s.TenantId == tenantId && s.StudyInstanceUid == st.StudyInstanceUid && s.SeriesInstanceUid == se.SeriesInstanceUid, ct);

            var commonJson = JsonSerializer.Serialize(manifest.CommonInstanceMetadata);

            if (seriesRecord == null)
            {
                seriesRecord = new SeriesRecord
                {
                    TenantId = tenantId,
                    StudyInstanceUid = st.StudyInstanceUid,
                    SeriesInstanceUid = se.SeriesInstanceUid,
                    Modality = se.Modality,
                    SeriesNumber = se.SeriesNumber,
                    SeriesDescription = se.SeriesDescription,
                    BodyPartExamined = se.BodyPartExamined,
                    NumberOfSeriesRelatedInstances = manifest.TotalInstances,
                    TotalSizeBytes = manifest.TotalSizeBytes,
                    ManifestS3Key = manifest.ManifestS3Key,
                    CommonMetadataJson = commonJson,
                    IndexedAtUtc = DateTime.UtcNow
                };
                _db.Series.Add(seriesRecord);
            }
            else
            {
                seriesRecord.Modality = se.Modality;
                seriesRecord.SeriesNumber = se.SeriesNumber;
                seriesRecord.SeriesDescription = se.SeriesDescription;
                seriesRecord.BodyPartExamined = se.BodyPartExamined;
                seriesRecord.NumberOfSeriesRelatedInstances = manifest.TotalInstances;
                seriesRecord.TotalSizeBytes = manifest.TotalSizeBytes;
                seriesRecord.ManifestS3Key = manifest.ManifestS3Key;
                seriesRecord.CommonMetadataJson = commonJson;
                seriesRecord.IndexedAtUtc = DateTime.UtcNow;
            }

            // 4. Fast native bulk cleanup of existing instances for this series (zero memory overhead)
            await _db.Instances
                .Where(i => i.TenantId == tenantId && i.StudyInstanceUid == st.StudyInstanceUid && i.SeriesInstanceUid == se.SeriesInstanceUid)
                .ExecuteDeleteAsync(ct);

            // Add new instances (EF Core batches multi-row INSERTs)
            var instanceRecords = manifest.Instances.Select(inst => new InstanceRecord
            {
                TenantId = tenantId,
                StudyInstanceUid = st.StudyInstanceUid,
                SeriesInstanceUid = se.SeriesInstanceUid,
                SopInstanceUid = inst.SopInstanceUid,
                InstanceNumber = inst.InstanceNumber,
                SopClassUid = inst.Overrides?.SopClassUid ?? manifest.CommonInstanceMetadata?.SopClassUid,
                DestinationS3Key = inst.DestinationS3Key,
                SourceS3Key = inst.SourceS3Key,
                FileSizeBytes = inst.FileSizeBytes,
                OverridesJson = inst.Overrides != null ? JsonSerializer.Serialize(inst.Overrides) : null,
                IndexedAtUtc = DateTime.UtcNow
            }).ToList();

            _db.Instances.AddRange(instanceRecords);
            await _db.SaveChangesAsync(ct);

            // 5. Single-Pass Aggregate Update via modern SQLite UPDATE ... FROM
            await _db.Database.ExecuteSqlInterpolatedAsync($@"
                UPDATE Studies
                SET 
                    NumberOfStudyRelatedSeries = agg.SeriesCount,
                    NumberOfStudyRelatedInstances = agg.InstanceCount,
                    ModalitiesInStudy = agg.Modalities
                FROM (
                    SELECT 
                        COUNT(*) AS SeriesCount,
                        COALESCE(SUM(NumberOfSeriesRelatedInstances), 0) AS InstanceCount,
                        COALESCE(REPLACE(GROUP_CONCAT(DISTINCT Modality), ',', '\'), '') AS Modalities
                    FROM Series
                    WHERE TenantId = {tenantId} AND StudyInstanceUid = {st.StudyInstanceUid}
                ) AS agg
                WHERE Studies.TenantId = {tenantId} AND Studies.StudyInstanceUid = {st.StudyInstanceUid};", ct);

            await tx.CommitAsync(ct);
            _db.ChangeTracker.Clear();

            _logger.LogDebug("Indexed manifest for tenant {TenantId}, Study {StudyUid}, Series {SeriesUid} ({Instances} instances)",
                tenantId, st.StudyInstanceUid, se.SeriesInstanceUid, manifest.TotalInstances);
            }
            catch
            {
                await tx.RollbackAsync(ct);
                throw;
            }
        }
        finally
        {
            _dbWriteLock.Release();
        }
    }

    public async Task<IndexSyncResult> RebuildIndexFromS3Async(string tenantId, string? destinationBucket = null, CancellationToken ct = default)
    {
        var sw = Stopwatch.StartNew();
        var bucket = string.IsNullOrWhiteSpace(destinationBucket) ? _minioOptions.DefaultDestinationBucket : destinationBucket.Trim();
        var prefix = $"{tenantId.Trim()}/";

        var result = new IndexSyncResult
        {
            TenantId = tenantId
        };

        try
        {
            // Clean up any empty records if present using high-speed ExecuteDeleteAsync
            await _db.Studies.Where(s => s.TenantId == tenantId && (s.StudyInstanceUid == "" || s.StudyInstanceUid == null)).ExecuteDeleteAsync(ct);
            await _db.Series.Where(s => s.TenantId == tenantId && (s.SeriesInstanceUid == "" || s.SeriesInstanceUid == null)).ExecuteDeleteAsync(ct);
            await _db.Patients.Where(p => p.TenantId == tenantId && (p.PatientId == "" || p.PatientId == null)).ExecuteDeleteAsync(ct);

            var s3Items = await _s3Service.ListObjectsAsync(bucket, prefix, ct);
            var manifestKeys = s3Items
                .Where(x => x.Key.EndsWith("/manifest.json", StringComparison.OrdinalIgnoreCase))
                .Select(x => x.Key)
                .ToList();

            result.ManifestsScanned = manifestKeys.Count;

            foreach (var key in manifestKeys)
            {
                try
                {
                    using var stream = await _s3Service.GetStreamAsync(bucket, key, ct);
                    var manifest = await JsonSerializer.DeserializeAsync<SeriesManifest>(stream, JsonOptions, cancellationToken: ct);
                    if (manifest != null && !string.IsNullOrWhiteSpace(manifest.Study?.StudyInstanceUid))
                    {
                        await IndexManifestAsync(manifest, ct);
                        result.SeriesIndexed++;
                        result.InstancesIndexed += manifest.TotalInstances;
                    }
                }
                catch (Exception ex)
                {
                    _logger.LogError(ex, "Failed to index manifest from key {Key}", key);
                    result.Errors.Add($"Key {key}: {ex.Message}");
                }
            }

            result.StudiesIndexed = await _db.Studies.CountAsync(s => s.TenantId == tenantId && s.StudyInstanceUid != "", ct);
            result.Success = result.Errors.Count == 0;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Failed to rebuild index from S3 for tenant {TenantId}", tenantId);
            result.Success = false;
            result.Errors.Add(ex.Message);
        }
        finally
        {
            sw.Stop();
            result.DurationMs = Math.Round(sw.Elapsed.TotalMilliseconds, 2);
        }

        return result;
    }

    public async Task<IndexStatsDto> GetIndexStatsAsync(string tenantId, CancellationToken ct = default)
    {
        return new IndexStatsDto
        {
            TenantId = tenantId,
            PatientCount = await _db.Patients.CountAsync(p => p.TenantId == tenantId, ct),
            StudyCount = await _db.Studies.CountAsync(s => s.TenantId == tenantId, ct),
            SeriesCount = await _db.Series.CountAsync(s => s.TenantId == tenantId, ct),
            InstanceCount = await _db.Instances.CountAsync(i => i.TenantId == tenantId, ct)
        };
    }

    public async Task<List<StudyRecord>> QueryStudiesAsync(string tenantId, QidoStudyQuery query, CancellationToken ct = default)
    {
        var q = _db.Studies
            .AsNoTracking()
            .Include(s => s.Patient)
            .Where(s => s.TenantId == tenantId && s.StudyInstanceUid != "");

        if (!string.IsNullOrWhiteSpace(query.StudyInstanceUID))
        {
            q = q.Where(s => s.StudyInstanceUid == query.StudyInstanceUID.Trim());
        }

        if (!string.IsNullOrWhiteSpace(query.PatientID))
        {
            var patId = query.PatientID.Trim();
            if (patId.Contains('*') || patId.Contains('?'))
            {
                var pattern = patId.Replace('*', '%').Replace('?', '_');
                q = q.Where(s => EF.Functions.Like(s.PatientId, pattern));
            }
            else
            {
                q = q.Where(s => s.PatientId == patId);
            }
        }

        if (!string.IsNullOrWhiteSpace(query.PatientName))
        {
            var patName = query.PatientName.Trim();
            if (patName.Contains('*') || patName.Contains('?'))
            {
                var pattern = patName.Replace('*', '%').Replace('?', '_');
                q = q.Where(s => s.Patient != null && EF.Functions.Like(s.Patient.PatientName, pattern));
            }
            else
            {
                q = q.Where(s => s.Patient != null && EF.Functions.Like(s.Patient.PatientName, $"%{patName}%"));
            }
        }

        if (!string.IsNullOrWhiteSpace(query.AccessionNumber))
        {
            var acc = query.AccessionNumber.Trim();
            if (acc.Contains('*') || acc.Contains('?'))
            {
                var pattern = acc.Replace('*', '%').Replace('?', '_');
                q = q.Where(s => s.AccessionNumber != null && EF.Functions.Like(s.AccessionNumber, pattern));
            }
            else
            {
                q = q.Where(s => s.AccessionNumber == acc);
            }
        }

        if (!string.IsNullOrWhiteSpace(query.StudyDate))
        {
            var dateParam = query.StudyDate.Trim();
            if (dateParam.Contains('-'))
            {
                var parts = dateParam.Split('-');
                if (!string.IsNullOrWhiteSpace(parts[0]))
                    q = q.Where(s => s.StudyDate != null && string.Compare(s.StudyDate, parts[0]) >= 0);
                if (parts.Length > 1 && !string.IsNullOrWhiteSpace(parts[1]))
                    q = q.Where(s => s.StudyDate != null && string.Compare(s.StudyDate, parts[1]) <= 0);
            }
            else
            {
                q = q.Where(s => s.StudyDate == dateParam);
            }
        }

        if (!string.IsNullOrWhiteSpace(query.ModalitiesInStudy))
        {
            var mod = query.ModalitiesInStudy.Trim();
            q = q.Where(s => s.ModalitiesInStudy != null && EF.Functions.Like(s.ModalitiesInStudy, $"%{mod}%"));
        }

        if (!string.IsNullOrWhiteSpace(query.ReferringPhysicianName))
        {
            var doc = query.ReferringPhysicianName.Replace("*", "").Trim();
            q = q.Where(s => s.ReferringPhysicianName != null && EF.Functions.Like(s.ReferringPhysicianName, $"%{doc}%"));
        }

        if (!string.IsNullOrWhiteSpace(query.StudyDescription))
        {
            var desc = query.StudyDescription.Trim();
            if (desc.Contains('*') || desc.Contains('?'))
            {
                var pattern = desc.Replace('*', '%').Replace('?', '_');
                q = q.Where(s => s.StudyDescription != null && EF.Functions.Like(s.StudyDescription, pattern));
            }
            else
            {
                q = q.Where(s => s.StudyDescription != null && EF.Functions.Like(s.StudyDescription, $"%{desc}%"));
            }
        }

        var limit = Math.Clamp(query.Limit, 1, 1000);
        var offset = Math.Max(0, query.Offset);

        return await q.OrderBy(s => s.StudyDate).Skip(offset).Take(limit).ToListAsync(ct);
    }

    public async Task<List<SeriesRecord>> QuerySeriesAsync(string tenantId, string? studyInstanceUid, QidoSeriesQuery query, CancellationToken ct = default)
    {
        var q = _db.Series
            .AsNoTracking()
            .Include(s => s.Study)
            .Where(s => s.TenantId == tenantId && s.SeriesInstanceUid != "");

        if (!string.IsNullOrWhiteSpace(studyInstanceUid))
        {
            q = q.Where(s => s.StudyInstanceUid == studyInstanceUid.Trim());
        }

        if (!string.IsNullOrWhiteSpace(query.SeriesInstanceUID))
        {
            q = q.Where(s => s.SeriesInstanceUid == query.SeriesInstanceUID.Trim());
        }

        if (!string.IsNullOrWhiteSpace(query.Modality))
        {
            q = q.Where(s => s.Modality == query.Modality.Trim());
        }

        if (!string.IsNullOrWhiteSpace(query.SeriesNumber))
        {
            q = q.Where(s => s.SeriesNumber == query.SeriesNumber.Trim());
        }

        var limit = Math.Clamp(query.Limit, 1, 1000);
        var offset = Math.Max(0, query.Offset);

        return await q.OrderBy(s => s.SeriesNumber).Skip(offset).Take(limit).ToListAsync(ct);
    }

    public async Task<List<InstanceRecord>> QueryInstancesAsync(string tenantId, string? studyInstanceUid, string? seriesInstanceUid, QidoInstanceQuery query, CancellationToken ct = default)
    {
        var q = _db.Instances
            .AsNoTracking()
            .Where(i => i.TenantId == tenantId && i.SopInstanceUid != "");

        if (!string.IsNullOrWhiteSpace(studyInstanceUid))
        {
            q = q.Where(i => i.StudyInstanceUid == studyInstanceUid.Trim());
        }

        if (!string.IsNullOrWhiteSpace(seriesInstanceUid))
        {
            q = q.Where(i => i.SeriesInstanceUid == seriesInstanceUid.Trim());
        }

        if (!string.IsNullOrWhiteSpace(query.SOPInstanceUID))
        {
            q = q.Where(i => i.SopInstanceUid == query.SOPInstanceUID.Trim());
        }

        if (!string.IsNullOrWhiteSpace(query.SOPClassUID))
        {
            q = q.Where(i => i.SopClassUid == query.SOPClassUID.Trim());
        }

        if (!string.IsNullOrWhiteSpace(query.InstanceNumber))
        {
            q = q.Where(i => i.InstanceNumber == query.InstanceNumber.Trim());
        }

        var limit = Math.Clamp(query.Limit, 1, 1000);
        var offset = Math.Max(0, query.Offset);

        return await q.OrderBy(i => i.InstanceNumber).Skip(offset).Take(limit).ToListAsync(ct);
    }

    public async Task<InstanceRecord?> GetInstanceAsync(string tenantId, string studyUid, string seriesUid, string sopUid, CancellationToken ct = default)
    {
        return await _db.Instances
            .AsNoTracking()
            .FirstOrDefaultAsync(i =>
                i.TenantId == tenantId &&
                i.StudyInstanceUid == studyUid &&
                i.SeriesInstanceUid == seriesUid &&
                i.SopInstanceUid == sopUid, ct);
    }

    public async Task<List<InstanceRecord>> GetSeriesInstancesAsync(string tenantId, string studyUid, string seriesUid, CancellationToken ct = default)
    {
        return await _db.Instances
            .AsNoTracking()
            .Where(i =>
                i.TenantId == tenantId &&
                i.StudyInstanceUid == studyUid &&
                i.SeriesInstanceUid == seriesUid)
            .OrderBy(i => i.InstanceNumber)
            .ToListAsync(ct);
    }

    public async Task<List<InstanceRecord>> GetStudyInstancesAsync(string tenantId, string studyUid, CancellationToken ct = default)
    {
        return await _db.Instances
            .AsNoTracking()
            .Where(i =>
                i.TenantId == tenantId &&
                i.StudyInstanceUid == studyUid)
            .OrderBy(i => i.SeriesInstanceUid)
            .ThenBy(i => i.InstanceNumber)
            .ToListAsync(ct);
    }

    public async Task<CleanupResult> CleanupAsync(CleanupRequest request, CancellationToken ct = default)
    {
        var sw = Stopwatch.StartNew();
        var tenantId = string.IsNullOrWhiteSpace(request.TenantId) ? "tenant-001" : request.TenantId.Trim();
        var result = new CleanupResult
        {
            TenantId = tenantId
        };

        await _dbWriteLock.WaitAsync(ct);
        try
        {
            // 1. Database Cleanup
            if (request.CleanupDatabase)
            {
                if (request.AllTenants)
                {
                    result.DeletedInstances = await _db.Instances.ExecuteDeleteAsync(ct);
                    result.DeletedSeries = await _db.Series.ExecuteDeleteAsync(ct);
                    result.DeletedStudies = await _db.Studies.ExecuteDeleteAsync(ct);
                    result.DeletedPatients = await _db.Patients.ExecuteDeleteAsync(ct);
                }
                else
                {
                    result.DeletedInstances = await _db.Instances.Where(i => i.TenantId == tenantId).ExecuteDeleteAsync(ct);
                    result.DeletedSeries = await _db.Series.Where(s => s.TenantId == tenantId).ExecuteDeleteAsync(ct);
                    result.DeletedStudies = await _db.Studies.Where(s => s.TenantId == tenantId).ExecuteDeleteAsync(ct);
                    result.DeletedPatients = await _db.Patients.Where(p => p.TenantId == tenantId).ExecuteDeleteAsync(ct);
                }

                try
                {
                    await _db.Database.ExecuteSqlRawAsync("PRAGMA wal_checkpoint(PASSIVE);", ct);
                }
                catch (Exception ex)
                {
                    _logger.LogDebug(ex, "WAL checkpoint skipped or unsupported in current provider");
                }

                result.Messages.Add($"Database records purged: {result.DeletedInstances} instances, {result.DeletedSeries} series, {result.DeletedStudies} studies, {result.DeletedPatients} patients.");
            }

            // 2. S3 Destination Folder Cleanup
            if (request.CleanupDestinationS3)
            {
                var destBucket = string.IsNullOrWhiteSpace(request.DestinationBucket) ? _minioOptions.DefaultDestinationBucket : request.DestinationBucket.Trim();
                var prefix = request.AllTenants ? "" : $"{tenantId}/";
                var deleted = await _s3Service.DeleteObjectsByPrefixAsync(destBucket, prefix, ct);
                result.DeletedDestinationS3Objects = deleted;
                result.Messages.Add($"S3 destination bucket '{destBucket}' prefix '{prefix}' purged: {deleted} objects deleted.");
            }

            // 3. S3 Source Folder Cleanup (Optional)
            if (request.CleanupSourceS3 && !string.IsNullOrWhiteSpace(request.SourcePrefix))
            {
                var srcBucket = string.IsNullOrWhiteSpace(request.SourceBucket) ? _minioOptions.DefaultSourceBucket : request.SourceBucket.Trim();
                var prefix = request.SourcePrefix.Trim().TrimStart('/');
                var deleted = await _s3Service.DeleteObjectsByPrefixAsync(srcBucket, prefix, ct);
                result.DeletedSourceS3Objects = deleted;
                result.Messages.Add($"S3 source bucket '{srcBucket}' prefix '{prefix}' purged: {deleted} objects deleted.");
            }

            result.Success = true;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error during cleanup for tenant {TenantId}", tenantId);
            result.Success = false;
            result.Errors.Add(ex.Message);
        }
        finally
        {
            _dbWriteLock.Release();
            sw.Stop();
            result.DurationMs = Math.Round(sw.Elapsed.TotalMilliseconds, 2);
        }

        return result;
    }
}
