using System.Collections.Concurrent;
using System.Diagnostics;
using DicomIngestion.Api.Models;
using FellowOakDicom;
using FellowOakDicom.IO.Buffer;
using Microsoft.Extensions.Options;

namespace DicomIngestion.Api.Services;

public interface IDicomDataGenerator
{
    Task<GenerateDataResponse> GenerateAndUploadBatchAsync(GenerateDataRequest request, CancellationToken ct = default);
}

public class DicomDataGenerator : IDicomDataGenerator
{
    private readonly IS3StorageService _s3Service;
    private readonly MinioOptions _minioOptions;
    private readonly ILogger<DicomDataGenerator> _logger;

    public DicomDataGenerator(
        IS3StorageService s3Service,
        IOptions<MinioOptions> minioOptions,
        ILogger<DicomDataGenerator> logger)
    {
        _s3Service = s3Service;
        _minioOptions = minioOptions.Value;
        _logger = logger;
    }

    public async Task<GenerateDataResponse> GenerateAndUploadBatchAsync(GenerateDataRequest request, CancellationToken ct = default)
    {
        var totalSw = Stopwatch.StartNew();
        var bucket = string.IsNullOrWhiteSpace(request.Bucket)
            ? _minioOptions.DefaultSourceBucket
            : request.Bucket;

        await _s3Service.EnsureBucketExistsAsync(bucket, ct);

        var pixelByteLength = ResolvePixelPayloadSize(request.PayloadSize);
        var fileCount = Math.Max(1, request.FileCount);
        var studyCount = Math.Max(1, request.StudyCount);
        var seriesPerStudy = Math.Max(1, request.SeriesPerStudy);

        var prefix = request.Prefix.TrimEnd('/') + "/";

        var pixelBuffer = new byte[pixelByteLength];
        new Random(42).NextBytes(pixelBuffer);

        var studies = Enumerable.Range(1, studyCount)
            .Select(i => $"1.2.840.10008.1.1.{DateTime.UtcNow.Ticks}.{i}")
            .ToList();

        var seriesList = new List<(string StudyUid, string SeriesUid, int SeriesNumber, string S3Folder)>();
        foreach (var studyUid in studies)
        {
            for (int s = 1; s <= seriesPerStudy; s++)
            {
                var sUid = $"{studyUid}.{s}";
                var sFolder = request.OrganizeBySeriesFolders ? $"{prefix}series-{s}/" : prefix;
                seriesList.Add((studyUid, sUid, s, sFolder));
            }
        }

        long totalBytesWritten = 0;
        var parallelOptions = new ParallelOptions
        {
            MaxDegreeOfParallelism = 16,
            CancellationToken = ct
        };

        var countsPerSeries = new ConcurrentDictionary<string, int>();

        await Parallel.ForEachAsync(Enumerable.Range(1, fileCount), parallelOptions, async (idx, token) =>
        {
            var seriesInfo = seriesList[(idx - 1) % seriesList.Count];
            countsPerSeries.AddOrUpdate(seriesInfo.SeriesUid, 1, (_, current) => current + 1);

            var sopUid = $"{seriesInfo.SeriesUid}.{idx}";
            var patientId = $"PAT-{(idx % 10):D4}";

            var isVariantInstance = (idx % 5 == 0);
            var rows = isVariantInstance ? (ushort)256 : (ushort)512;
            var cols = isVariantInstance ? (ushort)256 : (ushort)512;

            var sopClassUid = request.IsMultiFrame
                ? DicomUID.MultiFrameGrayscaleByteSecondaryCaptureImageStorage
                : DicomUID.SecondaryCaptureImageStorage;

            var dataset = new DicomDataset(DicomTransferSyntax.ExplicitVRLittleEndian)
            {
                { DicomTag.FileMetaInformationVersion, new byte[] { 0, 1 } },
                { DicomTag.MediaStorageSOPClassUID, sopClassUid },
                { DicomTag.MediaStorageSOPInstanceUID, sopUid },
                { DicomTag.TransferSyntaxUID, DicomTransferSyntax.ExplicitVRLittleEndian.UID },
                { DicomTag.ImplementationClassUID, "1.2.826.0.1.3680043.9.7433.1.0" },

                { DicomTag.ImageType, @"ORIGINAL\PRIMARY\AXIAL" },
                { DicomTag.SpecificCharacterSet, "ISO_IR 100" },
                { DicomTag.SOPClassUID, sopClassUid },
                { DicomTag.SOPInstanceUID, sopUid },
                { DicomTag.StudyInstanceUID, seriesInfo.StudyUid },
                { DicomTag.SeriesInstanceUID, seriesInfo.SeriesUid },

                // Patient Level
                { DicomTag.PatientID, patientId },
                { DicomTag.IssuerOfPatientID, "CLINIC-HEALTH-SYS-1" },
                { DicomTag.PatientName, $"BENCHMARK^PATIENT^{patientId}" },
                { DicomTag.PatientBirthDate, "19850615" },
                { DicomTag.PatientSex, (idx % 2 == 0) ? "M" : "F" },

                // Study Level
                { DicomTag.StudyDate, DateTime.UtcNow.ToString("yyyyMMdd") },
                { DicomTag.StudyTime, DateTime.UtcNow.ToString("HHmmss") },
                { DicomTag.AccessionNumber, $"ACC-BNC-{idx:D6}" },
                { DicomTag.StudyDescription, "DICOM INGESTION BENCHMARK TEST" },
                { DicomTag.ReferringPhysicianName, "DR^HOUSE^GREGORY" },

                // Series Level
                { DicomTag.Modality, request.IsMultiFrame ? "US" : "CT" },
                { DicomTag.SeriesNumber, seriesInfo.SeriesNumber.ToString() },
                { DicomTag.SeriesDescription, $"Slice Series {seriesInfo.SeriesNumber}" },
                { DicomTag.BodyPartExamined, "CHEST" },
                { DicomTag.InstanceNumber, idx.ToString() },

                // Image / Pixel Structure (single vs multi-frame)
                { DicomTag.PhotometricInterpretation, "MONOCHROME2" },
                { DicomTag.Rows, rows },
                { DicomTag.Columns, cols },
                { DicomTag.BitsAllocated, (ushort)16 },
                { DicomTag.BitsStored, (ushort)16 },
                { DicomTag.HighBit, (ushort)15 },
                { DicomTag.PixelRepresentation, (ushort)0 },
                { DicomTag.SamplesPerPixel, (ushort)1 }
            };

            if (request.IsMultiFrame)
            {
                dataset.AddOrUpdate(DicomTag.NumberOfFrames, request.NumberOfFrames.ToString());
            }

            // Add PixelData payload
            dataset.AddOrUpdate(new DicomOtherByte(DicomTag.PixelData, new MemoryByteBuffer(pixelBuffer)));

            var file = new DicomFile(dataset);
            using var memoryStream = new MemoryStream();
            await file.SaveAsync(memoryStream);
            memoryStream.Position = 0;
            var fileLength = memoryStream.Length;

            var key = $"{seriesInfo.S3Folder}slice_{idx:D5}.dcm";
            await _s3Service.PutObjectAsync(bucket, key, memoryStream, fileLength, "application/dicom", token);

            Interlocked.Add(ref totalBytesWritten, fileLength);
        });

        totalSw.Stop();
        var totalSec = totalSw.Elapsed.TotalSeconds;

        var generatedSeriesList = seriesList
            .GroupBy(x => x.SeriesUid)
            .Select(g =>
            {
                var item = g.First();
                countsPerSeries.TryGetValue(item.SeriesUid, out var count);
                return new GeneratedSeriesInfo
                {
                    StudyInstanceUid = item.StudyUid,
                    SeriesInstanceUid = item.SeriesUid,
                    S3Prefix = item.S3Folder,
                    FileCount = count
                };
            })
            .ToList();

        return new GenerateDataResponse
        {
            Success = true,
            Bucket = bucket,
            Prefix = prefix,
            TotalFilesGenerated = fileCount,
            TotalSizeBytes = totalBytesWritten,
            TotalDurationMs = Math.Round(totalSw.Elapsed.TotalMilliseconds, 2),
            FilesPerSecond = totalSec > 0 ? Math.Round(fileCount / totalSec, 2) : 0,
            GeneratedSeries = generatedSeriesList
        };
    }

    private static int ResolvePixelPayloadSize(string payloadOption)
    {
        if (int.TryParse(payloadOption, out var explicitBytes) && explicitBytes > 0)
        {
            return explicitBytes;
        }

        return payloadOption.ToLowerInvariant() switch
        {
            "small" or "50kb" => 50 * 1024,          // ~50 KB
            "medium" or "512kb" => 512 * 1024,      // ~512 KB
            "large" or "10mb" => 10 * 1024 * 1024,  // ~10 MB
            "xlarge" or "30mb" => 30 * 1024 * 1024, // ~30 MB
            _ => 512 * 1024
        };
    }
}
