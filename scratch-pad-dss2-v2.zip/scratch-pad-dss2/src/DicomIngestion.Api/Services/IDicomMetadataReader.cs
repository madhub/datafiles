using DicomIngestion.Api.Models;

namespace DicomIngestion.Api.Services;

public interface IDicomMetadataReader
{
    Task<ParsedDicomRecord> ExtractMetadataAsync(Stream dicomStream, string sourceKey, long fileSize, CancellationToken ct = default);
}
