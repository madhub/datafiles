using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace DicomIngestion.Api.Data;

[Table("Patients")]
public class PatientRecord
{
    [Required]
    [MaxLength(64)]
    public string TenantId { get; set; } = "tenant-001";

    [Required]
    [MaxLength(64)]
    public string PatientId { get; set; } = string.Empty;

    [MaxLength(64)]
    public string? IssuerOfPatientId { get; set; }

    [MaxLength(256)]
    public string PatientName { get; set; } = string.Empty;

    [MaxLength(16)]
    public string? PatientBirthDate { get; set; }

    [MaxLength(16)]
    public string? PatientSex { get; set; }

    public DateTime IndexedAtUtc { get; set; } = DateTime.UtcNow;

    public List<StudyRecord> Studies { get; set; } = new();
}

[Table("Studies")]
public class StudyRecord
{
    [Required]
    [MaxLength(64)]
    public string TenantId { get; set; } = "tenant-001";

    [Required]
    [MaxLength(128)]
    public string StudyInstanceUid { get; set; } = string.Empty;

    [Required]
    [MaxLength(64)]
    public string PatientId { get; set; } = string.Empty;

    [MaxLength(16)]
    public string? StudyDate { get; set; }

    [MaxLength(16)]
    public string? StudyTime { get; set; }

    [MaxLength(64)]
    public string? AccessionNumber { get; set; }

    [MaxLength(256)]
    public string? StudyDescription { get; set; }

    [MaxLength(256)]
    public string? ReferringPhysicianName { get; set; }

    public int NumberOfStudyRelatedSeries { get; set; }
    public int NumberOfStudyRelatedInstances { get; set; }

    [MaxLength(64)]
    public string? ModalitiesInStudy { get; set; }

    public DateTime IndexedAtUtc { get; set; } = DateTime.UtcNow;

    public PatientRecord? Patient { get; set; }
    public List<SeriesRecord> Series { get; set; } = new();
}

[Table("Series")]
public class SeriesRecord
{
    [Required]
    [MaxLength(64)]
    public string TenantId { get; set; } = "tenant-001";

    [Required]
    [MaxLength(128)]
    public string StudyInstanceUid { get; set; } = string.Empty;

    [Required]
    [MaxLength(128)]
    public string SeriesInstanceUid { get; set; } = string.Empty;

    [MaxLength(16)]
    public string? Modality { get; set; }

    [MaxLength(16)]
    public string? SeriesNumber { get; set; }

    [MaxLength(256)]
    public string? SeriesDescription { get; set; }

    [MaxLength(64)]
    public string? BodyPartExamined { get; set; }

    public int NumberOfSeriesRelatedInstances { get; set; }
    public long TotalSizeBytes { get; set; }

    [MaxLength(512)]
    public string ManifestS3Key { get; set; } = string.Empty;

    public string? CommonMetadataJson { get; set; }

    public DateTime IndexedAtUtc { get; set; } = DateTime.UtcNow;

    public StudyRecord? Study { get; set; }
    public List<InstanceRecord> Instances { get; set; } = new();
}

[Table("Instances")]
public class InstanceRecord
{
    [Required]
    [MaxLength(64)]
    public string TenantId { get; set; } = "tenant-001";

    [Required]
    [MaxLength(128)]
    public string StudyInstanceUid { get; set; } = string.Empty;

    [Required]
    [MaxLength(128)]
    public string SeriesInstanceUid { get; set; } = string.Empty;

    [Required]
    [MaxLength(128)]
    public string SopInstanceUid { get; set; } = string.Empty;

    [MaxLength(16)]
    public string? InstanceNumber { get; set; }

    [MaxLength(128)]
    public string? SopClassUid { get; set; }

    [Required]
    [MaxLength(512)]
    public string DestinationS3Key { get; set; } = string.Empty;

    [MaxLength(512)]
    public string? SourceS3Key { get; set; }

    public long FileSizeBytes { get; set; }

    public string? OverridesJson { get; set; }

    public DateTime IndexedAtUtc { get; set; } = DateTime.UtcNow;

    public SeriesRecord? Series { get; set; }
}
