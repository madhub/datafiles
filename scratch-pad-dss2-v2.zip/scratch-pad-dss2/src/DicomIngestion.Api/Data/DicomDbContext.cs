using Microsoft.EntityFrameworkCore;

namespace DicomIngestion.Api.Data;

public class DicomDbContext : DbContext
{
    public DicomDbContext(DbContextOptions<DicomDbContext> options) : base(options)
    {
    }

    public DbSet<PatientRecord> Patients => Set<PatientRecord>();
    public DbSet<StudyRecord> Studies => Set<StudyRecord>();
    public DbSet<SeriesRecord> Series => Set<SeriesRecord>();
    public DbSet<InstanceRecord> Instances => Set<InstanceRecord>();

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        base.OnModelCreating(modelBuilder);

        // Patient Entity
        modelBuilder.Entity<PatientRecord>(entity =>
        {
            entity.HasKey(p => new { p.TenantId, p.PatientId });
            entity.HasIndex(p => new { p.TenantId, p.PatientName });
        });

        // Study Entity
        modelBuilder.Entity<StudyRecord>(entity =>
        {
            entity.HasKey(s => new { s.TenantId, s.StudyInstanceUid });
            entity.HasIndex(s => new { s.TenantId, s.PatientId });
            entity.HasIndex(s => new { s.TenantId, s.StudyDate });
            entity.HasIndex(s => new { s.TenantId, s.AccessionNumber });
            entity.HasIndex(s => new { s.TenantId, s.StudyDescription });

            entity.HasOne(s => s.Patient)
                .WithMany(p => p.Studies)
                .HasForeignKey(s => new { s.TenantId, s.PatientId })
                .OnDelete(DeleteBehavior.Cascade);
        });

        // Series Entity
        modelBuilder.Entity<SeriesRecord>(entity =>
        {
            entity.HasKey(s => new { s.TenantId, s.StudyInstanceUid, s.SeriesInstanceUid });
            entity.HasIndex(s => new { s.TenantId, s.StudyInstanceUid });
            entity.HasIndex(s => new { s.TenantId, s.Modality });

            entity.HasOne(s => s.Study)
                .WithMany(st => st.Series)
                .HasForeignKey(s => new { s.TenantId, s.StudyInstanceUid })
                .OnDelete(DeleteBehavior.Cascade);
        });

        // Instance Entity
        modelBuilder.Entity<InstanceRecord>(entity =>
        {
            entity.HasKey(i => new { i.TenantId, i.StudyInstanceUid, i.SeriesInstanceUid, i.SopInstanceUid });
            entity.HasIndex(i => new { i.TenantId, i.SopInstanceUid });
            entity.HasIndex(i => new { i.TenantId, i.SeriesInstanceUid });

            entity.HasOne(i => i.Series)
                .WithMany(s => s.Instances)
                .HasForeignKey(i => new { i.TenantId, i.StudyInstanceUid, i.SeriesInstanceUid })
                .OnDelete(DeleteBehavior.Cascade);
        });
    }
}
