using Amazon.S3;
using DicomIngestion.Api.Data;
using DicomIngestion.Api.Models;
using DicomIngestion.Api.Services;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Options;

var builder = WebApplication.CreateBuilder(args);

// Bind Configuration Options
builder.Services.Configure<MinioOptions>(
    builder.Configuration.GetSection(MinioOptions.SectionName));
builder.Services.Configure<IngestionOptions>(
    builder.Configuration.GetSection(IngestionOptions.SectionName));

// Configure SQLite Relational Index Database
builder.Services.AddDbContext<DicomDbContext>(options =>
{
    var connStr = builder.Configuration.GetConnectionString("DicomIndexDb") ?? "Data Source=data/dicom_index.db";
    options.UseSqlite(connStr);
});

// Configure Amazon S3 Client for RustFS / MinIO
builder.Services.AddSingleton<IAmazonS3>(sp =>
{
    var minio = sp.GetRequiredService<IOptions<MinioOptions>>().Value;
    var config = new AmazonS3Config
    {
        ServiceURL = minio.ServiceUrl,
        ForcePathStyle = minio.ForcePathStyle,
        UseHttp = minio.ServiceUrl.StartsWith("http://", StringComparison.OrdinalIgnoreCase),
        AuthenticationRegion = minio.Region
    };
    return new AmazonS3Client(minio.AccessKey, minio.SecretKey, config);
});

// Register Pipeline & DICOMweb Services
builder.Services.AddSingleton<IKeyedLockService, KeyedLockService>();
builder.Services.AddSingleton<IS3StorageService, S3StorageService>();
builder.Services.AddSingleton<IDicomMetadataReader, DicomMetadataReader>();
builder.Services.AddScoped<IDicomIndexService, DicomIndexService>();
builder.Services.AddScoped<IIngestionPipeline, IngestionPipeline>();
builder.Services.AddScoped<IDicomDataGenerator, DicomDataGenerator>();

builder.Services.AddControllers();
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen(c =>
{
    c.SwaggerDoc("v1", new()
    {
        Title = "DICOM Ingestion, QIDO-RS & WADO-RS API",
        Version = "v1",
        Description = "High-performance DICOM ingestion pipeline with RustFS/MinIO, SQLite relational index, QIDO-RS hierarchical queries, and WADO-RS Part 10 retrieval"
    });
});

var app = builder.Build();

// Ensure SQLite database and WAL mode are initialized on startup
using (var scope = app.Services.CreateScope())
{
    var db = scope.ServiceProvider.GetRequiredService<DicomDbContext>();
    Directory.CreateDirectory("data");
    await db.Database.EnsureCreatedAsync();
    await db.Database.ExecuteSqlRawAsync(@"
        PRAGMA journal_mode = WAL;
        PRAGMA synchronous = NORMAL;
        PRAGMA busy_timeout = 5000;
        PRAGMA mmap_size = 268435456;
        PRAGMA cache_size = -64000;
        PRAGMA temp_store = MEMORY;
    ");
}

// Enable Swagger UI in both Development and Production for easy benchmarking & inspection
app.UseSwagger();
app.UseSwaggerUI(c =>
{
    c.SwaggerEndpoint("/swagger/v1/swagger.json", "DICOM Ingestion & DICOMweb API v1");
    c.RoutePrefix = string.Empty; // Serve Swagger at app root
});

app.UseAuthorization();
app.MapControllers();

app.Run();
