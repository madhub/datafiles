namespace DicomIngestion.Api.Models;

public class MinioOptions
{
    public const string SectionName = "Minio";

    public string ServiceUrl { get; set; } = "http://127.0.0.1:9000";
    public string AccessKey { get; set; } = "minioadmin";
    public string SecretKey { get; set; } = "minioadmin";
    public bool ForcePathStyle { get; set; } = true;
    public string Region { get; set; } = "us-east-1";
    public string DefaultSourceBucket { get; set; } = "dicom-source";
    public string DefaultDestinationBucket { get; set; } = "dicom-destination";
}

public class IngestionOptions
{
    public const string SectionName = "Ingestion";

    public int DefaultConcurrency { get; set; } = 16;
    public int HeaderReadChunkSizeBytes { get; set; } = 131072; // 128 KB
}
