using Microsoft.AspNetCore.Http;

namespace DicomIngestion.Api.Models;

public class QidoStudyQuery
{
    public string? PatientID { get; set; }
    public string? PatientName { get; set; }
    public string? StudyDate { get; set; }
    public string? AccessionNumber { get; set; }
    public string? StudyInstanceUID { get; set; }
    public string? ModalitiesInStudy { get; set; }
    public string? ReferringPhysicianName { get; set; }
    public string? StudyDescription { get; set; }

    public int Limit { get; set; } = 100;
    public int Offset { get; set; } = 0;
    public string? Format { get; set; } // "dicom" (default) or "friendly"

    public void PopulateFromQuery(IQueryCollection query)
    {
        string? GetVal(params string[] keys)
        {
            foreach (var key in keys)
            {
                if (query.TryGetValue(key, out var val) && !string.IsNullOrWhiteSpace(val))
                {
                    return val.ToString().Trim();
                }
            }
            return null;
        }

        PatientID ??= GetVal("00100020", "patientid", "patientId", "PatientID");
        PatientName ??= GetVal("00100010", "patientname", "patientName", "PatientName");
        StudyDate ??= GetVal("00080020", "studydate", "studyDate", "StudyDate");
        AccessionNumber ??= GetVal("00080050", "accessionnumber", "accessionNumber", "AccessionNumber");
        StudyInstanceUID ??= GetVal("0020000D", "0020000d", "studyinstanceuid", "studyInstanceUid", "StudyInstanceUID");
        ModalitiesInStudy ??= GetVal("00080061", "modalitiesinstudy", "modalitiesInStudy", "ModalitiesInStudy");
        ReferringPhysicianName ??= GetVal("00080090", "referringphysicianname", "referringPhysicianName", "ReferringPhysicianName");
        StudyDescription ??= GetVal("00081030", "studydescription", "studyDescription", "StudyDescription");
        Format ??= GetVal("format");
    }
}

public class QidoSeriesQuery
{
    public string? Modality { get; set; }
    public string? SeriesInstanceUID { get; set; }
    public string? SeriesNumber { get; set; }
    public string? SeriesDescription { get; set; }

    public int Limit { get; set; } = 100;
    public int Offset { get; set; } = 0;
    public string? Format { get; set; }

    public void PopulateFromQuery(IQueryCollection query)
    {
        string? GetVal(params string[] keys)
        {
            foreach (var key in keys)
            {
                if (query.TryGetValue(key, out var val) && !string.IsNullOrWhiteSpace(val))
                {
                    return val.ToString().Trim();
                }
            }
            return null;
        }

        SeriesInstanceUID ??= GetVal("0020000E", "0020000e", "seriesinstanceuid", "seriesInstanceUid", "SeriesInstanceUID");
        Modality ??= GetVal("00080060", "modality", "Modality");
        SeriesNumber ??= GetVal("00200011", "seriesnumber", "seriesNumber", "SeriesNumber");
        SeriesDescription ??= GetVal("0008103E", "0008103e", "seriesdescription", "seriesDescription", "SeriesDescription");
        Format ??= GetVal("format");
    }
}

public class QidoInstanceQuery
{
    public string? SOPInstanceUID { get; set; }
    public string? SOPClassUID { get; set; }
    public string? InstanceNumber { get; set; }

    public int Limit { get; set; } = 100;
    public int Offset { get; set; } = 0;
    public string? Format { get; set; }

    public void PopulateFromQuery(IQueryCollection query)
    {
        string? GetVal(params string[] keys)
        {
            foreach (var key in keys)
            {
                if (query.TryGetValue(key, out var val) && !string.IsNullOrWhiteSpace(val))
                {
                    return val.ToString().Trim();
                }
            }
            return null;
        }

        SOPInstanceUID ??= GetVal("00080018", "sopinstanceuid", "sopInstanceUid", "SOPInstanceUID");
        SOPClassUID ??= GetVal("00080016", "sopclassuid", "sopClassUid", "SOPClassUID");
        InstanceNumber ??= GetVal("00200013", "instancenumber", "instanceNumber", "InstanceNumber");
        Format ??= GetVal("format");
    }
}

public class IndexSyncResult
{
    public bool Success { get; set; } = true;
    public string TenantId { get; set; } = string.Empty;
    public int ManifestsScanned { get; set; }
    public int StudiesIndexed { get; set; }
    public int SeriesIndexed { get; set; }
    public int InstancesIndexed { get; set; }
    public double DurationMs { get; set; }
    public List<string> Errors { get; set; } = new();
}

public class IndexStatsDto
{
    public string TenantId { get; set; } = string.Empty;
    public int PatientCount { get; set; }
    public int StudyCount { get; set; }
    public int SeriesCount { get; set; }
    public int InstanceCount { get; set; }
    public DateTime TimestampUtc { get; set; } = DateTime.UtcNow;
}

public class CleanupRequest
{
    public string? TenantId { get; set; } = "tenant-001";
    public bool CleanupDatabase { get; set; } = true;
    public bool CleanupDestinationS3 { get; set; } = true;
    public bool CleanupSourceS3 { get; set; } = false;
    public string? SourcePrefix { get; set; }
    public string? DestinationBucket { get; set; }
    public string? SourceBucket { get; set; }
    public bool AllTenants { get; set; } = false;
}

public class CleanupResult
{
    public bool Success { get; set; } = true;
    public string TenantId { get; set; } = string.Empty;
    public int DeletedInstances { get; set; }
    public int DeletedSeries { get; set; }
    public int DeletedStudies { get; set; }
    public int DeletedPatients { get; set; }
    public int DeletedDestinationS3Objects { get; set; }
    public int DeletedSourceS3Objects { get; set; }
    public double DurationMs { get; set; }
    public List<string> Messages { get; set; } = new();
    public List<string> Errors { get; set; } = new();
}
