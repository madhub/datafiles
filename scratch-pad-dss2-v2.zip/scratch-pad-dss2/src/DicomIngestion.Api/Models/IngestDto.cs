using System.ComponentModel.DataAnnotations;
using System.Text.Json.Serialization;

namespace DicomIngestion.Api.Models;

public abstract class BaseIngestRequest
{
    [Required]
    public string TenantId { get; set; } = "tenant-001";

    public string? SourceBucket { get; set; }
    public string? DestinationBucket { get; set; }
    public int? ConcurrencyLimit { get; set; }
    public bool GenerateManifests { get; set; } = true;
    public bool UseByteRangeForHeader { get; set; } = true;
    public bool IncludeFullManifests { get; set; } = false;
}

/// <summary>
/// Mode 1: Bulk unsegregated folder containing arbitrary patients, studies, and series.
/// </summary>
public class BulkIngestRequest : BaseIngestRequest
{
    [Required]
    public string SourcePrefix { get; set; } = string.Empty;
}

/// <summary>
/// Mode 2: Pre-segregated single series folder.
/// Caller asserts studyInstanceUid and seriesInstanceUid. Bypasses dynamic segregation.
/// </summary>
public class SeriesIngestRequest : BaseIngestRequest
{
    [Required]
    public string SourcePrefix { get; set; } = string.Empty;

    [Required]
    public string StudyInstanceUid { get; set; } = string.Empty;

    [Required]
    public string SeriesInstanceUid { get; set; } = string.Empty;
}

public class SeriesFolderMapping
{
    [Required]
    public string SeriesInstanceUid { get; set; } = string.Empty;

    [Required]
    public string SourcePrefix { get; set; } = string.Empty;

    public string? Modality { get; set; }
}

/// <summary>
/// Mode 3: Pre-segregated study where caller maps multiple series to their respective S3 prefixes.
/// </summary>
public class StudyIngestRequest : BaseIngestRequest
{
    [Required]
    public string StudyInstanceUid { get; set; } = string.Empty;

    [Required]
    [MinLength(1, ErrorMessage = "At least one series mapping is required.")]
    public List<SeriesFolderMapping> Series { get; set; } = new();
}

/// <summary>
/// Backward-compatible unified request model.
/// </summary>
public class IngestRequest : BaseIngestRequest
{
    public string? SourcePrefix { get; set; }
    public string? StudyInstanceUid { get; set; }
    public string? SeriesInstanceUid { get; set; }
    public List<SeriesFolderMapping>? Series { get; set; }
}

public class IngestionError
{
    public string SourceKey { get; set; } = string.Empty;
    public string Stage { get; set; } = string.Empty;
    public string Message { get; set; } = string.Empty;
}

public class IngestResponse
{
    public bool Success { get; set; }
    public string TenantId { get; set; } = string.Empty;
    public string IngestionMode { get; set; } = string.Empty;
    public string SourceBucket { get; set; } = string.Empty;
    public string DestinationBucket { get; set; } = string.Empty;
    public int ConcurrencyUsed { get; set; }

    public int SeriesCount { get; set; } = 0;
    public int StudyCount { get; set; } = 0;
    public int PatientCount { get; set; } = 0;
    public PerformanceMetrics Metrics { get; set; } = new();
    public List<string> ManifestS3Keys { get; set; } = new();

    [JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
    public List<SeriesManifest>? SeriesManifests { get; set; }

    public List<IngestionError> Errors { get; set; } = new();
}
