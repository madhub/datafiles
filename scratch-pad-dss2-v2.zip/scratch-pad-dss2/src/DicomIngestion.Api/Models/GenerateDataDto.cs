namespace DicomIngestion.Api.Models;

public class GenerateDataRequest
{
    public string? Bucket { get; set; }
    public string Prefix { get; set; } = "benchmark-batch/";
    public int FileCount { get; set; } = 50;
    public int StudyCount { get; set; } = 2;
    public int SeriesPerStudy { get; set; } = 2;

    /// <summary>
    /// If true, generates files into separate subfolders per series: {prefix}/series-{s}/
    /// </summary>
    public bool OrganizeBySeriesFolders { get; set; } = false;

    /// <summary>
    /// If true, sets NumberOfFrames > 1 to test multi-frame modality handling (e.g. Ultrasound, Multi-frame CT).
    /// </summary>
    public bool IsMultiFrame { get; set; } = false;
    public int NumberOfFrames { get; set; } = 16;
    
    /// <summary>
    /// Payload sizes:
    /// "Small" (~50KB)
    /// "Medium" (~512KB)
    /// "Large" (~10MB)
    /// Or an explicit integer byte size as a string.
    /// </summary>
    public string PayloadSize { get; set; } = "Medium";
}

public class GeneratedSeriesInfo
{
    public string StudyInstanceUid { get; set; } = string.Empty;
    public string SeriesInstanceUid { get; set; } = string.Empty;
    public string S3Prefix { get; set; } = string.Empty;
    public int FileCount { get; set; }
}

public class GenerateDataResponse
{
    public bool Success { get; set; }
    public string Bucket { get; set; } = string.Empty;
    public string Prefix { get; set; } = string.Empty;
    public int TotalFilesGenerated { get; set; }
    public long TotalSizeBytes { get; set; }
    public double TotalDurationMs { get; set; }
    public double FilesPerSecond { get; set; }
    public List<GeneratedSeriesInfo> GeneratedSeries { get; set; } = new();
}
