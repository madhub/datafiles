using System.Text.Json.Serialization;

namespace DicomIngestion.Api.Models;

public class PatientMetadata
{
    public string PatientId { get; set; } = string.Empty;
    
    [JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
    public string? IssuerOfPatientId { get; set; }

    public string PatientName { get; set; } = string.Empty;

    [JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
    public string? PatientBirthDate { get; set; }

    [JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
    public string? PatientSex { get; set; }
}

public class StudyMetadata
{
    public string StudyInstanceUid { get; set; } = string.Empty;

    [JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
    public string? StudyDate { get; set; }

    [JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
    public string? StudyTime { get; set; }

    [JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
    public string? AccessionNumber { get; set; }

    [JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
    public string? StudyDescription { get; set; }

    [JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
    public string? ReferringPhysicianName { get; set; }
}

public class SeriesMetadata
{
    public string SeriesInstanceUid { get; set; } = string.Empty;

    [JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
    public string? Modality { get; set; }

    [JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
    public string? SeriesNumber { get; set; }

    [JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
    public string? SeriesDescription { get; set; }

    [JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
    public string? BodyPartExamined { get; set; }
}

/// <summary>
/// Common instance attributes that are shared across images in a series.
/// </summary>
public class InstanceImageAttributes
{
    [JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
    public string? ImageType { get; set; }

    [JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
    public int? NumberOfFrames { get; set; }

    [JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
    public string? SopClassUid { get; set; }

    [JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
    public string? TransferSyntaxUid { get; set; }

    [JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
    public string? SpecificCharacterSet { get; set; }

    [JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
    public int? Rows { get; set; }

    [JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
    public int? Columns { get; set; }

    [JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
    public int? BitsAllocated { get; set; }

    [JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
    public int? BitsStored { get; set; }

    [JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
    public int? HighBit { get; set; }

    [JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
    public int? PixelRepresentation { get; set; }

    [JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
    public int? SamplesPerPixel { get; set; }

    [JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
    public string? PhotometricInterpretation { get; set; }
}

/// <summary>
/// Factored instance metadata. Slices matching commonInstanceMetadata omit Overrides.
/// </summary>
public class FactoredInstanceMetadata
{
    public string SopInstanceUid { get; set; } = string.Empty;

    [JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
    public string? InstanceNumber { get; set; }

    public string DestinationS3Key { get; set; } = string.Empty;
    public string SourceS3Key { get; set; } = string.Empty;
    public long FileSizeBytes { get; set; }

    [JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
    public InstanceImageAttributes? Overrides { get; set; }
}

public class ParsedDicomRecord
{
    public PatientMetadata Patient { get; set; } = new();
    public StudyMetadata Study { get; set; } = new();
    public SeriesMetadata Series { get; set; } = new();
    public InstanceImageAttributes ImageAttributes { get; set; } = new();

    public string SopInstanceUid { get; set; } = string.Empty;
    public string? InstanceNumber { get; set; }
    public string SourceS3Key { get; set; } = string.Empty;
    public string DestinationS3Key { get; set; } = string.Empty;
    public long FileSizeBytes { get; set; }

    public double HeaderParseLatencyMs { get; set; }
    public double S3CopyLatencyMs { get; set; }
}

/// <summary>
/// Standalone Series Manifest stored at {tenantId}/{studyInstanceUid}/{seriesInstanceUid}/manifest.json
/// Factored into commonInstanceMetadata and instance-specific overrides.
/// </summary>
public class SeriesManifest
{
    public string TenantId { get; set; } = string.Empty;
    public string ManifestS3Key { get; set; } = string.Empty;
    public DateTime IngestTimestampUtc { get; set; } = DateTime.UtcNow;

    public int TotalInstances { get; set; }
    public long TotalSizeBytes { get; set; }

    public PatientMetadata Patient { get; set; } = new();
    public StudyMetadata Study { get; set; } = new();
    public SeriesMetadata Series { get; set; } = new();

    public InstanceImageAttributes CommonInstanceMetadata { get; set; } = new();
    public List<FactoredInstanceMetadata> Instances { get; set; } = new();
}
