namespace DicomIngestion.Api.Models;

public class LatencyDistribution
{
    public double MinMs { get; set; }
    public double AvgMs { get; set; }
    public double P50Ms { get; set; }
    public double P90Ms { get; set; }
    public double P99Ms { get; set; }
    public double MaxMs { get; set; }

    public static LatencyDistribution Compute(IEnumerable<double> samples)
    {
        var list = samples.OrderBy(x => x).ToList();
        if (list.Count == 0) return new LatencyDistribution();

        return new LatencyDistribution
        {
            MinMs = Math.Round(list[0], 2),
            AvgMs = Math.Round(list.Average(), 2),
            P50Ms = Math.Round(Percentile(list, 0.50), 2),
            P90Ms = Math.Round(Percentile(list, 0.90), 2),
            P99Ms = Math.Round(Percentile(list, 0.99), 2),
            MaxMs = Math.Round(list[^1], 2)
        };
    }

    private static double Percentile(List<double> sorted, double percentile)
    {
        if (sorted.Count == 1) return sorted[0];
        var idx = (int)Math.Ceiling(percentile * sorted.Count) - 1;
        return sorted[Math.Clamp(idx, 0, sorted.Count - 1)];
    }
}

public class PerformanceMetrics
{
    public double DiscoveryDurationMs { get; set; }
    public double ProcessingDurationMs { get; set; }
    public double ManifestDurationMs { get; set; }
    public double TotalDurationMs { get; set; }

    public int FilesDiscovered { get; set; }
    public int FilesProcessed { get; set; }
    public int FilesFailed { get; set; }

    public long TotalBytesProcessed { get; set; }
    public double TotalMegabytesProcessed => Math.Round(TotalBytesProcessed / (1024.0 * 1024.0), 2);

    public double ThroughputFilesPerSecond { get; set; }
    public double ThroughputMegabytesPerSecond { get; set; }

    public LatencyDistribution HeaderParseLatency { get; set; } = new();
    public LatencyDistribution S3CopyLatency { get; set; } = new();
    public LatencyDistribution EndToEndPerFileLatency { get; set; } = new();
}
