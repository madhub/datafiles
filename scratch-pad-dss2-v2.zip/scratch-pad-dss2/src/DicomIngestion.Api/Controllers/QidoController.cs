using DicomIngestion.Api.Models;
using DicomIngestion.Api.Services;
using Microsoft.AspNetCore.Mvc;

namespace DicomIngestion.Api.Controllers;

[ApiController]
[Route("dicomweb")]
public class QidoController : ControllerBase
{
    private readonly IDicomIndexService _indexService;
    private const string DefaultTenant = "tenant-001";

    public QidoController(IDicomIndexService indexService)
    {
        _indexService = indexService;
    }

    /// <summary>
    /// QIDO-RS: Query for Studies (Study Level Query).
    /// Returns NumberOfStudyRelatedSeries (0020,1206) and NumberOfStudyRelatedInstances (0020,1208).
    /// </summary>
    [HttpGet("studies")]
    [HttpGet("{tenantId}/studies")]
    [Produces("application/dicom+json", "application/json")]
    public async Task<IActionResult> SearchForStudies(
        [FromRoute] string? tenantId,
        [FromQuery] QidoStudyQuery query,
        CancellationToken ct)
    {
        query.PopulateFromQuery(Request.Query);
        var resolvedTenant = ResolveTenant(tenantId);
        var studies = await _indexService.QueryStudiesAsync(resolvedTenant, query, ct);

        if (string.Equals(query.Format, "friendly", StringComparison.OrdinalIgnoreCase))
        {
            return Ok(studies.Select(DicomJsonHelper.ToFriendlyJson));
        }

        var dicomJsonArray = studies.Select(DicomJsonHelper.ToDicomJson).ToList();
        Response.ContentType = "application/dicom+json";
        return Ok(dicomJsonArray);
    }

    /// <summary>
    /// QIDO-RS: Query for Series within a Study (Series Level Query).
    /// Returns NumberOfSeriesRelatedInstances (0020,1209).
    /// </summary>
    [HttpGet("studies/{studyInstanceUid}/series")]
    [HttpGet("{tenantId}/studies/{studyInstanceUid}/series")]
    [Produces("application/dicom+json", "application/json")]
    public async Task<IActionResult> SearchForStudySeries(
        [FromRoute] string? tenantId,
        [FromRoute] string studyInstanceUid,
        [FromQuery] QidoSeriesQuery query,
        CancellationToken ct)
    {
        query.PopulateFromQuery(Request.Query);
        var resolvedTenant = ResolveTenant(tenantId);
        var seriesList = await _indexService.QuerySeriesAsync(resolvedTenant, studyInstanceUid, query, ct);

        if (string.Equals(query.Format, "friendly", StringComparison.OrdinalIgnoreCase))
        {
            return Ok(seriesList.Select(DicomJsonHelper.ToFriendlyJson));
        }

        var dicomJsonArray = seriesList.Select(DicomJsonHelper.ToDicomJson).ToList();
        Response.ContentType = "application/dicom+json";
        return Ok(dicomJsonArray);
    }

    /// <summary>
    /// QIDO-RS: Search for Series across all Studies.
    /// </summary>
    [HttpGet("series")]
    [HttpGet("{tenantId}/series")]
    [Produces("application/dicom+json", "application/json")]
    public async Task<IActionResult> SearchForAllSeries(
        [FromRoute] string? tenantId,
        [FromQuery] QidoSeriesQuery query,
        CancellationToken ct)
    {
        query.PopulateFromQuery(Request.Query);
        var resolvedTenant = ResolveTenant(tenantId);
        var seriesList = await _indexService.QuerySeriesAsync(resolvedTenant, null, query, ct);

        if (string.Equals(query.Format, "friendly", StringComparison.OrdinalIgnoreCase))
        {
            return Ok(seriesList.Select(DicomJsonHelper.ToFriendlyJson));
        }

        var dicomJsonArray = seriesList.Select(DicomJsonHelper.ToDicomJson).ToList();
        Response.ContentType = "application/dicom+json";
        return Ok(dicomJsonArray);
    }

    /// <summary>
    /// QIDO-RS: Query for Instances within a Series (Instance Level Query).
    /// </summary>
    [HttpGet("studies/{studyInstanceUid}/series/{seriesInstanceUid}/instances")]
    [HttpGet("{tenantId}/studies/{studyInstanceUid}/series/{seriesInstanceUid}/instances")]
    [Produces("application/dicom+json", "application/json")]
    public async Task<IActionResult> SearchForSeriesInstances(
        [FromRoute] string? tenantId,
        [FromRoute] string studyInstanceUid,
        [FromRoute] string seriesInstanceUid,
        [FromQuery] QidoInstanceQuery query,
        CancellationToken ct)
    {
        query.PopulateFromQuery(Request.Query);
        var resolvedTenant = ResolveTenant(tenantId);
        var instances = await _indexService.QueryInstancesAsync(resolvedTenant, studyInstanceUid, seriesInstanceUid, query, ct);

        if (string.Equals(query.Format, "friendly", StringComparison.OrdinalIgnoreCase))
        {
            return Ok(instances.Select(DicomJsonHelper.ToFriendlyJson));
        }

        var dicomJsonArray = instances.Select(DicomJsonHelper.ToDicomJson).ToList();
        Response.ContentType = "application/dicom+json";
        return Ok(dicomJsonArray);
    }

    /// <summary>
    /// QIDO-RS: Search for Instances across all Studies/Series.
    /// </summary>
    [HttpGet("instances")]
    [HttpGet("{tenantId}/instances")]
    [Produces("application/dicom+json", "application/json")]
    public async Task<IActionResult> SearchForAllInstances(
        [FromRoute] string? tenantId,
        [FromQuery] QidoInstanceQuery query,
        CancellationToken ct)
    {
        query.PopulateFromQuery(Request.Query);
        var resolvedTenant = ResolveTenant(tenantId);
        var instances = await _indexService.QueryInstancesAsync(resolvedTenant, null, null, query, ct);

        if (string.Equals(query.Format, "friendly", StringComparison.OrdinalIgnoreCase))
        {
            return Ok(instances.Select(DicomJsonHelper.ToFriendlyJson));
        }

        var dicomJsonArray = instances.Select(DicomJsonHelper.ToDicomJson).ToList();
        Response.ContentType = "application/dicom+json";
        return Ok(dicomJsonArray);
    }

    private static string ResolveTenant(string? tenantId)
    {
        return string.IsNullOrWhiteSpace(tenantId) ? DefaultTenant : tenantId.Trim();
    }
}
