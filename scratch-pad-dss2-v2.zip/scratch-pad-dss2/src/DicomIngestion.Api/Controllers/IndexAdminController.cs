using DicomIngestion.Api.Models;
using DicomIngestion.Api.Services;
using Microsoft.AspNetCore.Mvc;

namespace DicomIngestion.Api.Controllers;

[ApiController]
[Route("api/v1/indexing")]
[Route("api/v1/admin")]
public class IndexAdminController : ControllerBase
{
    private readonly IDicomIndexService _indexService;
    private const string DefaultTenant = "tenant-001";

    public IndexAdminController(IDicomIndexService indexService)
    {
        _indexService = indexService;
    }

    /// <summary>
    /// Scans the S3 destination bucket for existing factored series manifests (manifest.json)
    /// and populates or updates the SQLite relational index records.
    /// </summary>
    [HttpPost("sync")]
    [ProducesResponseType(typeof(IndexSyncResult), StatusCodes.Status200OK)]
    public async Task<IActionResult> SyncIndexFromManifests(
        [FromQuery] string? tenantId,
        [FromQuery] string? destinationBucket,
        CancellationToken ct)
    {
        var resolvedTenant = string.IsNullOrWhiteSpace(tenantId) ? DefaultTenant : tenantId.Trim();
        var result = await _indexService.RebuildIndexFromS3Async(resolvedTenant, destinationBucket, ct);
        return Ok(result);
    }

    /// <summary>
    /// Retrieves current index statistics for a tenant from SQLite database.
    /// </summary>
    [HttpGet("stats")]
    [ProducesResponseType(typeof(IndexStatsDto), StatusCodes.Status200OK)]
    public async Task<IActionResult> GetIndexStats(
        [FromQuery] string? tenantId,
        CancellationToken ct)
    {
        var resolvedTenant = string.IsNullOrWhiteSpace(tenantId) ? DefaultTenant : tenantId.Trim();
        var stats = await _indexService.GetIndexStatsAsync(resolvedTenant, ct);
        return Ok(stats);
    }

    /// <summary>
    /// Purges database records (Patients, Studies, Series, Instances) and associated S3 folders for a tenant.
    /// </summary>
    [HttpPost("cleanup")]
    [HttpDelete("cleanup")]
    [ProducesResponseType(typeof(CleanupResult), StatusCodes.Status200OK)]
    public async Task<IActionResult> Cleanup(
        [FromBody(EmptyBodyBehavior = Microsoft.AspNetCore.Mvc.ModelBinding.EmptyBodyBehavior.Allow)] CleanupRequest? bodyRequest,
        [FromQuery] string? tenantId,
        [FromQuery] bool? cleanupDatabase,
        [FromQuery] bool? cleanupDestinationS3,
        [FromQuery] bool? cleanupSourceS3,
        [FromQuery] string? sourcePrefix,
        [FromQuery] bool? allTenants,
        CancellationToken ct)
    {
        var req = bodyRequest ?? new CleanupRequest();
        if (!string.IsNullOrWhiteSpace(tenantId)) req.TenantId = tenantId;
        if (cleanupDatabase.HasValue) req.CleanupDatabase = cleanupDatabase.Value;
        if (cleanupDestinationS3.HasValue) req.CleanupDestinationS3 = cleanupDestinationS3.Value;
        if (cleanupSourceS3.HasValue) req.CleanupSourceS3 = cleanupSourceS3.Value;
        if (!string.IsNullOrWhiteSpace(sourcePrefix)) req.SourcePrefix = sourcePrefix;
        if (allTenants.HasValue) req.AllTenants = allTenants.Value;

        var result = await _indexService.CleanupAsync(req, ct);
        return Ok(result);
    }
}
