using Amazon.S3;
using DicomIngestion.Api.Models;
using DicomIngestion.Api.Services;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Options;

namespace DicomIngestion.Api.Controllers;

[ApiController]
[Route("api/v1/benchmark")]
public class BenchmarkController : ControllerBase
{
    private readonly IDicomDataGenerator _generator;
    private readonly IS3StorageService _s3Service;
    private readonly MinioOptions _minioOptions;
    private readonly ILogger<BenchmarkController> _logger;

    public BenchmarkController(
        IDicomDataGenerator generator,
        IS3StorageService s3Service,
        IOptions<MinioOptions> minioOptions,
        ILogger<BenchmarkController> logger)
    {
        _generator = generator;
        _s3Service = s3Service;
        _minioOptions = minioOptions.Value;
        _logger = logger;
    }

    /// <summary>
    /// Generates synthetic DICOM files with configurable counts and pixel sizes directly into MinIO
    /// for benchmarking ingestion throughput.
    /// </summary>
    [HttpPost("generate-data")]
    [ProducesResponseType(typeof(GenerateDataResponse), StatusCodes.Status200OK)]
    public async Task<IActionResult> GenerateData([FromBody] GenerateDataRequest request, CancellationToken ct)
    {
        _logger.LogInformation("Generating {Count} synthetic DICOM files ({Size}) under prefix '{Prefix}'",
            request.FileCount, request.PayloadSize, request.Prefix);

        var result = await _generator.GenerateAndUploadBatchAsync(request, ct);
        return Ok(result);
    }

    /// <summary>
    /// Verifies connectivity to the MinIO instance and lists available buckets.
    /// </summary>
    [HttpGet("health")]
    public async Task<IActionResult> CheckHealth(CancellationToken ct)
    {
        try
        {
            await _s3Service.EnsureBucketExistsAsync(_minioOptions.DefaultSourceBucket, ct);
            await _s3Service.EnsureBucketExistsAsync(_minioOptions.DefaultDestinationBucket, ct);

            return Ok(new
            {
                Status = "Healthy",
                MinioServiceUrl = _minioOptions.ServiceUrl,
                SourceBucket = _minioOptions.DefaultSourceBucket,
                DestinationBucket = _minioOptions.DefaultDestinationBucket,
                TimestampUtc = DateTime.UtcNow
            });
        }
        catch (Exception ex)
        {
            return StatusCode(StatusCodes.Status503ServiceUnavailable, new
            {
                Status = "Unhealthy",
                MinioServiceUrl = _minioOptions.ServiceUrl,
                Error = ex.Message
            });
        }
    }
}
