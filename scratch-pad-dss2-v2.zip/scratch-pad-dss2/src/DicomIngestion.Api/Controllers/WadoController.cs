using System.Text;
using DicomIngestion.Api.Models;
using DicomIngestion.Api.Services;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Options;

namespace DicomIngestion.Api.Controllers;

[ApiController]
[Route("dicomweb")]
public class WadoController : ControllerBase
{
    private readonly IDicomIndexService _indexService;
    private readonly IS3StorageService _s3Service;
    private readonly MinioOptions _minioOptions;
    private readonly ILogger<WadoController> _logger;
    private const string DefaultTenant = "tenant-001";

    public WadoController(
        IDicomIndexService indexService,
        IS3StorageService s3Service,
        IOptions<MinioOptions> minioOptions,
        ILogger<WadoController> logger)
    {
        _indexService = indexService;
        _s3Service = s3Service;
        _minioOptions = minioOptions.Value;
        _logger = logger;
    }

    /// <summary>
    /// WADO-RS: Retrieve Instance (PS3.18 Section 10.4.1).
    /// Retrieves a single DICOM Part 10 instance.
    /// </summary>
    [HttpGet("studies/{studyInstanceUid}/series/{seriesInstanceUid}/instances/{sopInstanceUid}")]
    [HttpGet("{tenantId}/studies/{studyInstanceUid}/series/{seriesInstanceUid}/instances/{sopInstanceUid}")]
    [Produces("application/dicom", "multipart/related")]
    public async Task<IActionResult> RetrieveInstance(
        [FromRoute] string? tenantId,
        [FromRoute] string studyInstanceUid,
        [FromRoute] string seriesInstanceUid,
        [FromRoute] string sopInstanceUid,
        CancellationToken ct)
    {
        var resolvedTenant = ResolveTenant(tenantId);
        var bucket = _minioOptions.DefaultDestinationBucket;

        var instance = await _indexService.GetInstanceAsync(resolvedTenant, studyInstanceUid, seriesInstanceUid, sopInstanceUid, ct);
        var s3Key = instance?.DestinationS3Key ?? $"{resolvedTenant}/{studyInstanceUid}/{seriesInstanceUid}/{sopInstanceUid}.dcm";

        try
        {
            var accept = Request.Headers.Accept.ToString();
            var isMultipart = accept.Contains("multipart/related", StringComparison.OrdinalIgnoreCase);

            if (isMultipart)
            {
                var boundary = "DICOMWEB_" + Guid.NewGuid().ToString("N");
                Response.ContentType = $"multipart/related; type=\"application/dicom\"; boundary={boundary}";

                var header = $"--{boundary}\r\nContent-Type: application/dicom\r\nContent-Location: /dicomweb/studies/{studyInstanceUid}/series/{seriesInstanceUid}/instances/{sopInstanceUid}\r\n\r\n";
                await Response.Body.WriteAsync(Encoding.ASCII.GetBytes(header), ct);

                using (var stream = await _s3Service.GetStreamAsync(bucket, s3Key, ct))
                {
                    await stream.CopyToAsync(Response.Body, ct);
                }

                var footer = $"\r\n--{boundary}--\r\n";
                await Response.Body.WriteAsync(Encoding.ASCII.GetBytes(footer), ct);
                await Response.Body.FlushAsync(ct);
                return new EmptyResult();
            }

            var directStream = await _s3Service.GetStreamAsync(bucket, s3Key, ct);
            return File(directStream, "application/dicom", $"{sopInstanceUid}.dcm");
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Failed to retrieve DICOM instance {Key} from bucket {Bucket}", s3Key, bucket);
            return NotFound(new { error = $"Instance not found: {sopInstanceUid}" });
        }
    }

    /// <summary>
    /// WADO-RS: Retrieve Series (PS3.18 Section 10.4.2).
    /// Strictly multipart/related; type="application/dicom" per DICOM standard.
    /// </summary>
    [HttpGet("studies/{studyInstanceUid}/series/{seriesInstanceUid}")]
    [HttpGet("{tenantId}/studies/{studyInstanceUid}/series/{seriesInstanceUid}")]
    [Produces("multipart/related")]
    public async Task<IActionResult> RetrieveSeries(
        [FromRoute] string? tenantId,
        [FromRoute] string studyInstanceUid,
        [FromRoute] string seriesInstanceUid,
        CancellationToken ct)
    {
        var resolvedTenant = ResolveTenant(tenantId);
        var bucket = _minioOptions.DefaultDestinationBucket;

        var instances = await _indexService.GetSeriesInstancesAsync(resolvedTenant, studyInstanceUid, seriesInstanceUid, ct);
        if (instances.Count == 0)
        {
            return NotFound(new { error = $"Series not found or contains no indexed instances: {seriesInstanceUid}" });
        }

        var boundary = "DICOMWEB_" + Guid.NewGuid().ToString("N");
        Response.ContentType = $"multipart/related; type=\"application/dicom\"; boundary={boundary}";

        foreach (var inst in instances)
        {
            try
            {
                var header = $"\r\n--{boundary}\r\nContent-Type: application/dicom\r\nContent-Location: /dicomweb/studies/{studyInstanceUid}/series/{seriesInstanceUid}/instances/{inst.SopInstanceUid}\r\n\r\n";
                await Response.Body.WriteAsync(Encoding.ASCII.GetBytes(header), ct);

                using var stream = await _s3Service.GetStreamAsync(bucket, inst.DestinationS3Key, ct);
                await stream.CopyToAsync(Response.Body, ct);
            }
            catch (Exception ex)
            {
                _logger.LogWarning(ex, "Could not stream instance {Key} in series {SeriesUid}", inst.DestinationS3Key, seriesInstanceUid);
            }
        }

        var footer = $"\r\n--{boundary}--\r\n";
        await Response.Body.WriteAsync(Encoding.ASCII.GetBytes(footer), ct);
        await Response.Body.FlushAsync(ct);

        return new EmptyResult();
    }

    /// <summary>
    /// WADO-RS: Retrieve Study (PS3.18 Section 10.4.3).
    /// Strictly multipart/related; type="application/dicom" per DICOM standard.
    /// </summary>
    [HttpGet("studies/{studyInstanceUid}")]
    [HttpGet("{tenantId}/studies/{studyInstanceUid}")]
    [Produces("multipart/related")]
    public async Task<IActionResult> RetrieveStudy(
        [FromRoute] string? tenantId,
        [FromRoute] string studyInstanceUid,
        CancellationToken ct)
    {
        var resolvedTenant = ResolveTenant(tenantId);
        var bucket = _minioOptions.DefaultDestinationBucket;

        var instances = await _indexService.GetStudyInstancesAsync(resolvedTenant, studyInstanceUid, ct);
        if (instances.Count == 0)
        {
            return NotFound(new { error = $"Study not found or contains no indexed instances: {studyInstanceUid}" });
        }

        var boundary = "DICOMWEB_" + Guid.NewGuid().ToString("N");
        Response.ContentType = $"multipart/related; type=\"application/dicom\"; boundary={boundary}";

        foreach (var inst in instances)
        {
            try
            {
                var header = $"\r\n--{boundary}\r\nContent-Type: application/dicom\r\nContent-Location: /dicomweb/studies/{studyInstanceUid}/series/{inst.SeriesInstanceUid}/instances/{inst.SopInstanceUid}\r\n\r\n";
                await Response.Body.WriteAsync(Encoding.ASCII.GetBytes(header), ct);

                using var stream = await _s3Service.GetStreamAsync(bucket, inst.DestinationS3Key, ct);
                await stream.CopyToAsync(Response.Body, ct);
            }
            catch (Exception ex)
            {
                _logger.LogWarning(ex, "Could not stream instance {Key} in study {StudyUid}", inst.DestinationS3Key, studyInstanceUid);
            }
        }

        var footer = $"\r\n--{boundary}--\r\n";
        await Response.Body.WriteAsync(Encoding.ASCII.GetBytes(footer), ct);
        await Response.Body.FlushAsync(ct);

        return new EmptyResult();
    }

    /// <summary>
    /// Legacy WADO-URI Endpoint: GET /dicomweb/wado?requestType=WADO&studyUID=...&seriesUID=...&objectUID=...
    /// </summary>
    [HttpGet("wado")]
    [Produces("application/dicom")]
    public async Task<IActionResult> RetrieveWadoUri(
        [FromQuery] string? requestType,
        [FromQuery] string? studyUID,
        [FromQuery] string? seriesUID,
        [FromQuery] string? objectUID,
        [FromQuery] string? tenantId,
        CancellationToken ct)
    {
        if (!string.Equals(requestType, "WADO", StringComparison.OrdinalIgnoreCase))
        {
            return BadRequest(new { error = "Invalid requestType. Must be 'WADO'." });
        }

        if (string.IsNullOrWhiteSpace(studyUID) || string.IsNullOrWhiteSpace(seriesUID) || string.IsNullOrWhiteSpace(objectUID))
        {
            return BadRequest(new { error = "studyUID, seriesUID, and objectUID are required for WADO-URI." });
        }

        var resolvedTenant = ResolveTenant(tenantId);
        var bucket = _minioOptions.DefaultDestinationBucket;

        var instance = await _indexService.GetInstanceAsync(resolvedTenant, studyUID.Trim(), seriesUID.Trim(), objectUID.Trim(), ct);
        var s3Key = instance?.DestinationS3Key ?? $"{resolvedTenant}/{studyUID.Trim()}/{seriesUID.Trim()}/{objectUID.Trim()}.dcm";

        try
        {
            var stream = await _s3Service.GetStreamAsync(bucket, s3Key, ct);
            return File(stream, "application/dicom", $"{objectUID}.dcm");
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Failed WADO-URI retrieval for {Key}", s3Key);
            return NotFound(new { error = $"Object not found: {objectUID}" });
        }
    }

    private static string ResolveTenant(string? tenantId)
    {
        return string.IsNullOrWhiteSpace(tenantId) ? DefaultTenant : tenantId.Trim();
    }
}
