using DicomIngestion.Api.Models;
using DicomIngestion.Api.Services;
using Microsoft.AspNetCore.Mvc;

namespace DicomIngestion.Api.Controllers;

[ApiController]
[Route("api/v1/ingest")]
public class IngestionController : ControllerBase
{
    private readonly IIngestionPipeline _ingestionPipeline;
    private readonly ILogger<IngestionController> _logger;

    public IngestionController(IIngestionPipeline ingestionPipeline, ILogger<IngestionController> logger)
    {
        _ingestionPipeline = ingestionPipeline;
        _logger = logger;
    }

    /// <summary>
    /// Mode 1: Ingests an unsegregated bulk S3 folder containing arbitrary mix of patients, studies, and series.
    /// Dynamically extracts headers, groups by series, copies files, and creates factored manifests per series.
    /// </summary>
    [HttpPost("bulk")]
    [ProducesResponseType(typeof(IngestResponse), StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status400BadRequest)]
    public async Task<IActionResult> IngestBulk([FromBody] BulkIngestRequest request, CancellationToken ct)
    {
        if (string.IsNullOrWhiteSpace(request.SourcePrefix))
        {
            return BadRequest(new { Error = "SourcePrefix is required for bulk ingestion." });
        }

        _logger.LogInformation("Starting bulk DICOM ingestion for tenant {TenantId}, prefix '{Prefix}'",
            request.TenantId, request.SourcePrefix);

        var response = await _ingestionPipeline.IngestBulkAsync(request, ct);
        return Ok(response);
    }

    /// <summary>
    /// Mode 2: Ingests a pre-segregated single series S3 folder.
    /// Bypasses dynamic grouping entirely since caller asserts studyInstanceUid and seriesInstanceUid.
    /// </summary>
    [HttpPost("series")]
    [ProducesResponseType(typeof(IngestResponse), StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status400BadRequest)]
    public async Task<IActionResult> IngestSeries([FromBody] SeriesIngestRequest request, CancellationToken ct)
    {
        if (string.IsNullOrWhiteSpace(request.SourcePrefix) ||
            string.IsNullOrWhiteSpace(request.StudyInstanceUid) ||
            string.IsNullOrWhiteSpace(request.SeriesInstanceUid))
        {
            return BadRequest(new { Error = "SourcePrefix, StudyInstanceUid, and SeriesInstanceUid are required." });
        }

        _logger.LogInformation("Starting pre-segregated series ingestion for tenant {TenantId}, series {SeriesUid}",
            request.TenantId, request.SeriesInstanceUid);

        var response = await _ingestionPipeline.IngestSeriesAsync(request, ct);
        return Ok(response);
    }

    /// <summary>
    /// Mode 3: Ingests a pre-segregated study where caller provides series mappings to S3 folders.
    /// Each series folder is processed as an atomic unit in parallel.
    /// </summary>
    [HttpPost("study")]
    [ProducesResponseType(typeof(IngestResponse), StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status400BadRequest)]
    public async Task<IActionResult> IngestStudy([FromBody] StudyIngestRequest request, CancellationToken ct)
    {
        if (string.IsNullOrWhiteSpace(request.StudyInstanceUid) || request.Series.Count == 0)
        {
            return BadRequest(new { Error = "StudyInstanceUid and at least one Series mapping are required." });
        }

        _logger.LogInformation("Starting pre-segregated study ingestion for tenant {TenantId}, study {StudyUid} ({Count} series)",
            request.TenantId, request.StudyInstanceUid, request.Series.Count);

        var response = await _ingestionPipeline.IngestStudyAsync(request, ct);
        return Ok(response);
    }

    /// <summary>
    /// Unified synchronous endpoint (automatically routes based on provided fields for backward compatibility).
    /// </summary>
    [HttpPost("sync")]
    [ProducesResponseType(typeof(IngestResponse), StatusCodes.Status200OK)]
    public async Task<IActionResult> IngestSync([FromBody] IngestRequest request, CancellationToken ct)
    {
        var response = await _ingestionPipeline.ExecuteIngestionAsync(request, ct);
        return Ok(response);
    }
}
