# System Architecture & Design Document: Cloud-Native DICOM Ingestion Pipeline

**Document Version:** 1.0  
**Target Runtimes:** ASP.NET Core 8 (.NET 8), AWS SDK for .NET, Fellow Oak DICOM (`fo-dicom` 5.2.6)  
**Storage Target:** Amazon S3 / MinIO Object Storage  

---

## 1. Executive Summary & Problem Statement

Modern medical imaging networks process millions of DICOM objects across varied modalities (e.g., CT, MR, X-Ray/CR, Ultrasound, Pathology/WSI) comprising both single-frame and multi-frame datasets. 

Traditional DICOM ingestion pipelines often suffer from critical architectural bottlenecks:
1. **Network & Memory Saturation**: Downloading entire multi-megabyte DICOM objects (95–99% of which is binary Pixel Data) to the application layer to parse headers exhaust network bandwidth and heap memory.
2. **Study-Level Contention**: Treating the **Study** as the unit of processing creates lock contention and race conditions when modalities acquire and upload series incrementally.
3. **Manifest Bloating**: Repeating identical imaging parameters across hundreds or thousands of slices in a series causes massive JSON redundancy.
4. **Rigid Folder Assumptions**: Ingestion engines often force either pure unsegregated dumps or strict pre-sorted structures, causing unnecessary server-side sorting or client-side preparation overhead.

This design document establishes a high-performance, multitenant DICOM ingestion pipeline in **ASP.NET Core 8** designed to eliminate these bottlenecks through:
* **Zero-Pixel Memory Overhead**: Streaming and extracting only header elements via `fo-dicom` with `FileReadOption.SkipLargeTags`.
* **S3 Server-Side Copying**: Zero data re-upload across the network; objects are moved internally within S3 storage at disk/IOPS speeds.
* **Series as the Atomic Unit of Processing**: Dedicated series processing and manifest generation at `{tenantId}/{studyInstanceUid}/{seriesInstanceUid}/manifest.json`.
* **Attribute Factoring**: Normalizing shared series attributes into a baseline while recording only delta overrides for variant instances.
* **Flexible Ingestion Modes**: Native support for **Bulk Unsegregated Dumps**, **Pre-Segregated Single Series**, and **Studies with Mapped Series Folders**.

---

## 2. Requirements Specification

### 2.1 Functional Requirements (FR)

| ID | Requirement | Description |
| :--- | :--- | :--- |
| **FR-01** | **Multi-Tenancy** | Isolate ingestion, storage, and manifests strictly by `tenantId`. |
| **FR-02** | **Mode 1: Bulk Ingestion** | Accept an S3 prefix containing arbitrary mixed patients, studies, and series; dynamically group and manifest by series. |
| **FR-03** | **Mode 2: Pre-Segregated Series** | Accept an S3 prefix with caller-asserted `studyInstanceUid` and `seriesInstanceUid`; bypass dynamic grouping entirely for maximum throughput. |
| **FR-04** | **Mode 3: Mapped Study** | Accept a `studyInstanceUid` with an array of series-to-prefix mappings; process mapped series concurrently. |
| **FR-05** | **Zero-Pixel Streaming** | Read required DICOM header tags without loading or deserializing `PixelData (7FE0,0010)` into memory. |
| **FR-06** | **Single & Multi-Frame Support** | Ingest single-frame objects and multi-frame objects (e.g. Ultrasound, Multi-frame CT/MR) with identical low latency. |
| **FR-07** | **Standardized Hierarchy** | Copy objects server-side to `{tenantId}/{studyInstanceUid}/{seriesInstanceUid}/{sopInstanceUid}.dcm`. |
| **FR-08** | **Factored Series Manifest** | Generate `{tenantId}/{studyInstanceUid}/{seriesInstanceUid}/manifest.json` containing `commonInstanceMetadata` and instance `overrides`. |
| **FR-09** | **Patient Tag Extraction** | Capture `PatientID`, `IssuerOfPatientID` (if present), `PatientName`, `PatientBirthDate`, and `PatientSex`. |
| **FR-10** | **Study Tag Extraction** | Capture `StudyInstanceUID`, `StudyDate`, `StudyTime`, `AccessionNumber`, `StudyDescription`, and `ReferringPhysicianName` (if present). |
| **FR-11** | **Series Tag Extraction** | Capture `SeriesInstanceUID`, `Modality`, `SeriesNumber`, `SeriesDescription`, and `BodyPartExamined`. |
| **FR-12** | **Instance Factored Tags** | Factor `imageType`, `numberOfFrames`, `rows`, `columns`, `bitsAllocated`, `bitsStored`, `highBit`, `pixelRepresentation`, `samplesPerPixel`, `photometricInterpretation`, `sopClassUid`, `transferSyntaxUid`, and `specificCharacterSet`. |
| **FR-13** | **Performance Telemetry** | Measure and report discovery time, header parse latency percentiles (P50/P90/Max), S3 copy latency, throughput (files/sec, MB/sec), and error details. |

### 2.2 Non-Functional Requirements (NFR)

* **NFR-01 (Throughput)**: Sustain $\ge 100\text{ files/sec}$ and $\ge 100\text{ MB/sec}$ on standard local storage/MinIO.
* **NFR-02 (Parse Latency)**: Maintain median header parse latency $\le 1.0\text{ ms}$ regardless of file size (from 50 KB to 500 MB).
* **NFR-03 (Memory Footprint)**: Bounded memory consumption; avoid buffering entire files or pixel arrays into memory.
* **NFR-04 (Zero Network Waste)**: Utilize S3 Server-Side `CopyObjectAsync` to avoid transferring binary image payloads through the Web API.
* **NFR-05 (Idempotency)**: Re-running ingestion for the same series must safely overwrite instances and regenerate manifests without duplication.

---

## 3. System Context

The following diagram illustrates how the DICOM Ingestion API sits between external imaging modalities, PACS systems, and MinIO/S3 object storage:

![alt text](image.png)
---

## 4. Component Architecture

The internal architecture follows Clean Architecture principles, enforcing strict separation of concerns, thread-safe asynchronous concurrency, and zero code duplication:
![alt text](image-1.png)

### Component Roles & Responsibilities

1. **`IngestionController`**: Exposes strongly-typed REST endpoints with explicit validation annotations (`[Required]`, `[MinLength]`). Rejects malformed requests before execution.
2. **`IngestionPipeline`**: Orchestrates discovery, parallel worker dispatch, timing telemetry, factoring execution, and manifest upload.
3. **`DicomMetadataReader`**: Wraps `fo-dicom` 5.2.6. Uses `FileReadOption.SkipLargeTags` on an S3 byte stream to extract Patient, Study, Series, and Image attributes without buffering `PixelData`.
4. **`S3StorageService`**: Wraps AWS SDK `IAmazonS3`. Configured for MinIO with `ForcePathStyle = true`, `UseChunkEncoding = false`, and streamlined byte-range reads (`ByteRange(0, 131071)`).
5. **`DicomDataGenerator`**: Test harness for generating valid synthetic DICOM datasets directly in MinIO with configurable counts, sizes (Small, Medium, Large), and frame structures (Single-Frame vs Multi-Frame).

---

## 5. Sequence Diagrams

### 5.1 Mode 2: Pre-Segregated Single Series (Zero Segregation Overhead)

```mermaid
sequenceDiagram
    autonumber
    actor Client as "PACS / Modality Client"
    participant API as "IngestionController (/series)"
    participant Pipe as "IngestionPipeline"
    participant S3 as "S3StorageService (MinIO)"
    participant Reader as "DicomMetadataReader (fo-dicom)"

    Client->>API: POST /api/v1/ingest/series { TenantId, SourcePrefix, StudyUid, SeriesUid }
    API->>Pipe: IngestSeriesAsync(request)
    Pipe->>S3: ListObjectsAsync(SourceBucket, SourcePrefix)
    S3-->>Pipe: Return N S3 Object Items

    par For Each File (Bounded Concurrency)
        Pipe->>S3: GetByteRangeStreamAsync(0, 128KB)
        S3-->>Pipe: Stream Header Bytes
        Pipe->>Reader: ExtractMetadataAsync(Stream)
        Reader-->>Pipe: Parsed Record (Patient, Study, Series, ImageAttrs)
        Pipe->>S3: CopyObjectAsync(SourceKey, DestKey)
        Note over S3: MinIO copies server-side<br/>Zero pixel bytes over network!
        S3-->>Pipe: S3 Copy OK
    end

    Pipe->>Pipe: FactorSeriesAttributes(Records)<br/>(Calculate Mode Baseline & Deltas)
    Pipe->>S3: PutJsonAsync(ManifestS3Key, SeriesManifest)
    S3-->>Pipe: Manifest Persisted OK
    Pipe-->>API: IngestResponse with Metrics & Factored Manifest
    API-->>Client: 200 OK { Metrics, SeriesManifests }
```

---

### 5.2 Mode 1: Bulk Unsegregated Dump (Dynamic Grouping)

```mermaid
sequenceDiagram
    autonumber
    actor Client as "External System"
    participant API as "IngestionController (/bulk)"
    participant Pipe as "IngestionPipeline"
    participant S3 as "S3StorageService (MinIO)"
    participant Reader as "DicomMetadataReader (fo-dicom)"

    Client->>API: POST /api/v1/ingest/bulk { TenantId, SourcePrefix }
    API->>Pipe: IngestBulkAsync(request)
    Pipe->>S3: ListObjectsAsync(SourceBucket, SourcePrefix)
    S3-->>Pipe: Return all S3 Objects in Dump Prefix

    par For Each File (Concurrent Discovery & Streaming)
        Pipe->>S3: GetByteRangeStreamAsync(0, 128KB)
        S3-->>Pipe: Stream Header Bytes
        Pipe->>Reader: ExtractMetadataAsync(Stream)
        Reader-->>Pipe: Extracted UIDs & Image Attributes
        Pipe->>S3: CopyObjectAsync(SourceKey, DestKey)
        S3-->>Pipe: Copy OK
    end

    Note over Pipe: Group parsed records by (StudyInstanceUid, SeriesInstanceUid)

    loop For Each Discovered Series Group
        Pipe->>Pipe: FactorSeriesAttributes(SeriesGroup)
        Pipe->>S3: PutJsonAsync({tenant}/{study}/{series}/manifest.json)
        S3-->>Pipe: Manifest Stored
    end

    Pipe-->>API: IngestResponse with all SeriesManifests & Aggregate Metrics
    API-->>Client: 200 OK
```

---

### 5.3 Mode 3: Pre-Segregated Study with Mapped Series Folders

```mermaid
sequenceDiagram
    autonumber
    actor Client as "Clinical Gateway"
    participant API as "IngestionController (/study)"
    participant Pipe as "IngestionPipeline"
    participant S3 as "S3StorageService"

    Client->>API: POST /api/v1/ingest/study { StudyUid, Series: [Series1, Series2, ...] }
    API->>Pipe: IngestStudyAsync(request)

    par For Each Series Mapping in Parallel
        Note over Pipe: Process Series 1 Folder (Scout)
        Pipe->>S3: Discover, Stream, Copy & Manifest Series 1
        S3-->>Pipe: Series 1 Manifest Created
    and
        Note over Pipe: Process Series 2 Folder (Axial Contrast)
        Pipe->>S3: Discover, Stream, Copy & Manifest Series 2
        S3-->>Pipe: Series 2 Manifest Created
    end

    Pipe-->>API: IngestResponse (Combined Series Manifests & Metrics)
    API-->>Client: 200 OK
```

---

## 6. Data Model & Factoring Schema

### 6.1 The Factoring Principle

In a clinical CT/MR acquisition containing 100 to 1,000 slices:
* Over 90% of DICOM tags (e.g. Dimensions, Bit Depth, Photometric Interpretation, Transfer Syntax, SOP Class) are identical for every slice.
* Repeating these tags for every slice creates huge JSON files (megabytes of redundant text) and wastes CPU cycles during parsing and serialization.

**The Solution: Factored Normalization**:
1. **`commonInstanceMetadata`**: The pipeline calculates the statistical **mode** (most frequent value) across all instances for each image attribute.
2. **`instances[].overrides`**: Slices that match the series baseline omit these attributes entirely. Only slices with deviations (e.g. localizer, different matrix, or re-encoded transfer syntax) contain an `overrides` dictionary.
![alt text](image-2.png)

---

### 6.2 Series Manifest JSON Specification

Stored at:  
`{tenantId}/{studyInstanceUid}/{seriesInstanceUid}/manifest.json`

```json
{
  "$schema": "https://json-schema.org/draft/2020-12/schema",
  "title": "SeriesManifest",
  "type": "object",
  "properties": {
    "tenantId": { "type": "string" },
    "manifestS3Key": { "type": "string" },
    "ingestTimestampUtc": { "type": "string", "format": "date-time" },
    "totalInstances": { "type": "integer" },
    "totalSizeBytes": { "type": "integer" },
    "patient": {
      "type": "object",
      "properties": {
        "patientId": { "type": "string" },
        "issuerOfPatientId": { "type": ["string", "null"] },
        "patientName": { "type": "string" },
        "patientBirthDate": { "type": ["string", "null"] },
        "patientSex": { "type": ["string", "null"] }
      },
      "required": ["patientId", "patientName"]
    },
    "study": {
      "type": "object",
      "properties": {
        "studyInstanceUid": { "type": "string" },
        "studyDate": { "type": ["string", "null"] },
        "studyTime": { "type": ["string", "null"] },
        "accessionNumber": { "type": ["string", "null"] },
        "studyDescription": { "type": ["string", "null"] },
        "referringPhysicianName": { "type": ["string", "null"] }
      },
      "required": ["studyInstanceUid"]
    },
    "series": {
      "type": "object",
      "properties": {
        "seriesInstanceUid": { "type": "string" },
        "modality": { "type": "string" },
        "seriesNumber": { "type": ["string", "null"] },
        "seriesDescription": { "type": ["string", "null"] },
        "bodyPartExamined": { "type": ["string", "null"] }
      },
      "required": ["seriesInstanceUid"]
    },
    "commonInstanceMetadata": {
      "type": "object",
      "properties": {
        "imageType": { "type": ["string", "null"] },
        "numberOfFrames": { "type": ["integer", "null"] },
        "rows": { "type": ["integer", "null"] },
        "columns": { "type": ["integer", "null"] },
        "bitsAllocated": { "type": ["integer", "null"] },
        "bitsStored": { "type": ["integer", "null"] },
        "highBit": { "type": ["integer", "null"] },
        "pixelRepresentation": { "type": ["integer", "null"] },
        "samplesPerPixel": { "type": ["integer", "null"] },
        "photometricInterpretation": { "type": ["string", "null"] },
        "sopClassUid": { "type": ["string", "null"] },
        "transferSyntaxUid": { "type": ["string", "null"] },
        "specificCharacterSet": { "type": ["string", "null"] }
      }
    },
    "instances": {
      "type": "array",
      "items": {
        "type": "object",
        "properties": {
          "sopInstanceUid": { "type": "string" },
          "instanceNumber": { "type": ["string", "null"] },
          "destinationS3Key": { "type": "string" },
          "sourceS3Key": { "type": "string" },
          "fileSizeBytes": { "type": "integer" },
          "overrides": { "type": ["object", "null"] }
        },
        "required": ["sopInstanceUid", "destinationS3Key", "sourceS3Key", "fileSizeBytes"]
      }
    }
  }
}
```

---

## 7. Storage Layout & Path Standardization

Both DICOM objects and manifests are arranged in a hierarchical structure aligned with DICOMweb QIDO/WADO URI hierarchies:

```
dicom-destination/
└── {tenantId}/
    └── {studyInstanceUid}/
        ├── {seriesInstanceUid_1}/
        │   ├── manifest.json                                      <-- Factored Series Manifest
        │   ├── {sopInstanceUid_1}.dcm                            <-- Standardized DICOM Object
        │   ├── {sopInstanceUid_2}.dcm
        │   └── {sopInstanceUid_N}.dcm
        └── {seriesInstanceUid_2}/
            ├── manifest.json
            ├── {sopInstanceUid_101}.dcm
            └── {sopInstanceUid_102}.dcm
```

### Key Path Rules
1. **Tenant Isolation**: Every object is prefixed with `{tenantId}` to guarantee multi-tenant boundaries.
2. **UID Sanitization**: All UIDs are sanitized to allow only alphanumeric characters, dots (`.`), underscores (`_`), and hyphens (`-`). Any directory traversal characters (`..`, `/`, `\`) are strictly stripped.
3. **Colocated Manifest**: Storing `manifest.json` directly inside the series directory enables zero-cost series metadata lookups for DICOMweb WADO-RS (`/studies/{study}/series/{series}/metadata`).

---

## 8. Performance & Scalability Analysis

### 8.1 Empirical Benchmark Results

Tested on local system with MinIO (`127.0.0.1:9000`) and Concurrency = 16:

| Benchmark Test Scenario | File Count | Data Size | Total Duration | Throughput (Files/sec) | Throughput (MB/sec) | Header Parse Latency (P50) | S3 Copy Latency (P50) |
| :--- | :---: | :---: | :---: | :---: | :---: | :---: | :---: |
| **Small Files (~50KB CR)** | 50 | 2.49 MB | **445.4 ms** | **112.26 files/s** | 5.59 MB/s | **0.35 ms** | 63.84 ms |
| **Medium Files (~512KB CT)** | 50 | 25.05 MB | **309.06 ms** | **161.78 files/s** | **81.05 MB/s** | **0.31 ms** | 68.76 ms |
| **Large Files (~10MB MG)** | 10 | 100.01 MB | **306.29 ms** | 32.65 files/s | **326.52 MB/s** | **0.37 ms** | 257.93 ms |
| **Multi-Frame Objects (16 Frames)** | 20 | 10.20 MB | **195.40 ms** | **102.35 files/s** | 52.20 MB/s | **0.33 ms** | 71.20 ms |

### 8.2 Architectural Performance Drivers

1. **Header Parsing Latency Invariance**:
   * Across all test scenarios—from 50 KB single frames to 10 MB images and multi-frame objects—the median header parse latency remained virtually identical at **~0.31 ms – 0.37 ms**.
   * *Driver*: `fo-dicom` reads the sequential preamble and metadata elements and halts before the `PixelData` tag. The massive binary payload is never decoded or buffered.
2. **High-Throughput S3 Server-Side Copy**:
   * Transfer throughput scaled directly with payload size up to **326.52 MB/sec**.
   * *Driver*: `CopyObjectAsync` instructs MinIO/S3 to duplicate the storage pointers internally on disk. Zero pixel bytes cross the network interface of the Web API server.
3. **Zero Segregation Overhead (Mode 2 & 3)**:
   * By passing `studyInstanceUid` and `seriesInstanceUid`, the pipeline skips multi-pass LINQ grouping and sorting, executing discovery, copy, and manifest writing in a single streaming pass.

---

## 9. Architectural Evolution (Next Phases)

While this synchronous pipeline serves as a high-performance benchmark and ingestion engine, the architecture is designed to transition seamlessly to a distributed, cloud-scale architecture:

```mermaid
graph TD
    API["Web API (Import Gateway)"]
    Queue[("Message Queue (AWS SQS / RabbitMQ / Kafka)")]
    Workers["Distributed Worker Pool (.NET BackgroundServices / ECS)"]
    S3[("MinIO / S3 Storage")]
    SQL[("PostgreSQL / SQL Index (QIDO-RS Indexes)")]

    API -->|Async Job Accepted (202 Accepted)| Queue
    Queue --> Workers
    Workers -->|Stream Headers & S3 Copy| S3
    Workers -->|Store Manifest| S3
    Workers -->|Upsert QIDO-RS Study/Series/Instance Rows| SQL
```

1. **Asynchronous Job Scheduling**: Convert `POST /api/v1/ingest/*` to return `202 Accepted` with a `jobId`, dispatching series processing units to an SQS queue or Kafka topic.
2. **SQL Metadata Indexing**: Ingest pipeline workers can directly project the `SeriesManifest` into relational SQL tables (`Studies`, `Series`, `Instances`) with indexes on `PatientID`, `AccessionNumber`, `StudyDate`, and `Modality` for sub-millisecond DICOMweb QIDO-RS queries.
3. **Dead Letter Queue & Auto-Retry**: Automated exponential backoff and DLQ routing for corrupt DICOM files or S3 transient rate-limits.

```text
curl -v --json '{"SourceBucket":"dicom-source","DestinationBucket":"dicom-destination","SourcePrefix":" demo-data8k/"}'  http://localhost:5000/api/v1/ingest/bulk

Store SHA256 of source dcm & store it manifest.
discard:sourceS3Key & destinationS3Key


curl.exe -s -X POST http://localhost:5000/api/v1/ingest/bulk -H Content-Type: application/json" -d '{"SourceBucket":"dicom-source","DestinationBucket":"dicom-destination","SourcePrefix":"demo-data8k/"}'
```
