# Comprehensive DICOM Ingestion Performance Benchmark Script
# Tests: Bulk Unsegregated, Pre-Segregated Series, Pre-Segregated Study, and Multi-Frame
param(
    [string]$ApiUrl = "http://localhost:5000",
    [string]$TenantId = "tenant-benchmark",
    [int]$Concurrency = 16
)

$ErrorActionPreference = "Stop"

Write-Host "==========================================================" -ForegroundColor Cyan
Write-Host "  DICOM Ingestion Benchmark: Bulk, Series & Study Modes   " -ForegroundColor Cyan
Write-Host "==========================================================" -ForegroundColor Cyan
Write-Host "API Endpoint: $ApiUrl"
Write-Host "Tenant ID:    $TenantId"
Write-Host "Concurrency:  $Concurrency"
Write-Host ""

# Health Check
Write-Host "[1/5] Checking API and MinIO health..." -ForegroundColor Yellow
try {
    $health = Invoke-RestMethod -Uri "$ApiUrl/api/v1/benchmark/health" -Method Get
    Write-Host "  Status: $($health.Status) | MinIO: $($health.MinioServiceUrl)" -ForegroundColor Green
} catch {
    Write-Host "  FAILED: Could not reach API at $ApiUrl. Ensure 'dotnet run' is active." -ForegroundColor Red
    exit 1
}

$summary = @()

# -------------------------------------------------------------------------------------------------
# TEST 1: Mode 1 - Bulk Unsegregated Import (50 files, mixed studies/series)
# -------------------------------------------------------------------------------------------------
Write-Host ""
Write-Host "----------------------------------------------------------" -ForegroundColor DarkCyan
Write-Host "TEST 1: Mode 1 - Bulk Unsegregated Dump (/api/v1/ingest/bulk)" -ForegroundColor DarkCyan
Write-Host "----------------------------------------------------------" -ForegroundColor DarkCyan
$gen1 = Invoke-RestMethod -Uri "$ApiUrl/api/v1/benchmark/generate-data" -Method Post -ContentType "application/json" -Body (@{
    Prefix = "bench-mode1-bulk/"
    FileCount = 50
    StudyCount = 2
    SeriesPerStudy = 2
    PayloadSize = "Medium"
} | ConvertTo-Json)
Write-Host "  Generated 50 files in $($gen1.TotalDurationMs) ms" -ForegroundColor Gray

$resp1 = Invoke-RestMethod -Uri "$ApiUrl/api/v1/ingest/bulk" -Method Post -ContentType "application/json" -Body (@{
    TenantId = $TenantId
    SourcePrefix = "bench-mode1-bulk/"
    ConcurrencyLimit = $Concurrency
    GenerateManifests = $true
} | ConvertTo-Json)
$m1 = $resp1.Metrics
Write-Host "  [DONE] Mode 1: $($m1.FilesProcessed) files across $($resp1.SeriesCount) series in $($m1.TotalDurationMs) ms ($($m1.ThroughputFilesPerSecond) files/sec, $($m1.ThroughputMegabytesPerSecond) MB/s)" -ForegroundColor Green

$summary += [PSCustomObject]@{
    Mode = "Mode 1: Bulk Dump"
    Files = $m1.FilesProcessed
    Series = $resp1.SeriesCount
    TotalMB = $m1.TotalMegabytesProcessed
    DurationMs = $m1.TotalDurationMs
    FilesPerSec = $m1.ThroughputFilesPerSecond
    MBPerSec = $m1.ThroughputMegabytesPerSecond
    ParseP50Ms = $m1.HeaderParseLatency.P50Ms
    CopyP50Ms = $m1.S3CopyLatency.P50Ms
}

# -------------------------------------------------------------------------------------------------
# TEST 2: Mode 2 - Pre-Segregated Single Series (/api/v1/ingest/series)
# -------------------------------------------------------------------------------------------------
Write-Host ""
Write-Host "----------------------------------------------------------" -ForegroundColor DarkCyan
Write-Host "TEST 2: Mode 2 - Pre-Segregated Single Series (/api/v1/ingest/series)" -ForegroundColor DarkCyan
Write-Host "----------------------------------------------------------" -ForegroundColor DarkCyan
$gen2 = Invoke-RestMethod -Uri "$ApiUrl/api/v1/benchmark/generate-data" -Method Post -ContentType "application/json" -Body (@{
    Prefix = "bench-mode2-series/"
    FileCount = 50
    StudyCount = 1
    SeriesPerStudy = 1
    PayloadSize = "Medium"
} | ConvertTo-Json)
$targetSeries = $gen2.GeneratedSeries[0]
Write-Host "  Generated single series with 50 files in $($gen2.TotalDurationMs) ms" -ForegroundColor Gray

$resp2 = Invoke-RestMethod -Uri "$ApiUrl/api/v1/ingest/series" -Method Post -ContentType "application/json" -Body (@{
    TenantId = $TenantId
    SourcePrefix = $targetSeries.S3Prefix
    StudyInstanceUid = $targetSeries.StudyInstanceUid
    SeriesInstanceUid = $targetSeries.SeriesInstanceUid
    ConcurrencyLimit = $Concurrency
    GenerateManifests = $true
} | ConvertTo-Json)
$m2 = $resp2.Metrics
Write-Host "  [DONE] Mode 2 (Zero Segregation Overhead): $($m2.FilesProcessed) files in $($m2.TotalDurationMs) ms ($($m2.ThroughputFilesPerSecond) files/sec, $($m2.ThroughputMegabytesPerSecond) MB/s)" -ForegroundColor Green

$summary += [PSCustomObject]@{
    Mode = "Mode 2: Pre-Seg Series"
    Files = $m2.FilesProcessed
    Series = $resp2.SeriesCount
    TotalMB = $m2.TotalMegabytesProcessed
    DurationMs = $m2.TotalDurationMs
    FilesPerSec = $m2.ThroughputFilesPerSecond
    MBPerSec = $m2.ThroughputMegabytesPerSecond
    ParseP50Ms = $m2.HeaderParseLatency.P50Ms
    CopyP50Ms = $m2.S3CopyLatency.P50Ms
}

# -------------------------------------------------------------------------------------------------
# TEST 3: Mode 3 - Pre-Segregated Study with Mapped Series (/api/v1/ingest/study)
# -------------------------------------------------------------------------------------------------
Write-Host ""
Write-Host "----------------------------------------------------------" -ForegroundColor DarkCyan
Write-Host "TEST 3: Mode 3 - Study with Mapped Series (/api/v1/ingest/study)" -ForegroundColor DarkCyan
Write-Host "----------------------------------------------------------" -ForegroundColor DarkCyan
$gen3 = Invoke-RestMethod -Uri "$ApiUrl/api/v1/benchmark/generate-data" -Method Post -ContentType "application/json" -Body (@{
    Prefix = "bench-mode3-study/"
    FileCount = 60
    StudyCount = 1
    SeriesPerStudy = 3
    OrganizeBySeriesFolders = $true
    PayloadSize = "Medium"
} | ConvertTo-Json)

$studyUid = $gen3.GeneratedSeries[0].StudyInstanceUid
$seriesMappings = $gen3.GeneratedSeries | ForEach-Object {
    @{
        SeriesInstanceUid = $_.SeriesInstanceUid
        SourcePrefix = $_.S3Prefix
        Modality = "CT"
    }
}
Write-Host "  Generated study with 3 series folders in $($gen3.TotalDurationMs) ms" -ForegroundColor Gray

$resp3 = Invoke-RestMethod -Uri "$ApiUrl/api/v1/ingest/study" -Method Post -ContentType "application/json" -Body (@{
    TenantId = $TenantId
    StudyInstanceUid = $studyUid
    Series = $seriesMappings
    ConcurrencyLimit = $Concurrency
    GenerateManifests = $true
} | ConvertTo-Json)
$m3 = $resp3.Metrics
Write-Host "  [DONE] Mode 3: $($m3.FilesProcessed) files across $($resp3.SeriesCount) mapped series in $($m3.TotalDurationMs) ms ($($m3.ThroughputFilesPerSecond) files/sec, $($m3.ThroughputMegabytesPerSecond) MB/s)" -ForegroundColor Green

$summary += [PSCustomObject]@{
    Mode = "Mode 3: Mapped Study"
    Files = $m3.FilesProcessed
    Series = $resp3.SeriesCount
    TotalMB = $m3.TotalMegabytesProcessed
    DurationMs = $m3.TotalDurationMs
    FilesPerSec = $m3.ThroughputFilesPerSecond
    MBPerSec = $m3.ThroughputMegabytesPerSecond
    ParseP50Ms = $m3.HeaderParseLatency.P50Ms
    CopyP50Ms = $m3.S3CopyLatency.P50Ms
}

# -------------------------------------------------------------------------------------------------
# TEST 4: Multi-Frame Modality Test (16 frames per DICOM object)
# -------------------------------------------------------------------------------------------------
Write-Host ""
Write-Host "----------------------------------------------------------" -ForegroundColor DarkCyan
Write-Host "TEST 4: Multi-Frame Modality Test (Ultrasound / Multi-frame CT)" -ForegroundColor DarkCyan
Write-Host "----------------------------------------------------------" -ForegroundColor DarkCyan
$gen4 = Invoke-RestMethod -Uri "$ApiUrl/api/v1/benchmark/generate-data" -Method Post -ContentType "application/json" -Body (@{
    Prefix = "bench-multiframe/"
    FileCount = 20
    StudyCount = 1
    SeriesPerStudy = 1
    IsMultiFrame = $true
    NumberOfFrames = 16
    PayloadSize = "Medium"
} | ConvertTo-Json)
Write-Host "  Generated 20 multi-frame DICOM files in $($gen4.TotalDurationMs) ms" -ForegroundColor Gray

$resp4 = Invoke-RestMethod -Uri "$ApiUrl/api/v1/ingest/bulk" -Method Post -ContentType "application/json" -Body (@{
    TenantId = $TenantId
    SourcePrefix = "bench-multiframe/"
    ConcurrencyLimit = $Concurrency
    GenerateManifests = $true
} | ConvertTo-Json)
$m4 = $resp4.Metrics
Write-Host "  [DONE] Multi-frame: $($m4.FilesProcessed) objects in $($m4.TotalDurationMs) ms (Header parse P50: $($m4.HeaderParseLatency.P50Ms) ms)" -ForegroundColor Green

$summary += [PSCustomObject]@{
    Mode = "Multi-Frame (16 frames)"
    Files = $m4.FilesProcessed
    Series = $resp4.SeriesCount
    TotalMB = $m4.TotalMegabytesProcessed
    DurationMs = $m4.TotalDurationMs
    FilesPerSec = $m4.ThroughputFilesPerSecond
    MBPerSec = $m4.ThroughputMegabytesPerSecond
    ParseP50Ms = $m4.HeaderParseLatency.P50Ms
    CopyP50Ms = $m4.S3CopyLatency.P50Ms
}

Write-Host ""
Write-Host "==========================================================" -ForegroundColor Cyan
Write-Host "  BENCHMARK SUMMARY ACROSS ALL MODES & MODALITIES" -ForegroundColor Cyan
Write-Host "==========================================================" -ForegroundColor Cyan
$summary | Format-Table -AutoSize
