# System Architecture & Design Document: Cloud-Native DICOM Ingestion Pipeline

**Document Version:** 1.0  
**Target Runtimes:** ASP.NET Core 8 (.NET 8), AWS SDK for .NET, Fellow Oak DICOM (`fo-dicom` 5.2.6)  
**Storage Target:** Amazon S3 / MinIO Object Storage  

---

## 1. Executive Summary & Problem Statement

Modern medical imaging networks process millions of DICOM objects across varied modalities (e.g., CT, MR, X-Ray/CR, Ultrasound, Pathology/WSI) comprising both single-frame and multi-frame datasets. 

Traditional DICOM ingestion pipelines often suffer from critical architectural bottlenecks:
1. **Network & Memory Saturation**: Downloading entire multi-megabyte DICOM objects (95–99% of which is binary Pixel Data) to the application layer to parse headers exhaust network bandwidth and heap memory.
2. **Study-Level Contention**: Treating the **Study** as the unit of processing creates lock contention and race conditions when modalities acquire and upload series incrementally.
3. **Manifest Bloating**: Repeating identical imaging parameters across hundreds or thousands of slices in a series causes massive JSON redundancy.
4. **Rigid Folder Assumptions**: Ingestion engines often force either pure unsegregated dumps or strict pre-sorted structures, causing unnecessary server-side sorting or client-side preparation overhead.

This design document establishes a high-performance, multitenant DICOM ingestion pipeline in **ASP.NET Core 8** designed to eliminate these bottlenecks through:
* **Zero-Pixel Memory Overhead**: Streaming and extracting only header elements via `fo-dicom` with `FileReadOption.SkipLargeTags`.
* **S3 Server-Side Copying**: Zero data re-upload across the network; objects are moved internally within S3 storage at disk/IOPS speeds.
* **Series as the Atomic Unit of Processing**: Dedicated series processing and manifest generation at `{tenantId}/{studyInstanceUid}/{seriesInstanceUid}/manifest.json`.
* **Attribute Factoring**: Normalizing shared series attributes into a baseline while recording only delta overrides for variant instances.
* **Flexible Ingestion Modes**: Native support for **Bulk Unsegregated Dumps**, **Pre-Segregated Single Series**, and **Studies with Mapped Series Folders**.

---

## 2. Requirements Specification

### 2.1 Functional Requirements (FR)

| ID | Requirement | Description |
| :--- | :--- | :--- |
| **FR-01** | **Multi-Tenancy** | Isolate ingestion, storage, and manifests strictly by `tenantId`. |
| **FR-02** | **Mode 1: Bulk Ingestion** | Accept an S3 prefix containing arbitrary mixed patients, studies, and series; dynamically group and manifest by series. |
| **FR-03** | **Mode 2: Pre-Segregated Series** | Accept an S3 prefix with caller-asserted `studyInstanceUid` and `seriesInstanceUid`; bypass dynamic grouping entirely for maximum throughput. |
| **FR-04** | **Mode 3: Mapped Study** | Accept a `studyInstanceUid` with an array of series-to-prefix mappings; process mapped series concurrently. |
| **FR-05** | **Zero-Pixel Streaming** | Read required DICOM header tags without loading or deserializing `PixelData (7FE0,0010)` into memory. |
| **FR-06** | **Single & Multi-Frame Support** | Ingest single-frame objects and multi-frame objects (e.g. Ultrasound, Multi-frame CT/MR) with identical low latency. |
| **FR-07** | **Standardized Hierarchy** | Copy objects server-side to `{tenantId}/{studyInstanceUid}/{seriesInstanceUid}/{sopInstanceUid}.dcm`. |
| **FR-08** | **Factored Series Manifest** | Generate `{tenantId}/{studyInstanceUid}/{seriesInstanceUid}/manifest.json` containing `commonInstanceMetadata` and instance `overrides`. |
| **FR-09** | **Patient Tag Extraction** | Capture `PatientID`, `IssuerOfPatientID` (if present), `PatientName`, `PatientBirthDate`, and `PatientSex`. |
| **FR-10** | **Study Tag Extraction** | Capture `StudyInstanceUID`, `StudyDate`, `StudyTime`, `AccessionNumber`, `StudyDescription`, and `ReferringPhysicianName` (if present). |
| **FR-11** | **Series Tag Extraction** | Capture `SeriesInstanceUID`, `Modality`, `SeriesNumber`, `SeriesDescription`, and `BodyPartExamined`. |
| **FR-12** | **Instance Factored Tags** | Factor `imageType`, `numberOfFrames`, `rows`, `columns`, `bitsAllocated`, `bitsStored`, `highBit`, `pixelRepresentation`, `samplesPerPixel`, `photometricInterpretation`, `sopClassUid`, `transferSyntaxUid`, and `specificCharacterSet`. |
| **FR-13** | **Performance Telemetry** | Measure and report discovery time, header parse latency percentiles (P50/P90/Max), S3 copy latency, throughput (files/sec, MB/sec), and error details. |

### 2.2 Non-Functional Requirements (NFR)

* **NFR-01 (Throughput)**: Sustain $\ge 100\text{ files/sec}$ and $\ge 100\text{ MB/sec}$ on standard local storage/MinIO.
* **NFR-02 (Parse Latency)**: Maintain median header parse latency $\le 1.0\text{ ms}$ regardless of file size (from 50 KB to 500 MB).
* **NFR-03 (Memory Footprint)**: Bounded memory consumption; avoid buffering entire files or pixel arrays into memory.
* **NFR-04 (Zero Network Waste)**: Utilize S3 Server-Side `CopyObjectAsync` to avoid transferring binary image payloads through the Web API.
* **NFR-05 (Idempotency)**: Re-running ingestion for the same series must safely overwrite instances and regenerate manifests without duplication.

---

## 3. System Context

The following diagram illustrates how the DICOM Ingestion API sits between external imaging modalities, PACS systems, and MinIO/S3 object storage:

```mermaid
%%{init: {
  'theme': 'base',
  'themeVariables': {
    'primaryColor': '#ffffff',
    'primaryTextColor': '#24292f',
    'primaryBorderColor': '#57606a',
    'lineColor': '#57606a',
    'secondaryColor': '#ffffff',
    'tertiaryColor': '#ffffff',
    'clusterBkg': '#ffffff',
    'clusterBorder': '#57606a',
    'edgeLabelBackground': '#ffffff',
    'nodeBorder': '#57606a',
    'fontFamily': 'Segoe UI, Helvetica, Arial, sans-serif',
    'fontSize': '12px'
  },
  'flowchart': {
    'curve': 'stepAfter',
    'nodeSpacing': 45,
    'rankSpacing': 45
  }
}}%%
graph TD
    subgraph External["External Medical Imaging Sources"]
        Edge["Cloud Gateway / Edge Connectors"]
        PACS["Hospital PACS / VNA Archives"]
        Modalities["Clinical Modalities (CT, MR, US, X-Ray)"]
    end

    subgraph IngestionSystem["Cloud-Native DICOM Pipeline"]
        API["ASP.NET Core 8 Web API (DicomIngestion.Api)"]
        Engine["Ingestion Pipeline Engine"]
        Reader["fo-dicom Stream Reader (SkipLargeTags)"]
        API --> Engine
        Engine --> Reader
    end

    subgraph ObjectStorage["MinIO / AWS S3 Storage"]
        DstBucket["Destination Bucket: dicom-destination"]
        SrcBucket["Source Bucket: dicom-source"]
    end

    subgraph Downstream["Downstream Consumers"]
        Viewers["Diagnostic Web Viewers (OHIF, Cornerstone)"]
        QIDO["DICOMweb QIDO-RS / WADO-RS Services"]
    end

    %% API Triggers (Left side)
    Edge -->|Trigger Ingest Request| API
    PACS -->|Trigger Ingest Request| API

    %% Ingestion Uploads (Right side to Source Bucket)
    Modalities -->|Raw Upload / Batch Export| SrcBucket
    PACS -->|Export| SrcBucket
    Edge -->|Pre-Segregated Series| SrcBucket

    %% Pipeline Operations
    Reader -->|Byte-Range Header Read| SrcBucket
    Engine -->|S3 Server-Side Copy| DstBucket
    Engine -->|Write Factored Series Manifest| DstBucket

    %% Downstream Access
    DstBucket --> Viewers
    DstBucket --> QIDO
```

---

## 4. Component Architecture

The internal architecture follows Clean Architecture principles, enforcing strict separation of concerns, thread-safe asynchronous concurrency, and zero code duplication:

```mermaid
%%{init: {
  'theme': 'base',
  'themeVariables': {
    'primaryColor': '#ffffff',
    'primaryTextColor': '#24292f',
    'primaryBorderColor': '#57606a',
    'lineColor': '#57606a',
    'secondaryColor': '#ffffff',
    'tertiaryColor': '#ffffff',
    'clusterBkg': '#ffffff',
    'clusterBorder': '#57606a',
    'edgeLabelBackground': '#ffffff',
    'nodeBorder': '#57606a',
    'fontFamily': 'Segoe UI, Helvetica, Arial, sans-serif',
    'fontSize': '12px'
  },
  'flowchart': {
    'curve': 'stepAfter',
    'nodeSpacing': 45,
    'rankSpacing': 45
  }
}}%%
graph TD
    subgraph ControllersLayer["API Layer (Controllers)"]
        C_Bulk["POST /api/v1/ingest/bulk"]
        C_Series["POST /api/v1/ingest/series"]
        C_Study["POST /api/v1/ingest/study"]
        C_Sync["POST /api/v1/ingest/sync (Fallback)"]
        C_Bench["POST /api/v1/benchmark/generate-data"]
    end

    subgraph ServicesLayer["Core Ingestion Engine (Services)"]
        Pipeline["IIngestionPipeline (IngestionPipeline.cs)"]
        Factoring["Attribute Factoring Engine (FactorSeriesAttributes)"]
        Reader["IDicomMetadataReader (DicomMetadataReader.cs)"]
        Generator["IDicomDataGenerator (DicomDataGenerator.cs)"]
    end

    subgraph StorageLayer["Storage Abstraction Layer"]
        S3Service["IS3StorageService (S3StorageService.cs)"]
        AWSSDK["Amazon S3 Client (AWSSDK.S3)"]
    end

    C_Bulk --> Pipeline
    C_Series --> Pipeline
    C_Study --> Pipeline
    C_Sync --> Pipeline
    C_Bench --> Generator

    Pipeline --> S3Service
    Pipeline --> Reader
    Pipeline --> Factoring

    Generator --> S3Service
    S3Service --> AWSSDK
```

### Component Roles & Responsibilities

1. **`IngestionController`**: Exposes strongly-typed REST endpoints with explicit validation annotations (`[Required]`, `[MinLength]`). Rejects malformed requests before execution.
2. **`IngestionPipeline`**: Orchestrates discovery, parallel worker dispatch, timing telemetry, factoring execution, and manifest upload.
3. **`DicomMetadataReader`**: Wraps `fo-dicom` 5.2.6. Uses `FileReadOption.SkipLargeTags` on an S3 byte stream to extract Patient, Study, Series, and Image attributes without buffering `PixelData`.
4. **`S3StorageService`**: Wraps AWS SDK `IAmazonS3`. Configured for MinIO with `ForcePathStyle = true`, `UseChunkEncoding = false`, and streamlined byte-range reads (`ByteRange(0, 131071)`).
5. **`DicomDataGenerator`**: Test harness for generating valid synthetic DICOM datasets directly in MinIO with configurable counts, sizes (Small, Medium, Large), and frame structures (Single-Frame vs Multi-Frame).

---

## 5. Sequence Diagrams

### 5.1 Mode 2: Pre-Segregated Single Series (Zero Segregation Overhead)

```mermaid
%%{init: {
  'theme': 'base',
  'themeVariables': {
    'actorBkg': '#ffffff',
    'actorBorder': '#57606a',
    'actorTextColor': '#24292f',
    'signalColor': '#57606a',
    'signalTextColor': '#24292f',
    'labelBoxBkgColor': '#ffffff',
    'labelBoxBorderColor': '#57606a',
    'labelTextColor': '#24292f',
    'loopTextColor': '#24292f',
    'noteBorderColor': '#57606a',
    'noteBkgColor': '#ffffff',
    'noteTextColor': '#24292f',
    'activationBorderColor': '#57606a',
    'activationBkgColor': '#f6f8fa',
    'fontFamily': 'Segoe UI, Helvetica, Arial, sans-serif',
    'fontSize': '12px'
  }
}}%%
sequenceDiagram
    autonumber
    actor Client as PACS / Modality Client
    participant API as IngestionController (/series)
    participant Pipe as IngestionPipeline
    participant S3 as S3StorageService (MinIO)
    participant Reader as DicomMetadataReader (fo-dicom)

    Client->>API: POST /api/v1/ingest/series (TenantId, SourcePrefix, StudyUid, SeriesUid)
    API->>Pipe: IngestSeriesAsync(request)
    Pipe->>S3: ListObjectsAsync(SourceBucket, SourcePrefix)
    S3-->>Pipe: Return N S3 Object Items

    par For Each File (Bounded Concurrency)
        Pipe->>S3: GetByteRangeStreamAsync(0, 128KB)
        S3-->>Pipe: Stream Header Bytes
        Pipe->>Reader: ExtractMetadataAsync(Stream)
        Reader-->>Pipe: Parsed Record (Patient, Study, Series, ImageAttrs)
        Pipe->>S3: CopyObjectAsync(SourceKey, DestKey)
        Note over S3: MinIO copies server-side (zero pixel bytes transferred over network)
        S3-->>Pipe: S3 Copy OK
    end

    Pipe->>Pipe: FactorSeriesAttributes(Records) - Calculate Mode Baseline and Deltas
    Pipe->>S3: PutJsonAsync(ManifestS3Key, SeriesManifest)
    S3-->>Pipe: Manifest Persisted OK
    Pipe-->>API: IngestResponse with Metrics and Factored Manifest
    API-->>Client: 200 OK (Metrics, SeriesManifests)
```

---

### 5.2 Mode 1: Bulk Unsegregated Dump (Dynamic Grouping)

```mermaid
%%{init: {
  'theme': 'base',
  'themeVariables': {
    'actorBkg': '#ffffff',
    'actorBorder': '#57606a',
    'actorTextColor': '#24292f',
    'signalColor': '#57606a',
    'signalTextColor': '#24292f',
    'labelBoxBkgColor': '#ffffff',
    'labelBoxBorderColor': '#57606a',
    'labelTextColor': '#24292f',
    'loopTextColor': '#24292f',
    'noteBorderColor': '#57606a',
    'noteBkgColor': '#ffffff',
    'noteTextColor': '#24292f',
    'activationBorderColor': '#57606a',
    'activationBkgColor': '#f6f8fa',
    'fontFamily': 'Segoe UI, Helvetica, Arial, sans-serif',
    'fontSize': '12px'
  }
}}%%
sequenceDiagram
    autonumber
    actor Client as External System
    participant API as IngestionController (/bulk)
    participant Pipe as IngestionPipeline
    participant S3 as S3StorageService (MinIO)
    participant Reader as DicomMetadataReader (fo-dicom)

    Client->>API: POST /api/v1/ingest/bulk (TenantId, SourcePrefix)
    API->>Pipe: IngestBulkAsync(request)
    Pipe->>S3: ListObjectsAsync(SourceBucket, SourcePrefix)
    S3-->>Pipe: Return all S3 Objects in Dump Prefix

    par For Each File (Concurrent Discovery & Streaming)
        Pipe->>S3: GetByteRangeStreamAsync(0, 128KB)
        S3-->>Pipe: Stream Header Bytes
        Pipe->>Reader: ExtractMetadataAsync(Stream)
        Reader-->>Pipe: Extracted UIDs and Image Attributes
        Pipe->>S3: CopyObjectAsync(SourceKey, DestKey)
        S3-->>Pipe: Copy OK
    end

    Note over Pipe: Group parsed records by (StudyInstanceUid, SeriesInstanceUid)

    loop For Each Discovered Series Group
        Pipe->>Pipe: FactorSeriesAttributes(SeriesGroup)
        Pipe->>S3: PutJsonAsync(manifest.json)
        S3-->>Pipe: Manifest Stored
    end

    Pipe-->>API: IngestResponse with all SeriesManifests and Aggregate Metrics
    API-->>Client: 200 OK
```

---

### 5.3 Mode 3: Pre-Segregated Study with Mapped Series Folders

```mermaid
%%{init: {
  'theme': 'base',
  'themeVariables': {
    'actorBkg': '#ffffff',
    'actorBorder': '#57606a',
    'actorTextColor': '#24292f',
    'signalColor': '#57606a',
    'signalTextColor': '#24292f',
    'labelBoxBkgColor': '#ffffff',
    'labelBoxBorderColor': '#57606a',
    'labelTextColor': '#24292f',
    'loopTextColor': '#24292f',
    'noteBorderColor': '#57606a',
    'noteBkgColor': '#ffffff',
    'noteTextColor': '#24292f',
    'activationBorderColor': '#57606a',
    'activationBkgColor': '#f6f8fa',
    'fontFamily': 'Segoe UI, Helvetica, Arial, sans-serif',
    'fontSize': '12px'
  }
}}%%
sequenceDiagram
    autonumber
    actor Client as Clinical Gateway
    participant API as IngestionController (/study)
    participant Pipe as IngestionPipeline
    participant S3 as S3StorageService (MinIO)

    Client->>API: POST /api/v1/ingest/study (StudyUid, Series Mappings)
    API->>Pipe: IngestStudyAsync(request)

    par For Each Series Mapping in Parallel
        Note over Pipe: Process Series 1 Folder (Scout)
        Pipe->>S3: Discover, Stream, Copy and Manifest Series 1
        S3-->>Pipe: Series 1 Manifest Created
    and
        Note over Pipe: Process Series 2 Folder (Axial Contrast)
        Pipe->>S3: Discover, Stream, Copy and Manifest Series 2
        S3-->>Pipe: Series 2 Manifest Created
    end

    Pipe-->>API: IngestResponse (Combined Series Manifests and Metrics)
    API-->>Client: 200 OK
```

---

## 6. Data Model & Factoring Schema

### 6.1 The Factoring Principle

In a clinical CT/MR acquisition containing 100 to 1,000 slices:
* Over 90% of DICOM tags (e.g. Dimensions, Bit Depth, Photometric Interpretation, Transfer Syntax, SOP Class) are identical for every slice.
* Repeating these tags for every slice creates huge JSON files (megabytes of redundant text) and wastes CPU cycles during parsing and serialization.

**The Solution: Factored Normalization**:
1. **`commonInstanceMetadata`**: The pipeline calculates the statistical **mode** (most frequent value) across all instances for each image attribute.
2. **`instances[].overrides`**: Slices that match the series baseline omit these attributes entirely. Only slices with deviations (e.g. localizer, different matrix, or re-encoded transfer syntax) contain an `overrides` dictionary.

```mermaid
%%{init: {
  'theme': 'base',
  'themeVariables': {
    'primaryColor': '#ffffff',
    'primaryTextColor': '#24292f',
    'primaryBorderColor': '#57606a',
    'lineColor': '#57606a',
    'secondaryColor': '#ffffff',
    'tertiaryColor': '#ffffff',
    'clusterBkg': '#ffffff',
    'clusterBorder': '#57606a',
    'edgeLabelBackground': '#ffffff',
    'nodeBorder': '#57606a',
    'fontFamily': 'Segoe UI, Helvetica, Arial, sans-serif',
    'fontSize': '12px'
  },
  'flowchart': {
    'curve': 'stepAfter',
    'nodeSpacing': 45,
    'rankSpacing': 45
  }
}}%%
graph LR
    subgraph RawInstances [Raw Instance Tags]
        I1["Slice 1: Rows=512, Cols=512, Bits=16, TransferSyntax=ExplicitVR"]
        I2["Slice 2: Rows=512, Cols=512, Bits=16, TransferSyntax=ExplicitVR"]
        I3["Slice 3: Rows=256, Cols=256, Bits=16, TransferSyntax=ExplicitVR"]
    end

    subgraph Factored [Factored Series Normalization]
        Common["commonInstanceMetadata: Rows=512, Cols=512, Bits=16, TransferSyntax=ExplicitVR"]
        F1["Instance 1: SOP-1, Number: 1 (overrides: null)"]
        F2["Instance 2: SOP-2, Number: 2 (overrides: null)"]
        F3["Instance 3: SOP-3, Number: 3 (overrides: Rows=256, Cols=256)"]
    end

    RawInstances --> Factored
```

---

### 6.2 Series Manifest JSON Specification

Stored at:  
`{tenantId}/{studyInstanceUid}/{seriesInstanceUid}/manifest.json`

```json
{
  "$schema": "https://json-schema.org/draft/2020-12/schema",
  "title": "SeriesManifest",
  "type": "object",
  "properties": {
    "tenantId": { "type": "string" },
    "manifestS3Key": { "type": "string" },
    "ingestTimestampUtc": { "type": "string", "format": "date-time" },
    "totalInstances": { "type": "integer" },
    "totalSizeBytes": { "type": "integer" },
    "patient": {
      "type": "object",
      "properties": {
        "patientId": { "type": "string" },
        "issuerOfPatientId": { "type": ["string", "null"] },
        "patientName": { "type": "string" },
        "patientBirthDate": { "type": ["string", "null"] },
        "patientSex": { "type": ["string", "null"] }
      },
      "required": ["patientId", "patientName"]
    },
    "study": {
      "type": "object",
      "properties": {
        "studyInstanceUid": { "type": "string" },
        "studyDate": { "type": ["string", "null"] },
        "studyTime": { "type": ["string", "null"] },
        "accessionNumber": { "type": ["string", "null"] },
        "studyDescription": { "type": ["string", "null"] },
        "referringPhysicianName": { "type": ["string", "null"] }
      },
      "required": ["studyInstanceUid"]
    },
    "series": {
      "type": "object",
      "properties": {
        "seriesInstanceUid": { "type": "string" },
        "modality": { "type": "string" },
        "seriesNumber": { "type": ["string", "null"] },
        "seriesDescription": { "type": ["string", "null"] },
        "bodyPartExamined": { "type": ["string", "null"] }
      },
      "required": ["seriesInstanceUid"]
    },
    "commonInstanceMetadata": {
      "type": "object",
      "properties": {
        "imageType": { "type": ["string", "null"] },
        "numberOfFrames": { "type": ["integer", "null"] },
        "rows": { "type": ["integer", "null"] },
        "columns": { "type": ["integer", "null"] },
        "bitsAllocated": { "type": ["integer", "null"] },
        "bitsStored": { "type": ["integer", "null"] },
        "highBit": { "type": ["integer", "null"] },
        "pixelRepresentation": { "type": ["integer", "null"] },
        "samplesPerPixel": { "type": ["integer", "null"] },
        "photometricInterpretation": { "type": ["string", "null"] },
        "sopClassUid": { "type": ["string", "null"] },
        "transferSyntaxUid": { "type": ["string", "null"] },
        "specificCharacterSet": { "type": ["string", "null"] }
      }
    },
    "instances": {
      "type": "array",
      "items": {
        "type": "object",
        "properties": {
          "sopInstanceUid": { "type": "string" },
          "instanceNumber": { "type": ["string", "null"] },
          "destinationS3Key": { "type": "string" },
          "sourceS3Key": { "type": "string" },
          "fileSizeBytes": { "type": "integer" },
          "overrides": { "type": ["object", "null"] }
        },
        "required": ["sopInstanceUid", "destinationS3Key", "sourceS3Key", "fileSizeBytes"]
      }
    }
  }
}
```

---

## 7. Storage Layout & Path Standardization

Both DICOM objects and manifests are arranged in a hierarchical structure aligned with DICOMweb QIDO/WADO URI hierarchies:

```
dicom-destination/
└── {tenantId}/
    └── {studyInstanceUid}/
        ├── {seriesInstanceUid_1}/
        │   ├── manifest.json                                      <-- Factored Series Manifest
        │   ├── {sopInstanceUid_1}.dcm                            <-- Standardized DICOM Object
        │   ├── {sopInstanceUid_2}.dcm
        │   └── {sopInstanceUid_N}.dcm
        └── {seriesInstanceUid_2}/
            ├── manifest.json
            ├── {sopInstanceUid_101}.dcm
            └── {sopInstanceUid_102}.dcm
```

### Key Path Rules
1. **Tenant Isolation**: Every object is prefixed with `{tenantId}` to guarantee multi-tenant boundaries.
2. **UID Sanitization**: All UIDs are sanitized to allow only alphanumeric characters, dots (`.`), underscores (`_`), and hyphens (`-`). Any directory traversal characters (`..`, `/`, `\`) are strictly stripped.
3. **Colocated Manifest**: Storing `manifest.json` directly inside the series directory enables zero-cost series metadata lookups for DICOMweb WADO-RS (`/studies/{study}/series/{series}/metadata`).

---

## 8. Performance & Scalability Analysis

### 8.1 Empirical Benchmark Results

Tested on local system with MinIO (`127.0.0.1:9000`) and Concurrency = 16:

| Benchmark Test Scenario | File Count | Data Size | Total Duration | Throughput (Files/sec) | Throughput (MB/sec) | Header Parse Latency (P50) | S3 Copy Latency (P50) |
| :--- | :---: | :---: | :---: | :---: | :---: | :---: | :---: |
| **Small Files (~50KB CR)** | 50 | 2.49 MB | **445.4 ms** | **112.26 files/s** | 5.59 MB/s | **0.35 ms** | 63.84 ms |
| **Medium Files (~512KB CT)** | 50 | 25.05 MB | **309.06 ms** | **161.78 files/s** | **81.05 MB/s** | **0.31 ms** | 68.76 ms |
| **Large Files (~10MB MG)** | 10 | 100.01 MB | **306.29 ms** | 32.65 files/s | **326.52 MB/s** | **0.37 ms** | 257.93 ms |
| **Multi-Frame Objects (16 Frames)** | 20 | 10.20 MB | **195.40 ms** | **102.35 files/s** | 52.20 MB/s | **0.33 ms** | 71.20 ms |

### 8.2 Architectural Performance Drivers

1. **Header Parsing Latency Invariance**:
   * Across all test scenarios—from 50 KB single frames to 10 MB images and multi-frame objects—the median header parse latency remained virtually identical at **~0.31 ms – 0.37 ms**.
   * *Driver*: `fo-dicom` reads the sequential preamble and metadata elements and halts before the `PixelData` tag. The massive binary payload is never decoded or buffered.
2. **High-Throughput S3 Server-Side Copy**:
   * Transfer throughput scaled directly with payload size up to **326.52 MB/sec**.
   * *Driver*: `CopyObjectAsync` instructs MinIO/S3 to duplicate the storage pointers internally on disk. Zero pixel bytes cross the network interface of the Web API server.
3. **Zero Segregation Overhead (Mode 2 & 3)**:
   * By passing `studyInstanceUid` and `seriesInstanceUid`, the pipeline skips multi-pass LINQ grouping and sorting, executing discovery, copy, and manifest writing in a single streaming pass.

---

## 9. Progressive Series Ingestion, Grouped Queuing & Consistency Architecture

### 9.1 The Progressive Multi-Batch Ingestion Challenge
In modern medical imaging environments (such as CT, MRI, and Tomosynthesis scanners), imaging datasets are acquired progressively over time. Modalities often stream slices to object storage across **multiple separate batches or import requests** (e.g., slices 1–10 in batch 1, slices 11–30 in batch 2).

Without deliberate synchronization and cumulative merge mechanics, progressive multi-batch ingestion causes critical architectural failures:
1. **The Lost Update Anomaly (Read-Modify-Write Race)**: If two concurrent import requests process disjoint slices for the same series, worker A and worker B simultaneously read an empty or partial manifest. Worker B overwrites Worker A's manifest in S3, causing slices 1–10 to be dropped from the series manifest.
2. **Database & S3 Desynchronization**: If the database purges instance records on each batch without merging, only the most recent batch remains indexed in SQLite, while prior `.dcm` files linger orphaned in S3 storage.
3. **Contention vs Parallelism Dilemma**: Locking the entire ingestion engine or the study container degrades throughput, whereas allowing uncoordinated parallel writes corrupts series manifests.

---

### 9.2 Core Invariant: S3 Manifest $\equiv$ Database Index Consistency
At any point in time, whether slices for a series arrive in a single bulk request or across dozens of progressive batches, the pipeline maintains strict consistency between S3 and the relational index:

$$\forall (tenant, study, series): \quad \text{S3Manifest}(\text{Instances}) \equiv \text{SQLite}(\text{Instances}) = \bigcup_{b=1}^{B} \text{Slices}(b)$$

Whenever an incremental batch arrives:
1. **Critical Section Entry**: An exclusive lock is acquired for the partition key: `groupKey = $"{tenantId}_{seriesInstanceUid}"`.
2. **Manifest Retrieval**: The pipeline fetches the existing `manifest.json` from S3 (`_s3Service.GetJsonAsync<SeriesManifest>`).
3. **Factored Instance Merge**:
   - The new incoming slices are factored against the series baseline attributes.
   - Slices are merged into a dictionary keyed by `SopInstanceUid`. Re-uploaded slices cleanly update existing entries; new slices append seamlessly.
   - Slices are sorted by `InstanceNumber` and `SopInstanceUid`.
   - `TotalInstances` and `TotalSizeBytes` are updated to reflect the true cumulative state.
4. **Authoritative S3 Persistence**: The cumulative `SeriesManifest` is written to S3 (`PutJsonAsync`).
5. **Atomic SQLite Projection Update**: `IndexManifestAsync` runs inside an explicit database transaction:
   - Purges prior instance records for this series (`ExecuteDeleteAsync`).
   - Inserts all cumulative slice records in multi-row batches (`AddRange`).
   - Recalculates study-level aggregates (`NumberOfStudyRelatedSeries`, `NumberOfStudyRelatedInstances`, `ModalitiesInStudy`) in a single pass via SQLite `UPDATE ... FROM`.
   - Commits atomically and clears EF Core change tracking references.

---

### 9.3 Partitioned Group Concurrency: The `tenant_series_instance_uid` Pattern

To achieve maximum throughput while guaranteeing zero race conditions, concurrency is partitioned by `tenant_series_instance_uid`:
- **Serial Execution per Series**: Operations affecting the **same series** are queued and executed strictly sequentially.
- **Parallel Execution across Series**: Operations affecting **different series** execute concurrently with full parallelism up to system capacity.

```mermaid
%%{init: {
  'theme': 'base',
  'themeVariables': {
    'primaryColor': '#ffffff',
    'primaryTextColor': '#24292f',
    'primaryBorderColor': '#57606a',
    'lineColor': '#57606a',
    'secondaryColor': '#ffffff',
    'clusterBkg': '#ffffff',
    'clusterBorder': '#57606a'
  }
}}%%
graph TD
    subgraph IngestionTraffic["Incoming Ingestion Batches"]
        B1["Batch 1: Study 1, Series A (Slices 1-10)"]
        B2["Batch 2: Study 1, Series A (Slices 11-30)"]
        B3["Batch 3: Study 2, Series B (Slices 1-50)"]
    end

    subgraph PartitionRouter["Group Key Router: groupKey = tenantId + '_' + seriesUid"]
        PR["Keyed Concurrency Dispatcher"]
    end

    subgraph Queues["Partitioned Queues / Keyed Locks"]
        QA["Series A Lock / FIFO Queue (Strictly Serial)"]
        QB["Series B Lock / FIFO Queue (Strictly Serial)"]
    end

    subgraph Execution["Concurrent Worker Execution"]
        WA1["Series A: Process Batch 1 -> S3 Manifest v1 (10) -> DB (10)"]
        WA2["Series A: Wait -> Process Batch 2 -> Merge S3 Manifest v2 (30) -> DB (30)"]
        WB["Series B: Process Batch 3 in Parallel -> S3 Manifest (50) -> DB (50)"]
    end

    B1 --> PR
    B2 --> PR
    B3 --> PR

    PR -->|Key: tenant-001_SeriesA| QA
    PR -->|Key: tenant-001_SeriesB| QB

    QA --> WA1
    WA1 -.->|Unlocks| WA2
    QB --> WB
```

---

### 9.4 In-Memory Implementation: `IKeyedLockService`

In the standalone ASP.NET Core service, this pattern is implemented via `IKeyedLockService` / `KeyedLockService`:
- Uses a `ConcurrentDictionary<string, RefCountedSemaphore>` storing a dedicated `SemaphoreSlim(1, 1)` per active series key.
- When multiple batches arrive for `SeriesA`, the first acquires the lock while subsequent requests wait asynchronously (`await item.Semaphore.WaitAsync(ct)`).
- Distinct series keys allocate separate semaphores, running concurrently on the thread pool without blocking each other.
- When all waiting tasks for a series complete, `RefCount` reaches zero, and the semaphore is disposed and removed from the dictionary, preventing memory leaks.

```csharp
public class KeyedLockService : IKeyedLockService
{
    private sealed class RefCountedSemaphore
    {
        public readonly SemaphoreSlim Semaphore = new(1, 1);
        public int RefCount = 1;
    }

    private readonly ConcurrentDictionary<string, RefCountedSemaphore> _locks = new();

    public async Task<IDisposable> AcquireLockAsync(string key, CancellationToken ct = default)
    {
        RefCountedSemaphore item;
        lock (_locks)
        {
            if (_locks.TryGetValue(key, out var existing))
            {
                existing.RefCount++;
                item = existing;
            }
            else
            {
                item = new RefCountedSemaphore();
                _locks[key] = item;
            }
        }

        await item.Semaphore.WaitAsync(ct).ConfigureAwait(false);
        return new Releaser(this, key, item);
    }
    // ... thread-safe RefCount decrement and cleanup ...
}
```

---

### 9.5 Enterprise Production Mapping: Distributed Queues

While the in-memory keyed lock provides zero-overhead serialization on a single instance, distributed multi-node cloud deployments map this identical design to enterprise messaging backends:

| Environment | Mechanism | Partitioning / Grouping Key | Concurrency Characteristics |
| :--- | :--- | :--- | :--- |
| **Standalone / Local** | `KeyedLockService` (`ConcurrentDictionary<string, SemaphoreSlim>`) | `"{tenantId}_{seriesInstanceUid}"` | In-process non-blocking async locks; thread-pool concurrency across series. |
| **AWS Cloud** | **AWS SQS FIFO** | `MessageGroupId = $"{tenantId}_{seriesInstanceUid}"` | SQS FIFO guarantees strict sequential consumption per `MessageGroupId` across distributed worker pools, while distinct groups scale horizontally. |
| **Event Streaming** | **Apache Kafka** | `Record.Key = $"{tenantId}_{seriesInstanceUid}"` | Messages for the same series land deterministically on the same partition, processed in exact order by a single consumer thread. |
| **AMQP / RabbitMQ** | **Consistent Hash Exchange** | Routing Key = `"{tenantId}_{seriesInstanceUid}"` | Hashes series to dedicated queues, guaranteeing single-consumer serial processing per series. |

#### AWS SQS FIFO Ingestion Pattern
In an enterprise AWS deployment:
1. Modality upload events trigger an S3 Event Notification or an API Gateway ingest endpoint.
2. The ingestion coordinator publishes slice-processing tasks to an SQS FIFO queue with:
   - `MessageGroupId = $"{tenantId}_{seriesInstanceUid}"`
   - `MessageDeduplicationId = $"{tenantId}_{studyUid}_{seriesUid}_{sopInstanceUid}"`
3. A cluster of worker nodes consumes messages from SQS. SQS automatically locks the `MessageGroupId` to the worker currently processing it until the message is acknowledged, preventing concurrent updates to the same series manifest across nodes.
4. Once the series manifest is updated in S3 and projected to SQL, the worker acknowledges the message, allowing subsequent slices for that series to be consumed.

---

### 9.6 Database Concurrency Architecture: `_dbWriteLock` vs. SQS FIFO + Production RDBMS

A critical architectural distinction exists between the local development database concurrency model and the production cloud architecture:

#### A. Why `_dbWriteLock` is Mandatory in the Current Implementation
In the current standalone implementation, `_dbWriteLock` (`SemaphoreSlim(1, 1)`) is implemented in `DicomIndexService` to satisfy two local engine constraints:
1. **SQLite Engine Single-Writer Architecture**:
   While SQLite WAL (Write-Ahead Logging) mode allows unlimited concurrent readers, SQLite is strictly **single-writer across the entire database file**. Simultaneous write transactions from multiple threads result in `SQLITE_BUSY` (`database is locked`) errors once the busy timeout is reached.
2. **EF Core `DbContext` Thread Safety within a Request**:
   In ASP.NET Core, `DicomDbContext` is scoped to the incoming HTTP request. When `IngestBulkAsync` processes 50 series across 16 worker threads, multiple threads cannot call `IndexManifestAsync` on the same `DbContext` instance concurrently without triggering EF Core's concurrency detector: `InvalidOperationException: A second operation was started on this context instance before a previous operation completed`.

To maintain high throughput while preventing collisions:
- **Manifest S3 Uploads**: Executed **in parallel** across 16 worker threads (maximizing network IOPS).
- **SQLite Database Indexing**: Executed **sequentially on the request thread** (and serialized across requests via `_dbWriteLock`). At $<1\text{ ms}$ per series write, 50 series index in only $\sim 50\text{ ms}$.

#### B. Why `_dbWriteLock` is NOT Required (and an Anti-Pattern) with SQS FIFO + PostgreSQL/Aurora
In an enterprise production deployment using AWS SQS FIFO and a distributed RDBMS:
1. **Row-Level Locking & MVCC**:
   Enterprise databases like **PostgreSQL** or **Amazon Aurora** do not have SQLite's single-writer limitation. They utilize Multi-Version Concurrency Control (MVCC) and fine-grained row-level locking. Worker Pod 1 updating Series A and Worker Pod 2 updating Series B write to `Patients`, `Studies`, `Series`, and `Instances` **completely in parallel with zero database-level locking**.
2. **Isolated `DbContext` per Message Scope**:
   In an SQS worker service, each message consumer creates its own DI `IServiceScope` via `_serviceScopeFactory.CreateScope()`. Each worker thread possesses its own isolated `DicomDbContext` instance, completely eliminating in-process EF Core multi-threading collisions.
3. **Cross-Pod Synchronization**:
   An in-process C# `SemaphoreSlim` only coordinates threads within the memory of a single operating system process. It cannot coordinate across a fleet of distributed Kubernetes pods or ECS tasks.
4. **Handling Study-Level Row Updates**:
   If SQS delivers two distinct series belonging to the **same study** to Worker 1 and Worker 2 concurrently:
   - *Option 1 (RDBMS Row Lock)*: The database automatically sequences the update to the single `Studies` row (`NumberOfStudyRelatedSeries`, `NumberOfStudyRelatedInstances`). Worker 2 waits only $<1\text{ ms}$ for Worker 1's row lock to release, without blocking any other study in the system.
   - *Option 2 (Study-Level SQS Partitioning)*: Setting `MessageGroupId = $"{tenantId}_{studyInstanceUid}"` guarantees that all series for the same study process sequentially on one worker, while different studies process in parallel across all worker pods.

#### Architectural Comparison Matrix

| Architectural Dimension | Current Setup (In-Memory + SQLite) | Production Setup (AWS SQS FIFO + Aurora / PostgreSQL) |
| :--- | :--- | :--- |
| **Series Serialization** | `IKeyedLockService` (`ConcurrentDictionary<string, SemaphoreSlim>`) | `MessageGroupId = $"{tenantId}_{seriesInstanceUid}"` managed by AWS SQS FIFO |
| **Cross-Series Parallelism** | Multi-threaded within a single ASP.NET Core process | Horizontally scaled across $N$ distributed worker pods / ECS tasks |
| **Database Concurrency Model** | **Single writer globally** (SQLite engine constraint) | **Concurrent writers** via PostgreSQL / Aurora MVCC & row-level locks |
| **DbContext Lifecycle** | Scoped per HTTP request (shared across threads in request) | Fresh `DbContext` instance per SQS message execution scope |
| **Application Mutex (`_dbWriteLock`)** | **Required** (prevents `SQLITE_BUSY` and EF Core collisions) | **Not Required** (unnecessary; would throttle horizontal scalability) |
| **Study Aggregate Contention** | Single-pass `UPDATE ... FROM` executed sequentially | Row-level locking on `Studies` row or study-level `MessageGroupId` |

---

### 9.7 Resilience, Deadlocks & Replay Guarantees
1. **Deadlock Freedom**: Locks are acquired strictly at the **Series level** (`tenantId_seriesUid`). There is no nested locking across studies or patients, eliminating circular dependency deadlocks.
2. **Re-Ingestion Idempotency**: Re-ingesting an entire series or a subset of slices produces the identical cumulative manifest and database state.
3. **Zero-Loss Replay (`POST /api/v1/indexing/sync`)**: Since S3 `manifest.json` is always cumulative and authoritative, the entire database projection can be dropped and rebuilt from S3 storage at any time with zero data loss.

---

## 10. Architectural Evolution Roadmap

1. **Distributed Queue Adapter**: Provide pluggable `IKeyedSeriesQueue` implementations for AWS SQS FIFO and Kafka alongside the current in-memory `KeyedLockService`.
2. **Series Acquisition Completion Webhooks / Signals**: Provide modalities and PACS an explicit completion notification (`POST /api/v1/ingest/series/{seriesUid}/complete`) to trigger downstream AI inference, HL7/FHIR notifications, or deep archive tiering.
3. **Multi-Region Active-Active Replication**: Leverage S3 Cross-Region Replication (CRR) for immutable manifests and read-replica SQLite/PostgreSQL nodes for geo-distributed QIDO-RS query routing.

