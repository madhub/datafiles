using System.Diagnostics;
using DicomIngestion.Api.Data;
using DicomIngestion.Api.Models;
using DicomIngestion.Api.Services;
using Microsoft.Data.Sqlite;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging.Abstractions;
using Microsoft.Extensions.Options;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using NSubstitute;

namespace DicomIngestion.Tests;

[TestClass]
public class ProgressiveIngestionTests
{
    [TestMethod]
    public async Task KeyedLockService_SerializesSameKey_RunsDifferentKeysInParallel()
    {
        var locker = new KeyedLockService();
        var sameKeyExecutionOrder = new List<int>();
        var sw = Stopwatch.StartNew();

        // 1. Same key: Should execute sequentially
        var t1 = Task.Run(async () =>
        {
            using (await locker.AcquireLockAsync("tenant1_seriesA"))
            {
                await Task.Delay(100);
                sameKeyExecutionOrder.Add(1);
            }
        });

        var t2 = Task.Run(async () =>
        {
            await Task.Delay(20); // ensure t1 requests first
            using (await locker.AcquireLockAsync("tenant1_seriesA"))
            {
                sameKeyExecutionOrder.Add(2);
            }
        });

        await Task.WhenAll(t1, t2);
        Assert.AreEqual(1, sameKeyExecutionOrder[0]);
        Assert.AreEqual(2, sameKeyExecutionOrder[1]);

        // 2. Different keys: Should run concurrently
        sw.Restart();
        var tDiff1 = Task.Run(async () =>
        {
            using (await locker.AcquireLockAsync("tenant1_seriesB"))
            {
                await Task.Delay(150);
            }
        });

        var tDiff2 = Task.Run(async () =>
        {
            using (await locker.AcquireLockAsync("tenant1_seriesC"))
            {
                await Task.Delay(150);
            }
        });

        await Task.WhenAll(tDiff1, tDiff2);
        sw.Stop();

        // If run in parallel, total elapsed time should be < 280ms (well under 150 + 150 = 300ms)
        Assert.IsTrue(sw.ElapsedMilliseconds < 280, $"Expected parallel execution under 280ms, but was {sw.ElapsedMilliseconds}ms");
    }

    [TestMethod]
    public async Task ProgressiveManifestMerge_KeepsS3AndDatabaseConsistentAcrossBatches()
    {
        // 1. Setup in-memory SQLite database with required tables
        using var connection = new SqliteConnection("DataSource=:memory:");
        connection.Open();

        var options = new DbContextOptionsBuilder<DicomDbContext>()
            .UseSqlite(connection)
            .Options;

        using (var initDb = new DicomDbContext(options))
        {
            await initDb.Database.EnsureCreatedAsync();
        }

        using var db = new DicomDbContext(options);
        var s3Mock = Substitute.For<IS3StorageService>();
        var minioOptions = Options.Create(new MinioOptions());
        var indexService = new DicomIndexService(db, s3Mock, minioOptions, NullLogger<DicomIndexService>.Instance);
        var locker = new KeyedLockService();

        SeriesManifest? storedS3Manifest = null;
        s3Mock.PutJsonAsync(Arg.Any<string>(), Arg.Any<string>(), Arg.Any<SeriesManifest>(), Arg.Any<CancellationToken>())
            .Returns(ci =>
            {
                storedS3Manifest = ci.Arg<SeriesManifest>();
                return Task.CompletedTask;
            });

        s3Mock.GetJsonAsync<SeriesManifest>(Arg.Any<string>(), Arg.Any<string>(), Arg.Any<CancellationToken>())
            .Returns(ci => Task.FromResult(storedS3Manifest));

        // 2. Batch 1: Ingest 3 instances of Series 1
        var batch1Manifest = new SeriesManifest
        {
            TenantId = "tenant-001",
            ManifestS3Key = "tenant-001/1.2.3/1.2.3.1/manifest.json",
            TotalInstances = 3,
            TotalSizeBytes = 3000,
            Patient = new PatientMetadata { PatientId = "PAT-01", PatientName = "DOE^JOHN" },
            Study = new StudyMetadata { StudyInstanceUid = "1.2.3", StudyDate = "20260906" },
            Series = new SeriesMetadata { SeriesInstanceUid = "1.2.3.1", Modality = "CT", SeriesNumber = "1" },
            CommonInstanceMetadata = new InstanceImageAttributes { Rows = 512, Columns = 512, BitsAllocated = 16 },
            Instances = new List<FactoredInstanceMetadata>
            {
                new() { SopInstanceUid = "1.2.3.1.1", InstanceNumber = "1", FileSizeBytes = 1000 },
                new() { SopInstanceUid = "1.2.3.1.2", InstanceNumber = "2", FileSizeBytes = 1000 },
                new() { SopInstanceUid = "1.2.3.1.3", InstanceNumber = "3", FileSizeBytes = 1000 }
            }
        };

        // Write Batch 1 to S3 and Index
        await s3Mock.PutJsonAsync("dicom-destination", batch1Manifest.ManifestS3Key, batch1Manifest);
        await indexService.IndexManifestAsync(batch1Manifest);

        // Verify Batch 1 in DB
        var study1 = await db.Studies.FirstAsync();
        Assert.AreEqual(1, study1.NumberOfStudyRelatedSeries);
        Assert.AreEqual(3, study1.NumberOfStudyRelatedInstances);
        Assert.AreEqual(3, await db.Instances.CountAsync());

        // 3. Batch 2: Incremental 4 new instances for the SAME series (Slices 4 to 7)
        var batch2IncomingInstances = new List<FactoredInstanceMetadata>
        {
            new() { SopInstanceUid = "1.2.3.1.4", InstanceNumber = "4", FileSizeBytes = 1000 },
            new() { SopInstanceUid = "1.2.3.1.5", InstanceNumber = "5", FileSizeBytes = 1000 },
            new() { SopInstanceUid = "1.2.3.1.6", InstanceNumber = "6", FileSizeBytes = 1000 },
            new() { SopInstanceUid = "1.2.3.1.7", InstanceNumber = "7", FileSizeBytes = 1000 }
        };

        // Simulate Progressive Merge
        var existingManifest = await s3Mock.GetJsonAsync<SeriesManifest>("dicom-destination", batch1Manifest.ManifestS3Key);
        Assert.IsNotNull(existingManifest);

        var mergedDict = existingManifest.Instances.ToDictionary(i => i.SopInstanceUid);
        foreach (var inst in batch2IncomingInstances)
        {
            mergedDict[inst.SopInstanceUid] = inst;
        }

        var cumulativeInstances = mergedDict.Values.OrderBy(i => int.Parse(i.InstanceNumber ?? "0")).ToList();
        var cumulativeManifest = new SeriesManifest
        {
            TenantId = "tenant-001",
            ManifestS3Key = batch1Manifest.ManifestS3Key,
            TotalInstances = cumulativeInstances.Count,
            TotalSizeBytes = cumulativeInstances.Sum(x => x.FileSizeBytes),
            Patient = existingManifest.Patient,
            Study = existingManifest.Study,
            Series = existingManifest.Series,
            CommonInstanceMetadata = existingManifest.CommonInstanceMetadata,
            Instances = cumulativeInstances
        };

        // Update S3 and Re-Index
        await s3Mock.PutJsonAsync("dicom-destination", cumulativeManifest.ManifestS3Key, cumulativeManifest);
        await indexService.IndexManifestAsync(cumulativeManifest);

        // 4. Verify S3 and SQLite DB consistency
        Assert.AreEqual(7, storedS3Manifest!.TotalInstances);
        Assert.AreEqual(7, storedS3Manifest.Instances.Count);

        // Verify SQLite reflects all 7 instances with accurate study aggregates
        await db.Entry(study1).ReloadAsync();
        Assert.AreEqual(1, study1.NumberOfStudyRelatedSeries);
        Assert.AreEqual(7, study1.NumberOfStudyRelatedInstances);
        Assert.AreEqual(7, await db.Instances.CountAsync());

        // Verify exact instance UIDs in DB
        var instanceUids = await db.Instances.Select(i => i.SopInstanceUid).OrderBy(x => x).ToListAsync();
        Assert.AreEqual(7, instanceUids.Count);
        Assert.AreEqual("1.2.3.1.1", instanceUids[0]);
        Assert.AreEqual("1.2.3.1.7", instanceUids[6]);
    }
}
