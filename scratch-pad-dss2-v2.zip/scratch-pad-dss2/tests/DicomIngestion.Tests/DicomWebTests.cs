using System.Text.Json;
using System.Text.Json.Nodes;
using DicomIngestion.Api.Data;
using DicomIngestion.Api.Models;
using DicomIngestion.Api.Services;
using Microsoft.Data.Sqlite;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging.Abstractions;
using Microsoft.Extensions.Options;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using NSubstitute;

namespace DicomIngestion.Tests;

[TestClass]
public class DicomWebTests
{
    [TestMethod]
    public void ToDicomJson_StudyRecord_IncludesRequiredQidoAttributes()
    {
        var study = new StudyRecord
        {
            TenantId = "tenant-001",
            StudyInstanceUid = "1.2.3.4.5",
            StudyDate = "20260906",
            StudyTime = "120000",
            AccessionNumber = "ACC001",
            StudyDescription = "Chest CT",
            ReferringPhysicianName = "DR^DOE",
            NumberOfStudyRelatedSeries = 2,
            NumberOfStudyRelatedInstances = 50,
            ModalitiesInStudy = "CT",
            Patient = new PatientRecord
            {
                PatientId = "PAT001",
                PatientName = "DOE^JOHN",
                IssuerOfPatientId = "HOSPITAL",
                PatientBirthDate = "19800101",
                PatientSex = "M"
            }
        };

        var dicomJson = DicomJsonHelper.ToDicomJson(study);

        Assert.IsNotNull(dicomJson);
        Assert.IsTrue(dicomJson.ContainsKey("0020000D"));
        Assert.IsTrue(dicomJson.ContainsKey("00201206"));
        Assert.AreEqual(2, dicomJson["00201206"]!["Value"]![0]!.GetValue<int>());
        Assert.IsTrue(dicomJson.ContainsKey("00201208"));
        Assert.AreEqual(50, dicomJson["00201208"]!["Value"]![0]!.GetValue<int>());
        Assert.IsTrue(dicomJson.ContainsKey("00080061"));
        Assert.AreEqual("CT", dicomJson["00080061"]!["Value"]![0]!.GetValue<string>());
        Assert.IsTrue(dicomJson.ContainsKey("00100020"));
        Assert.AreEqual("PAT001", dicomJson["00100020"]!["Value"]![0]!.GetValue<string>());
    }

    [TestMethod]
    public void ToDicomJson_AttributesAreOrderedInAscendingTagOrder()
    {
        var study = new StudyRecord
        {
            TenantId = "tenant-001",
            StudyInstanceUid = "1.2.3.4.5",
            StudyDate = "20260906",
            StudyTime = "120000",
            AccessionNumber = "ACC001",
            StudyDescription = "Chest CT",
            ReferringPhysicianName = "DR^DOE",
            NumberOfStudyRelatedSeries = 2,
            NumberOfStudyRelatedInstances = 50,
            ModalitiesInStudy = "CT",
            Patient = new PatientRecord
            {
                PatientId = "PAT001",
                PatientName = "DOE^JOHN",
                IssuerOfPatientId = "HOSPITAL",
                PatientBirthDate = "19800101",
                PatientSex = "M"
            }
        };

        var dicomJson = DicomJsonHelper.ToDicomJson(study);
        var keys = dicomJson.Select(k => k.Key).ToList();
        var sortedKeys = keys.OrderBy(x => x, StringComparer.OrdinalIgnoreCase).ToList();
        CollectionAssert.AreEqual(sortedKeys, keys, "Study DICOM JSON tags must be in strictly ascending order.");

        var series = new SeriesRecord
        {
            TenantId = "tenant-001",
            StudyInstanceUid = "1.2.3.4.5",
            SeriesInstanceUid = "1.2.3.4.5.1",
            Modality = "CT",
            SeriesNumber = "1",
            SeriesDescription = "Axial",
            BodyPartExamined = "CHEST",
            NumberOfSeriesRelatedInstances = 25
        };

        var seriesJson = DicomJsonHelper.ToDicomJson(series);
        var seriesKeys = seriesJson.Select(k => k.Key).ToList();
        var sortedSeriesKeys = seriesKeys.OrderBy(x => x, StringComparer.OrdinalIgnoreCase).ToList();
        CollectionAssert.AreEqual(sortedSeriesKeys, seriesKeys, "Series DICOM JSON tags must be in strictly ascending order.");

        var instance = new InstanceRecord
        {
            TenantId = "tenant-001",
            StudyInstanceUid = "1.2.3.4.5",
            SeriesInstanceUid = "1.2.3.4.5.1",
            SopInstanceUid = "1.2.3.4.5.1.1",
            SopClassUid = "1.2.840.10008.5.1.4.1.1.2",
            InstanceNumber = "1"
        };

        var instanceJson = DicomJsonHelper.ToDicomJson(instance);
        var instanceKeys = instanceJson.Select(k => k.Key).ToList();
        var sortedInstanceKeys = instanceKeys.OrderBy(x => x, StringComparer.OrdinalIgnoreCase).ToList();
        CollectionAssert.AreEqual(sortedInstanceKeys, instanceKeys, "Instance DICOM JSON tags must be in strictly ascending order.");
    }

    [TestMethod]
    public void ToDicomJson_SeriesRecord_IncludesNumberOfSeriesRelatedInstances()
    {
        var series = new SeriesRecord
        {
            TenantId = "tenant-001",
            StudyInstanceUid = "1.2.3.4.5",
            SeriesInstanceUid = "1.2.3.4.5.1",
            Modality = "CT",
            SeriesNumber = "1",
            SeriesDescription = "Axial 5mm",
            BodyPartExamined = "CHEST",
            NumberOfSeriesRelatedInstances = 25
        };

        var dicomJson = DicomJsonHelper.ToDicomJson(series);

        Assert.IsNotNull(dicomJson);
        Assert.IsTrue(dicomJson.ContainsKey("0020000E"));
        Assert.IsTrue(dicomJson.ContainsKey("00201209"));
        Assert.AreEqual(25, dicomJson["00201209"]!["Value"]![0]!.GetValue<int>());
        Assert.IsTrue(dicomJson.ContainsKey("00080060"));
        Assert.AreEqual("CT", dicomJson["00080060"]!["Value"]![0]!.GetValue<string>());
    }

    [TestMethod]
    public async Task IndexManifestAsync_PopulatesDatabaseAndCalculatesAggregates()
    {
        using var connection = new SqliteConnection("Filename=:memory:");
        await connection.OpenAsync();

        var options = new DbContextOptionsBuilder<DicomDbContext>()
            .UseSqlite(connection)
            .Options;

        using var db = new DicomDbContext(options);
        await db.Database.EnsureCreatedAsync();

        var mockS3 = Substitute.For<IS3StorageService>();
        var minioOptions = Options.Create(new MinioOptions());
        var service = new DicomIndexService(db, mockS3, minioOptions, NullLogger<DicomIndexService>.Instance);

        var manifest1 = new SeriesManifest
        {
            TenantId = "tenant-001",
            ManifestS3Key = "tenant-001/1.2.3/1.2.3.1/manifest.json",
            TotalInstances = 3,
            TotalSizeBytes = 3000,
            Patient = new PatientMetadata { PatientId = "PAT-1", PatientName = "Test Patient" },
            Study = new StudyMetadata { StudyInstanceUid = "1.2.3", StudyDate = "20260906", AccessionNumber = "ACC1" },
            Series = new SeriesMetadata { SeriesInstanceUid = "1.2.3.1", Modality = "CT", SeriesNumber = "1" },
            CommonInstanceMetadata = new InstanceImageAttributes { SopClassUid = "1.2.840.10008.5.1.4.1.1.2" },
            Instances = new List<FactoredInstanceMetadata>
            {
                new() { SopInstanceUid = "1.2.3.1.1", InstanceNumber = "1", DestinationS3Key = "k1", FileSizeBytes = 1000 },
                new() { SopInstanceUid = "1.2.3.1.2", InstanceNumber = "2", DestinationS3Key = "k2", FileSizeBytes = 1000 },
                new() { SopInstanceUid = "1.2.3.1.3", InstanceNumber = "3", DestinationS3Key = "k3", FileSizeBytes = 1000 }
            }
        };

        var manifest2 = new SeriesManifest
        {
            TenantId = "tenant-001",
            ManifestS3Key = "tenant-001/1.2.3/1.2.3.2/manifest.json",
            TotalInstances = 2,
            TotalSizeBytes = 2000,
            Patient = new PatientMetadata { PatientId = "PAT-1", PatientName = "Test Patient" },
            Study = new StudyMetadata { StudyInstanceUid = "1.2.3", StudyDate = "20260906", AccessionNumber = "ACC1" },
            Series = new SeriesMetadata { SeriesInstanceUid = "1.2.3.2", Modality = "CT", SeriesNumber = "2" },
            CommonInstanceMetadata = new InstanceImageAttributes { SopClassUid = "1.2.840.10008.5.1.4.1.1.2" },
            Instances = new List<FactoredInstanceMetadata>
            {
                new() { SopInstanceUid = "1.2.3.2.1", InstanceNumber = "1", DestinationS3Key = "k4", FileSizeBytes = 1000 },
                new() { SopInstanceUid = "1.2.3.2.2", InstanceNumber = "2", DestinationS3Key = "k5", FileSizeBytes = 1000 }
            }
        };

        await service.IndexManifestAsync(manifest1);
        await service.IndexManifestAsync(manifest2);

        var stats = await service.GetIndexStatsAsync("tenant-001");
        Assert.AreEqual(1, stats.PatientCount);
        Assert.AreEqual(1, stats.StudyCount);
        Assert.AreEqual(2, stats.SeriesCount);
        Assert.AreEqual(5, stats.InstanceCount);

        var studies = await service.QueryStudiesAsync("tenant-001", new QidoStudyQuery());
        Assert.AreEqual(1, studies.Count);
        Assert.AreEqual(2, studies[0].NumberOfStudyRelatedSeries);
        Assert.AreEqual(5, studies[0].NumberOfStudyRelatedInstances);

        var seriesList = await service.QuerySeriesAsync("tenant-001", "1.2.3", new QidoSeriesQuery());
        Assert.AreEqual(2, seriesList.Count);
        Assert.AreEqual(3, seriesList.First(s => s.SeriesInstanceUid == "1.2.3.1").NumberOfSeriesRelatedInstances);
        Assert.AreEqual(2, seriesList.First(s => s.SeriesInstanceUid == "1.2.3.2").NumberOfSeriesRelatedInstances);
    }

    [TestMethod]
    public async Task QueryStudiesAsync_SupportsHexTagsAndWildcards()
    {
        using var connection = new SqliteConnection("Filename=:memory:");
        await connection.OpenAsync();

        var options = new DbContextOptionsBuilder<DicomDbContext>()
            .UseSqlite(connection)
            .Options;

        using var db = new DicomDbContext(options);
        await db.Database.EnsureCreatedAsync();

        var mockS3 = Substitute.For<IS3StorageService>();
        var minioOptions = Options.Create(new MinioOptions());
        var service = new DicomIndexService(db, mockS3, minioOptions, NullLogger<DicomIndexService>.Instance);

        var manifest1 = new SeriesManifest
        {
            TenantId = "tenant-001",
            ManifestS3Key = "tenant-001/1.1/1.1.1/manifest.json",
            TotalInstances = 1,
            Patient = new PatientMetadata { PatientId = "PAT-0004", PatientName = "BENCHMARK^PATIENT^PAT-0004" },
            Study = new StudyMetadata { StudyInstanceUid = "1.1", StudyDate = "20260906" },
            Series = new SeriesMetadata { SeriesInstanceUid = "1.1.1", Modality = "CT" },
            Instances = new List<FactoredInstanceMetadata>
            {
                new() { SopInstanceUid = "1.1.1.1", InstanceNumber = "1", DestinationS3Key = "k1" }
            }
        };

        var manifest2 = new SeriesManifest
        {
            TenantId = "tenant-001",
            ManifestS3Key = "tenant-001/1.2/1.2.1/manifest.json",
            TotalInstances = 1,
            Patient = new PatientMetadata { PatientId = "PAT-0006", PatientName = "OTHER^PATIENT^PAT-0006" },
            Study = new StudyMetadata { StudyInstanceUid = "1.2", StudyDate = "20260906" },
            Series = new SeriesMetadata { SeriesInstanceUid = "1.2.1", Modality = "CT" },
            Instances = new List<FactoredInstanceMetadata>
            {
                new() { SopInstanceUid = "1.2.1.1", InstanceNumber = "1", DestinationS3Key = "k2" }
            }
        };

        await service.IndexManifestAsync(manifest1);
        await service.IndexManifestAsync(manifest2);

        // 1. Test 00100020=PAT-0004 via PopulateFromQuery
        var q1 = new QidoStudyQuery();
        var dict1 = new Dictionary<string, Microsoft.Extensions.Primitives.StringValues> { { "00100020", "PAT-0004" } };
        q1.PopulateFromQuery(new Microsoft.AspNetCore.Http.QueryCollection(dict1));
        Assert.AreEqual("PAT-0004", q1.PatientID);

        var res1 = await service.QueryStudiesAsync("tenant-001", q1);
        Assert.AreEqual(1, res1.Count);
        Assert.AreEqual("PAT-0004", res1[0].PatientId);

        // 2. Test 00100010=BEN* via PopulateFromQuery
        var q2 = new QidoStudyQuery();
        var dict2 = new Dictionary<string, Microsoft.Extensions.Primitives.StringValues> { { "00100010", "BEN*" } };
        q2.PopulateFromQuery(new Microsoft.AspNetCore.Http.QueryCollection(dict2));
        Assert.AreEqual("BEN*", q2.PatientName);

        var res2 = await service.QueryStudiesAsync("tenant-001", q2);
        Assert.AreEqual(1, res2.Count);
        Assert.AreEqual("PAT-0004", res2[0].PatientId);
    }

    [TestMethod]
    public async Task CleanupAsync_PurgesTenantDatabaseRecordsAndCallsS3Delete()
    {
        using var connection = new SqliteConnection("Filename=:memory:");
        await connection.OpenAsync();

        var options = new DbContextOptionsBuilder<DicomDbContext>()
            .UseSqlite(connection)
            .Options;

        using var db = new DicomDbContext(options);
        await db.Database.EnsureCreatedAsync();

        var mockS3 = Substitute.For<IS3StorageService>();
        mockS3.DeleteObjectsByPrefixAsync(Arg.Any<string>(), Arg.Any<string>(), Arg.Any<CancellationToken>())
            .Returns(Task.FromResult(5));

        var minioOptions = Options.Create(new MinioOptions
        {
            DefaultDestinationBucket = "dicom-destination",
            DefaultSourceBucket = "dicom-source"
        });
        var service = new DicomIndexService(db, mockS3, minioOptions, NullLogger<DicomIndexService>.Instance);

        // Index data for tenant-001
        await service.IndexManifestAsync(new SeriesManifest
        {
            TenantId = "tenant-001",
            ManifestS3Key = "tenant-001/1/1/manifest.json",
            TotalInstances = 1,
            Patient = new PatientMetadata { PatientId = "P1" },
            Study = new StudyMetadata { StudyInstanceUid = "1" },
            Series = new SeriesMetadata { SeriesInstanceUid = "1" },
            Instances = new List<FactoredInstanceMetadata> { new() { SopInstanceUid = "1.1" } }
        });

        // Index data for tenant-002
        await service.IndexManifestAsync(new SeriesManifest
        {
            TenantId = "tenant-002",
            ManifestS3Key = "tenant-002/2/2/manifest.json",
            TotalInstances = 1,
            Patient = new PatientMetadata { PatientId = "P2" },
            Study = new StudyMetadata { StudyInstanceUid = "2" },
            Series = new SeriesMetadata { SeriesInstanceUid = "2" },
            Instances = new List<FactoredInstanceMetadata> { new() { SopInstanceUid = "2.1" } }
        });

        // Act: Cleanup tenant-001
        var cleanupResult = await service.CleanupAsync(new CleanupRequest
        {
            TenantId = "tenant-001",
            CleanupDatabase = true,
            CleanupDestinationS3 = true
        });

        // Assert
        Assert.IsTrue(cleanupResult.Success);
        Assert.AreEqual(1, cleanupResult.DeletedInstances);
        Assert.AreEqual(1, cleanupResult.DeletedSeries);
        Assert.AreEqual(1, cleanupResult.DeletedStudies);
        Assert.AreEqual(1, cleanupResult.DeletedPatients);
        Assert.AreEqual(5, cleanupResult.DeletedDestinationS3Objects);

        // Verify tenant-001 is gone from database
        var stats1 = await service.GetIndexStatsAsync("tenant-001");
        Assert.AreEqual(0, stats1.PatientCount);
        Assert.AreEqual(0, stats1.StudyCount);
        Assert.AreEqual(0, stats1.SeriesCount);
        Assert.AreEqual(0, stats1.InstanceCount);

        // Verify tenant-002 is still intact
        var stats2 = await service.GetIndexStatsAsync("tenant-002");
        Assert.AreEqual(1, stats2.PatientCount);
        Assert.AreEqual(1, stats2.StudyCount);

        // Verify S3 delete was called for tenant-001/
        await mockS3.Received(1).DeleteObjectsByPrefixAsync("dicom-destination", "tenant-001/", Arg.Any<CancellationToken>());
    }

    [TestMethod]
    public void IngestResponse_OmitsFullManifestsByDefault_AndPopulatesManifestS3Keys()
    {
        var response = new IngestResponse
        {
            Success = true,
            TenantId = "tenant-001",
            IngestionMode = "BulkUnsegregated",
            SourceBucket = "dicom-source",
            DestinationBucket = "dicom-destination",
            ConcurrencyUsed = 16,
            SeriesCount = 1,
            StudyCount = 1,
            PatientCount = 1,
            ManifestS3Keys = new List<string> { "tenant-001/1.2/1.2.1/manifest.json" },
            SeriesManifests = null // Default behavior
        };

        var options = new JsonSerializerOptions { PropertyNamingPolicy = JsonNamingPolicy.CamelCase };
        var json = JsonSerializer.Serialize(response, options);

        Assert.IsTrue(json.Contains("\"manifestS3Keys\""));
        Assert.IsTrue(json.Contains("tenant-001/1.2/1.2.1/manifest.json"));
        Assert.IsFalse(json.Contains("\"seriesManifests\""));

        // If explicitly included
        response.SeriesManifests = new List<SeriesManifest>
        {
            new() { TenantId = "tenant-001", ManifestS3Key = "tenant-001/1.2/1.2.1/manifest.json" }
        };
        var jsonWithManifests = JsonSerializer.Serialize(response, options);
        Assert.IsTrue(jsonWithManifests.Contains("\"seriesManifests\""));
    }
}
